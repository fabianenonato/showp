<!DOCTYPE html>
<html lang="pt">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
    
    <meta charset="utf-8"/>
    <meta name="generator" content="Wix.com Website Builder"/>
    <link rel="shortcut icon" href="https://www.wix.com/favicon.ico" type="image/x-icon"/>
    <link rel="apple-touch-icon" href="https://www.wix.com/favicon.ico" type="image/x-icon"/>
    
    
    
    
    <meta http-equiv="X-Wix-Meta-Site-Id" content="ed554812-eecc-40de-ac38-0af295cb607b"/>
    <meta http-equiv="X-Wix-Application-Instance-Id" content="1b9e9ea3-dfd2-4dbc-8ba1-a39a2a645328"/>
    
    
        <meta http-equiv="X-Wix-Published-Version" content="57"/>
    
    
    
    
    <meta name = "format-detection" content = "telephone=no"/>
    
    

    <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE"/>

    
     <meta id="wixMobileViewport" name="viewport" content="width=980, user-scalable=yes"/>
    

    
    
    
    

    





    <!-- META DATA -->
    <script type="text/javascript">
        

        var serviceTopology = {"cacheKillerVersion":"1","staticServerUrl":"https://static.parastorage.com/","usersScriptsRoot":"//static.parastorage.com/services/wix-users/2.660.0","biServerUrl":"https://frog.wix.com/","userServerUrl":"https://users.wix.com/","billingServerUrl":"https://premium.wix.com/","mediaRootUrl":"https://static.wixstatic.com/","logServerUrl":"https://frog.wix.com/plebs","monitoringServerUrl":"https://TODO/","usersClientApiUrl":"https://users.wix.com/wix-users","publicStaticBaseUri":"//static.parastorage.com/services/wix-public/1.299.0","basePublicUrl":"https://www.wix.com/","postLoginUrl":"https://www.wix.com/my-account","postSignUpUrl":"https://www.wix.com/new/account","baseDomain":"wix.com","staticMediaUrl":"https://static.wixstatic.com/media","staticAudioUrl":"https://music.wixstatic.com/mp3","staticDocsUrl":"https://docs.wixstatic.com/ugd","emailServer":"https://assets.wix.com/common-services/notification/invoke","blobUrl":"https://static.parastorage.com/wix_blob","htmlEditorUrl":"http://editor.wix.com/html","siteMembersUrl":"https://users.wix.com/wix-sm","scriptsLocationMap":{"automation":"https://static.parastorage.com/services/automation/1.23.0","bootstrap":"https://static.parastorage.com/services/bootstrap/2.1229.80","ck-editor":"https://static.parastorage.com/services/ck-editor/1.87.3","cookie-consent-policy-client":"https://static.parastorage.com/services/cookie-consent-policy-client/1.177.0","core":"https://static.parastorage.com/services/core/2.1229.80","dbsm-editor-app":"https://static.parastorage.com/services/dbsm-editor-app/1.1839.0","dbsm-viewer-app":"https://static.parastorage.com/services/dbsm-viewer-app/1.1151.0","ecommerce":"https://static.parastorage.com/services/ecommerce/1.203.0","editor-elements":"https://static.parastorage.com/services/editor-elements/1.1427.0","fallback-viewer-app":"https://static.parastorage.com/services/fallback-viewer-app/1.0.0","js-platform-apps-configuration":"https://static.parastorage.com/services/js-platform-apps-configuration/1.235.0","js-wixcode-sdk":"https://static.parastorage.com/services/js-wixcode-sdk/1.383.0","langs":"https://static.parastorage.com/services/langs/2.577.0","linguist-flags":"https://static.parastorage.com/services/linguist-flags/1.363.0","promote-analytics-adapter":"https://static.parastorage.com/services/promote-analytics-adapter/2.472.0","promote-seo-renderer":"https://static.parastorage.com/services/promote-seo-renderer/1.2.0","santa":"https://static.parastorage.com/services/santa/1.11206.0","santa-langs":"https://static.parastorage.com/services/santa-langs/1.9779.0","santa-resources":"https://static.parastorage.com/services/santa-resources/1.2.0","santa-site-auth-module":"https://static.parastorage.com/services/santa-site-auth-module/1.9.0","semi-native-sdk":"https://static.parastorage.com/services/semi-native-sdk/1.8.0","sitemembers":"https://static.parastorage.com/services/sm-js-sdk/1.31.0","skins":"https://static.parastorage.com/services/skins/2.1229.80","tag-manager-client":"https://static.parastorage.com/services/tag-manager-client/1.126.0","tpa":"https://static.parastorage.com/services/tpa/2.1065.0","web":"https://static.parastorage.com/services/web/2.1229.80","wix-bolt":"https://static.parastorage.com/services/wix-bolt/1.6455.0","wix-code-platform":"https://static.parastorage.com/services/wix-code-platform/1.425.0","wix-code-viewer-app":"https://static.parastorage.com/services/wix-code-viewer-app/1.559.0","wix-music-embed":"https://static.parastorage.com/services/wix-music-embed/1.26.0","wix-perf-measure":"https://static.parastorage.com/services/wix-perf-measure/1.178.0","wix-ui-santa":"https://static.parastorage.com/services/wix-ui-santa/1.1289.0","wixapps":"https://static.parastorage.com/services/wixapps/2.486.0","wixcode-namespaces":"https://static.parastorage.com/services/wixcode-namespaces/1.574.0"},"developerMode":false,"productionMode":true,"staticServerFallbackUrl":"https://sslstatic.wix.com/","staticVideoUrl":"https://video.wixstatic.com/","cloudStorageUrl":"https://static.wixstatic.com/","usersDomainUrl":"https://users.wix.com/wix-users","scriptsDomainUrl":"https://static.parastorage.com/","userFilesUrl":"https://static.parastorage.com/","staticHTMLComponentUrl":"https://igrejaevredencao74-wixsite-com.filesusr.com/","secured":true,"ecommerceCheckoutUrl":"https://www.safer-checkout.com/","premiumServerUrl":"https://premium.wix.com/","digitalGoodsServerUrl":"https://dgs.wixapps.net/","wixCloudBaseDomain":"wix-code.com","mailServiceSuffix":"/_api/common-services/notification/invoke","staticVideoHeadRequestUrl":"https://storage.googleapis.com/video.wixstatic.com","protectedPageResolverUrl":"https://site-pages.wix.com/_api/wix-public-html-info-webapp/resolve_protected_page_urls","mediaUploadServerUrl":"https://files.wix.com/","siteAssetsServerUrl":"https://siteassets.parastorage.com/pages","staticServerWixDomainUrl":"https://www.wix.com/_partials","adaptiveVideoDomain":"https://files.wix.com/","userFileDomainUrl":"filesusr.com","scriptsVersionsMap":{"stylable-santa-flatten":"2.0.14","ghostable-builder":"1.1.0","santa-main-r":"1.100.0","remote-widget-structure-builder":"1.220.0","santa-data-fixer":"1.1000.0","simple-all-pages":"1.0.0","ghostable-structure-builder":"1.150.0","santa-site-metadata":"1.636.0","remote-widget-assets-wrapper":"1.5.0"},"publicStaticsUrl":"//static.parastorage.com/services/wix-public/1.299.0"};
        var santaModels = true;
        var isStreaming = true;
        var rendererModel = {"metaSiteId":"ed554812-eecc-40de-ac38-0af295cb607b","siteInfo":{"documentType":"UGC","applicationType":"HtmlWeb","siteId":"1b9e9ea3-dfd2-4dbc-8ba1-a39a2a645328","siteTitleSEO":"Início | Todo Negócio AKI Pertinho"},"clientSpecMap":{"3581":{"type":"public","applicationId":3581,"appDefinitionId":"14cffd81-5215-0a7f-22f8-074b0e2401fb","appDefinitionName":"Member Account Info","instance":"3GsqE1nuXvpukPUKEAaAI0I5U9UZ-Ljxc0CQFLS6tKE.eyJpbnN0YW5jZUlkIjoiMjllZjk2YzMtOTgwYi00ZWViLTljZTgtMmRhM2Q1ZWYzMzRiIiwiYXBwRGVmSWQiOiIxNGNmZmQ4MS01MjE1LTBhN2YtMjJmOC0wNzRiMGUyNDAxZmIiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsImJpVG9rZW4iOiJjNGJhZGVkMS03NmM3LTBlMzUtMzBkMC0yNzUxNDAyNDUzMzAiLCJzaXRlT3duZXJJZCI6ImI3NTcwMzJmLWExY2ItNGMxYS1iMjM3LWUxMGMwYmY0NjljOCJ9","instanceId":"29ef96c3-980b-4eeb-9ce8-2da3d5ef334b","sectionUrl":"https:\/\/apps.wix.com\/member-info\/view","sectionMobileUrl":"https:\/\/apps.wix.com\/member-info\/view","sectionPublished":true,"sectionMobilePublished":true,"sectionSeoEnabled":false,"sectionDefaultPage":"","sectionRefreshOnWidthChange":true,"widgets":{"14dd1af6-3e02-63db-0ef2-72fbc7cc3136":{"widgetUrl":"https:\/\/apps.wix.com\/member-info\/view","widgetId":"14dd1af6-3e02-63db-0ef2-72fbc7cc3136","refreshOnWidthChange":true,"mobileUrl":"https:\/\/apps.wix.com\/member-info\/view","appPage":{"id":"member_info","name":"My Account","defaultPage":"","hidden":false,"multiInstanceEnabled":false,"order":1,"indexable":true,"fullPage":false,"landingPageInMobile":false,"hideFromMenu":false},"published":true,"mobilePublished":true,"seoEnabled":false,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":true,"componentFields":{},"default":true}},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":false,"permissions":{"revoked":false},"appFields":{}},"5":{"type":"public","applicationId":5,"appDefinitionId":"13ee94c1-b635-8505-3391-97919052c16f","appDefinitionName":"Wix Invoices","instance":"cThp40PIeoBsn6pWoB10jUn4BVnnGlmL1HCCVC_NHtE.eyJpbnN0YW5jZUlkIjoiYzkzZjQ2MjUtM2QzYi00MWM3LWFkMGItYjAzYzcyYjU4ODA3IiwiYXBwRGVmSWQiOiIxM2VlOTRjMS1iNjM1LTg1MDUtMzM5MS05NzkxOTA1MmMxNmYiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiI3MDMzYmUxOS01YzJkLTQ5MjEtYWNjNi1mNjgxYzAwZmZhNGIiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiMjQ2YTBlMzctZDNmNy0wMTE5LTAxMzMtYmFjZWU3N2VlODdjIiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"c93f4625-3d3b-41c7-ad0b-b03c72b58807","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":null},"10":{"type":"public","applicationId":10,"appDefinitionId":"14b89688-9b25-5214-d1cb-a3fb9683618b","appDefinitionName":"Mobile App-Social Posts","instance":"4YJp17mhVCRtb9XkzX_tbQzMJjjO4T6CxDRtd4KuHDw.eyJpbnN0YW5jZUlkIjoiN2ZhYzM4MzAtMTczMy00ZDg0LTlhOGQtZGE4ODBiZGU4NGIxIiwiYXBwRGVmSWQiOiIxNGI4OTY4OC05YjI1LTUyMTQtZDFjYi1hM2ZiOTY4MzYxOGIiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiJhNGQ2MTRlZi1kZWVmLTQ1ZjctODljYy02NDVhN2U1YjgxNGQiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiOTJmOTcwMjItZjlmZi0wZDVhLTM2YjUtZDA3YTllMTVlNGNhIiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"7fac3830-1733-4d84-9a8d-da880bde84b1","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"24":{"type":"public","applicationId":24,"appDefinitionId":"307ba931-689c-4b55-bb1d-6a382bad9222","appDefinitionName":"Video Maker","instance":"PXOSMPolo_c1MKp9plREU8YL9ruVk7gt4ziNmERQCio.eyJpbnN0YW5jZUlkIjoiYmYxMjMxNjUtZTRmOS00YWI4LTlhZmMtOWQ4ZTQ3NTI0YTliIiwiYXBwRGVmSWQiOiIzMDdiYTkzMS02ODljLTRiNTUtYmIxZC02YTM4MmJhZDkyMjIiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiIzNDg3NjdiMy1kZDU0LTQ0MTktYTg2Zi02YmZmYzNlZDRkODgiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiNTI0Nzc5NzctMGEzNS0wYTY2LTM2YzQtOTc3Y2QyOTkyYWUwIiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"bf123165-e4f9-4ab8-9afc-9d8e47524a9b","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"25":{"type":"public","applicationId":25,"appDefinitionId":"94bc563b-675f-41ad-a2a6-5494f211c47b","appDefinitionName":"Virtual Numbers","instance":"KxLM5IkbGDV-j4xkSdukiPD00Ob4Z58y6JrYEMsNrLs.eyJpbnN0YW5jZUlkIjoiZGRmNDAzNmQtNWVmYS00OTRkLWEwZTgtMjI5MmUxMmJkM2JhIiwiYXBwRGVmSWQiOiI5NGJjNTYzYi02NzVmLTQxYWQtYTJhNi01NDk0ZjIxMWM0N2IiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiJmYzlmNzA2NS0xM2Q5LTRjODctYmJkOC1mMTc2YzQ4MmU0NjEiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiMzBhMTRiN2YtYjAzNi0wOTkzLTBjZDAtMjg2MDc0ZTBiM2MxIiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"ddf4036d-5efa-494d-a0e8-2292e12bd3ba","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"14":{"type":"public","applicationId":14,"appDefinitionId":"139ef4fa-c108-8f9a-c7be-d5f492a2c939","appDefinitionName":"Automated Emails","instance":"IOJmLexP0TNqR9r_KyeZselmtOtifRF3LL4wCXNhfck.eyJpbnN0YW5jZUlkIjoiNTRiYmFjZmMtMTNiZS00MGU2LTk0ZmMtYWRlN2RkNmQzYTQyIiwiYXBwRGVmSWQiOiIxMzllZjRmYS1jMTA4LThmOWEtYzdiZS1kNWY0OTJhMmM5MzkiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiI0ODkxY2IwMi0zNzFmLTQzZjctYWYyYi1iMWE5NjM1YzVmZGMiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiYjllZWU0ZWUtZmQ3Mi0wMDM4LTM4YzQtYTcxNTQ4YTY1YTM5Iiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"54bbacfc-13be-40e6-94fc-ade7dd6d3a42","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":null},"5130":{"type":"public","applicationId":5130,"appDefinitionId":"1505b775-e885-eb1b-b665-1e485d9bf90e","appDefinitionName":"My Addresses","instance":"QAc_2P4IJwX2k1AwWijj8v2prh-UHLmqjY2ztWH_rzw.eyJpbnN0YW5jZUlkIjoiZDRlM2Y3MzgtYWQxOC00NTg1LTk4MWYtNDdkYjk0NjE2YTk4IiwiYXBwRGVmSWQiOiIxNTA1Yjc3NS1lODg1LWViMWItYjY2NS0xZTQ4NWQ5YmY5MGUiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsImJpVG9rZW4iOiIzOWI2YmYyYS00M2Q0LTA1NWItMzQyNy00ZDI5MDFhYTBhZTMiLCJzaXRlT3duZXJJZCI6ImI3NTcwMzJmLWExY2ItNGMxYS1iMjM3LWUxMGMwYmY0NjljOCJ9","instanceId":"d4e3f738-ad18-4585-981f-47db94616a98","sectionUrl":"https:\/\/addresses.wixapps.net\/addresses\/address-book","sectionMobileUrl":"https:\/\/addresses.wixapps.net\/addresses\/address-book","sectionPublished":true,"sectionMobilePublished":true,"sectionSeoEnabled":false,"sectionDefaultPage":"","sectionRefreshOnWidthChange":true,"widgets":{"151290e1-62a2-0775-6fbc-02182fad5dec":{"widgetUrl":"https:\/\/addresses.wixapps.net\/addresses\/address-book","widgetId":"151290e1-62a2-0775-6fbc-02182fad5dec","refreshOnWidthChange":true,"mobileUrl":"https:\/\/addresses.wixapps.net\/addresses\/address-book","appPage":{"id":"my_addresses","name":"My Addresses","defaultPage":"","hidden":false,"multiInstanceEnabled":false,"order":1,"indexable":true,"fullPage":false,"landingPageInMobile":false,"hideFromMenu":false},"published":true,"mobilePublished":true,"seoEnabled":false,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":true,"componentFields":{},"default":true}},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":false,"permissions":{"revoked":false},"appFields":{}},"20":{"type":"public","applicationId":20,"appDefinitionId":"a322993b-2c74-426f-bbb8-444db73d0d1b","appDefinitionName":"One App","instance":"i0qcZdiK1MY6TG94RIKVodUYIlH9_syfipTzpxNtxD0.eyJpbnN0YW5jZUlkIjoiZmE5ODZmNGYtZTA3MC00NmY5LWJiMWYtMTEwOGMwZDMxYTk2IiwiYXBwRGVmSWQiOiJhMzIyOTkzYi0yYzc0LTQyNmYtYmJiOC00NDRkYjczZDBkMWIiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiI1NDcwZjc1NS01ODJkLTQ1ODYtYTI0OS01ZmYzODAyYWQyYjAiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiMTdjZDI3NWQtMGViYy0wNjI3LTE3MjctMWJmYTU1MTg3YWVkIiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"fa986f4f-e070-46f9-bb1f-1108c0d31a96","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"29":{"type":"public","applicationId":29,"appDefinitionId":"8725b255-2aa2-4a53-b76d-7d3c363aaeea","appDefinitionName":"Subscriptions","instance":"HuwQO5fEZ5-MrdphVPcog6C6K9E_w3ToESAP5uxLdcI.eyJpbnN0YW5jZUlkIjoiMjBiNTIxZjktNjczMS00NDk1LTk4NzEtNzM1ZWRiNjhhOWE5IiwiYXBwRGVmSWQiOiI4NzI1YjI1NS0yYWEyLTRhNTMtYjc2ZC03ZDNjMzYzYWFlZWEiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsImJpVG9rZW4iOiJjZGUwNjllYi04OWZkLTA0NGItMzQ0OS03OWFjNGVhM2M5ZDIiLCJzaXRlT3duZXJJZCI6ImI3NTcwMzJmLWExY2ItNGMxYS1iMjM3LWUxMGMwYmY0NjljOCJ9","instanceId":"20b521f9-6731-4495-9871-735edb68a9a9","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"1104":{"type":"public","applicationId":1104,"appDefinitionId":"1375baa8-8eca-5659-ce9d-455b2009250d","appDefinitionName":"Wix Get Subscribers","instance":"YdBAScrX4CsxCNu2qtnL66MEKQ95as2Sxxj5_7fGmO4.eyJpbnN0YW5jZUlkIjoiMTA3MTQ0MWUtZWZjZS00ZjUyLTkyZjMtODk1NjllN2M4YWUzIiwiYXBwRGVmSWQiOiIxMzc1YmFhOC04ZWNhLTU2NTktY2U5ZC00NTViMjAwOTI1MGQiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsImJpVG9rZW4iOiJmZDI0MGMwYy0wMTAyLTBmOGMtM2VjYi04M2E0MGJiN2VhOTgiLCJzaXRlT3duZXJJZCI6ImI3NTcwMzJmLWExY2ItNGMxYS1iMjM3LWUxMGMwYmY0NjljOCJ9","instanceId":"1071441e-efce-4f52-92f3-89569e7c8ae3","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{"1375babd-6f2b-87ed-ff19-5778602c8b86":{"widgetUrl":"https:\/\/gs.wixapps.net\/statics\/index","widgetId":"1375babd-6f2b-87ed-ff19-5778602c8b86","refreshOnWidthChange":true,"mobileUrl":"https:\/\/gs.wixapps.net\/statics\/index","published":true,"mobilePublished":true,"seoEnabled":true,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":false,"componentFields":{},"tpaWidgetId":"wix_shoutout_widget","default":true}},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":false,"permissions":{"revoked":false},"appFields":{}},"6":{"type":"public","applicationId":6,"appDefinitionId":"150ae7ee-c74a-eecd-d3d7-2112895b988a","appDefinitionName":"Marketing Integration","instance":"PIU_svaztespclcKgmD3Xjjbz8r5OJrG4cDzQEXwnhI.eyJpbnN0YW5jZUlkIjoiN2JkMDk0OWItMTY0Zi00ZjcyLTg3OGEtMWViMTRmZDQzOWQ4IiwiYXBwRGVmSWQiOiIxNTBhZTdlZS1jNzRhLWVlY2QtZDNkNy0yMTEyODk1Yjk4OGEiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiI4MWNkYTRiMC01ZTFlLTQwMTUtODI5MC01YTgyYTk1MGM5YjciLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiOTY4NWRjODktZjg4My0wZmFjLTJiYjItMTQ0M2RhMWY1OWEzIiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"7bd0949b-164f-4f72-878a-1eb14fd439d8","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"2264":{"type":"public","applicationId":2264,"appDefinitionId":"1522827f-c56c-a5c9-2ac9-00f9e6ae12d3","appDefinitionName":"Pricing Plans","instance":"DgU2oCy2dU8udKF3wYrSB4zAzeHLrqKNYkxYQ-Mr6KI.eyJpbnN0YW5jZUlkIjoiOGZlYmU3OTktOWYwZi00NDM4LTk1ZjQtZGUzMDExOTIxMGViIiwiYXBwRGVmSWQiOiIxNTIyODI3Zi1jNTZjLWE1YzktMmFjOS0wMGY5ZTZhZTEyZDMiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsImJpVG9rZW4iOiI2MmJlYWY4Yi03MWMzLTA0ZTYtMzljYy1kNGMyODQ1OTcwOTAiLCJzaXRlT3duZXJJZCI6ImI3NTcwMzJmLWExY2ItNGMxYS1iMjM3LWUxMGMwYmY0NjljOCJ9","instanceId":"8febe799-9f0f-4438-95f4-de30119210eb","sectionUrl":"https:\/\/apps.wix.com\/membership-app\/tpa","sectionMobileUrl":"https:\/\/apps.wix.com\/membership-app\/tpa","sectionPublished":true,"sectionMobilePublished":true,"sectionSeoEnabled":true,"sectionDefaultPage":"","sectionRefreshOnWidthChange":true,"widgets":{"15293875-09d7-6913-a093-084a9b6ae7f4":{"widgetUrl":"https:\/\/apps.wix.com\/membership-app\/tpa","widgetId":"15293875-09d7-6913-a093-084a9b6ae7f4","refreshOnWidthChange":true,"mobileUrl":"https:\/\/apps.wix.com\/membership-app\/tpa","appPage":{"id":"membership_plan_picker_tpa","name":"Plans & Pricing","defaultPage":"","hidden":false,"multiInstanceEnabled":false,"order":1,"indexable":true,"fullPage":false,"landingPageInMobile":false,"hideFromMenu":false},"published":true,"mobilePublished":true,"seoEnabled":false,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":true,"componentFields":{},"default":true}},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{"platform":{"editorScriptUrl":"https:\/\/static.parastorage.com\/services\/membership-tpa-script\/1.126.0\/membership-tpa-editor-script.js"}}},"28":{"type":"public","applicationId":28,"appDefinitionId":"1380b703-ce81-ff05-f115-39571d94dfcd","appDefinitionName":"Wix Stores","instance":"4REDSXHXvA2vyfHFkf-Nrirt_JVecMU0PitpG17E2q0.eyJpbnN0YW5jZUlkIjoiZWQ1Zjk3NjgtYzIwZC00YzcwLThmOWYtN2NjNTlmYmY3ZDExIiwiYXBwRGVmSWQiOiIxMzgwYjcwMy1jZTgxLWZmMDUtZjExNS0zOTU3MWQ5NGRmY2QiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiI2YjNhNjg5Ni0xYjc4LTRiYTctOWM1Mi01NzlhYzJhMmViYmEiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiMDAwYWRmN2EtMmNjMS0wY2FlLTIzYTctNzYzNzBhNzQxZDZhIiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"ed5f9768-c20d-4c70-8f9f-7cc59fbf7d11","sectionUrl":"https:\/\/ecom.wix.com\/storefront\/gallery","sectionMobileUrl":"https:\/\/ecom.wix.com\/storefront\/gallery","sectionPublished":true,"sectionMobilePublished":true,"sectionSeoEnabled":true,"sectionDefaultPage":"","sectionRefreshOnWidthChange":true,"widgets":{"1380bba0-253e-a800-a235-88821cf3f8a4":{"widgetUrl":"https:\/\/ecom.wix.com\/storefront\/gallery","widgetId":"1380bba0-253e-a800-a235-88821cf3f8a4","refreshOnWidthChange":true,"mobileUrl":"https:\/\/ecom.wix.com\/storefront\/gallery","appPage":{"id":"product_gallery","name":"Shop","defaultPage":"","hidden":false,"multiInstanceEnabled":true,"order":1,"indexable":true,"fullPage":false,"landingPageInMobile":false,"hideFromMenu":false},"published":true,"mobilePublished":true,"seoEnabled":true,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":false,"componentFields":{"useSsrSeo":true,"componentUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-gallery\/1.1277.0\/gallery.bundle.min.js","controllerUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-gallery\/1.1277.0\/galleryController.bundle.min.js","minHeightInMobile":340,"mobileSettingsEnabled":true},"default":true},"14e121c8-00a3-f7cc-6156-2c82a2ba8fcb":{"widgetUrl":"https:\/\/ecom.wix.com\/storefront\/order-history","widgetId":"14e121c8-00a3-f7cc-6156-2c82a2ba8fcb","refreshOnWidthChange":true,"mobileUrl":"https:\/\/ecom.wix.com\/storefront\/order-history","appPage":{"id":"order_history","name":"My Orders","defaultPage":"","hidden":true,"multiInstanceEnabled":false,"order":5,"indexable":false,"fullPage":false,"landingPageInMobile":false,"hideFromMenu":false},"published":true,"mobilePublished":true,"seoEnabled":false,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":true,"componentFields":{},"default":false},"1380bbc4-1485-9d44-4616-92e36b1ead6b":{"widgetUrl":"https:\/\/ecom.wix.com\/storefront\/cartwidget","widgetId":"1380bbc4-1485-9d44-4616-92e36b1ead6b","refreshOnWidthChange":true,"mobileUrl":"https:\/\/ecom.wix.com\/storefront\/cartwidget","published":true,"mobilePublished":true,"seoEnabled":true,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":false,"componentFields":{"componentUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-cart-icon\/1.678.0\/cartIcon.bundle.min.js","componentName":"cartWidget","controllerUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-cart-icon\/1.678.0\/cartIconController.bundle.min.js"},"tpaWidgetId":"shopping_cart_icon","default":false},"13a94f09-2766-3c40-4a32-8edb5acdd8bc":{"widgetUrl":"https:\/\/ecom.wix.com\/storefront\/product","widgetId":"13a94f09-2766-3c40-4a32-8edb5acdd8bc","refreshOnWidthChange":true,"mobileUrl":"https:\/\/ecom.wix.com\/storefront\/product","appPage":{"id":"product_page","name":"Product Page","defaultPage":"","hidden":true,"multiInstanceEnabled":false,"order":2,"indexable":true,"fullPage":false,"landingPageInMobile":false,"hideFromMenu":false},"published":true,"mobilePublished":true,"seoEnabled":true,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":false,"componentFields":{"useSsrSeo":true,"componentUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-product-page\/1.1355.0\/productPage.bundle.min.js","controllerUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-product-page\/1.1355.0\/productPageController.bundle.min.js"},"default":false},"14fd5970-8072-c276-1246-058b79e70c1a":{"widgetUrl":"https:\/\/ecom.wixapps.net\/storefront\/checkout","widgetId":"14fd5970-8072-c276-1246-058b79e70c1a","refreshOnWidthChange":true,"mobileUrl":"https:\/\/ecom.wixapps.net\/storefront\/checkout","appPage":{"id":"checkout","name":"Checkout","defaultPage":"","hidden":true,"multiInstanceEnabled":false,"order":6,"indexable":false,"fullPage":false,"landingPageInMobile":true,"hideFromMenu":true},"published":true,"mobilePublished":true,"seoEnabled":false,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":true,"componentFields":{"minHeightInMobile":480,"fullPageDesktopOnly":true},"default":false},"13ec3e79-e668-cc0c-2d48-e99d53a213dd":{"widgetUrl":"https:\/\/ecom.wix.com\/storefront\/product-widget-view","widgetId":"13ec3e79-e668-cc0c-2d48-e99d53a213dd","refreshOnWidthChange":true,"mobileUrl":"https:\/\/ecom.wix.com\/storefront\/product-widget-view","published":true,"mobilePublished":true,"seoEnabled":true,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":false,"componentFields":{"useSsrSeo":true,"componentUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-product-widget\/1.696.0\/productWidget.bundle.min.js","controllerUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-product-widget\/1.696.0\/productWidgetController.bundle.min.js","minHeightInMobile":354},"tpaWidgetId":"product_widget","default":false},"14666402-0bc7-b763-e875-e99840d131bd":{"widgetUrl":"https:\/\/ecom.wix.com\/storefront\/add-to-cart","widgetId":"14666402-0bc7-b763-e875-e99840d131bd","refreshOnWidthChange":true,"mobileUrl":"https:\/\/ecom.wix.com\/storefront\/add-to-cart","published":true,"mobilePublished":true,"seoEnabled":true,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":false,"componentFields":{"componentUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-add-to-cart\/1.295.0\/addToCart.bundle.min.js","controllerUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-add-to-cart\/1.295.0\/addToCartController.bundle.min.js"},"tpaWidgetId":"add_to_cart_button","default":false},"a63a5215-8aa6-42af-96b1-583bfd74cff5":{"widgetUrl":"https:\/\/ecom.wix.com\/storefront\/wishlist","widgetId":"a63a5215-8aa6-42af-96b1-583bfd74cff5","refreshOnWidthChange":true,"mobileUrl":"https:\/\/ecom.wix.com\/storefront\/wishlist","appPage":{"id":"wishlist","name":"My Wishlist","defaultPage":"","hidden":true,"multiInstanceEnabled":false,"order":7,"indexable":true,"fullPage":false,"landingPageInMobile":false,"hideFromMenu":false},"published":true,"mobilePublished":true,"seoEnabled":false,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":false,"componentFields":{"componentUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-wishlist\/1.484.0\/wishlist.bundle.min.js","controllerUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-wishlist\/1.484.0\/wishlistController.bundle.min.js"},"default":false},"1380bbab-4da3-36b0-efb4-2e0599971d14":{"widgetUrl":"https:\/\/ecom.wix.com\/storefront\/cart","widgetId":"1380bbab-4da3-36b0-efb4-2e0599971d14","refreshOnWidthChange":true,"mobileUrl":"https:\/\/ecom.wix.com\/storefront\/cart","appPage":{"id":"shopping_cart","name":"Cart Page","defaultPage":"","hidden":true,"multiInstanceEnabled":false,"order":3,"indexable":false,"fullPage":false,"landingPageInMobile":false,"hideFromMenu":false},"published":true,"mobilePublished":true,"seoEnabled":true,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":false,"componentFields":{},"default":false},"13afb094-84f9-739f-44fd-78d036adb028":{"widgetUrl":"https:\/\/ecom.wix.com\/storefront\/gallery","widgetId":"13afb094-84f9-739f-44fd-78d036adb028","refreshOnWidthChange":true,"mobileUrl":"https:\/\/ecom.wix.com\/storefront\/gallery","published":true,"mobilePublished":true,"seoEnabled":true,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":false,"componentFields":{"useSsrSeo":true,"componentUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-gallery\/1.1277.0\/gallery.bundle.min.js","controllerUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-gallery\/1.1277.0\/galleryController.bundle.min.js","mobileSettingsEnabled":true},"tpaWidgetId":"grid_gallery","default":false},"139a41fd-0b1d-975f-6f67-e8cbdf8ccc82":{"widgetUrl":"https:\/\/ecom.wix.com\/storefront\/minigallery","widgetId":"139a41fd-0b1d-975f-6f67-e8cbdf8ccc82","refreshOnWidthChange":true,"mobileUrl":"https:\/\/ecom.wix.com\/storefront\/minigallery","published":true,"mobilePublished":true,"seoEnabled":true,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":false,"componentFields":{"componentUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-gallery\/1.1277.0\/sliderGallery.bundle.min.js","controllerUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-gallery\/1.1277.0\/sliderGalleryController.bundle.min.js"},"tpaWidgetId":"slider_gallery","default":false},"1380bbb4-8df0-fd38-a235-88821cf3f8a4":{"widgetUrl":"https:\/\/ecom.wix.com\/storefront\/success","widgetId":"1380bbb4-8df0-fd38-a235-88821cf3f8a4","refreshOnWidthChange":true,"mobileUrl":"https:\/\/ecom.wix.com\/storefront\/success","appPage":{"id":"thank_you_page","name":"Thank You Page","defaultPage":"","hidden":true,"multiInstanceEnabled":false,"order":4,"indexable":false,"fullPage":false,"landingPageInMobile":false,"hideFromMenu":false},"published":true,"mobilePublished":true,"seoEnabled":true,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":false,"componentFields":{"controllerUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-worker\/1.1135.0\/thankYouPageController.bundle.min.js","iframeWithPlatform":true},"default":false}},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{"platform":{"baseUrls":{"galleryBaseUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-gallery\/1.1277.0\/","cartIconBaseUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-cart-icon\/1.678.0\/","addToCartBaseUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-add-to-cart\/1.295.0\/","productPageBaseUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-product-page\/1.1355.0\/","productWidgetBaseUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-product-widget\/1.696.0\/","wishlistBaseUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-wishlist\/1.484.0\/"},"editorScriptUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-worker\/1.1139.0\/editor.bundle.min.js","viewerScriptUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-worker\/1.1139.0\/viewerScript.bundle.min.js"}}},"21":{"type":"public","applicationId":21,"appDefinitionId":"14d7032a-0a65-5270-cca7-30f599708fed","appDefinitionName":"WixCoupons","instance":"5Dg40OULpAqXzFGa-XT-JlyL99-5WWGuRRhXG14IRjA.eyJpbnN0YW5jZUlkIjoiMzNiODI2NjEtZjVlZi00NGExLTllNWQtYWU4OTJiYjQzMjVjIiwiYXBwRGVmSWQiOiIxNGQ3MDMyYS0wYTY1LTUyNzAtY2NhNy0zMGY1OTk3MDhmZWQiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiJmZmQzMzFhMy1iY2FkLTQ2NWMtOTIzZC0xNzJmZmMxZjk5ZmIiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiZGVlZDZlNzMtMWIyMy0wNDdmLTMyNjUtYTQ3YmJlN2Y1MjI3Iiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"33b82661-f5ef-44a1-9e5d-ae892bb4325c","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{"nonDiscoverable":true}},"3546":{"type":"public","applicationId":3546,"appDefinitionId":"14ce28f7-7eb0-3745-22f8-074b0e2401fb","appDefinitionName":"Profile Card","instance":"nOoGH--bmI1fRuM_1MOAn1VXlntMyDuvdglCAVAaRuI.eyJpbnN0YW5jZUlkIjoiNjA0Zjc0MTMtZTc3Ni00YzBlLWJhMTgtOGNlNGJiZjhiZTljIiwiYXBwRGVmSWQiOiIxNGNlMjhmNy03ZWIwLTM3NDUtMjJmOC0wNzRiMGUyNDAxZmIiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsImJpVG9rZW4iOiI4ZDFhM2MwMS0wOWJhLTBjZDAtMTYyMC04NjE2MmUzM2RlZTciLCJzaXRlT3duZXJJZCI6ImI3NTcwMzJmLWExY2ItNGMxYS1iMjM3LWUxMGMwYmY0NjljOCJ9","instanceId":"604f7413-e776-4c0e-ba18-8ce4bbf8be9c","appWorkerUrl":"https:\/\/apps.wix.com\/members-area\/app-worker","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{"14cefc05-d163-dbb7-e4ec-cd4f2c4d6ddd":{"widgetUrl":"https:\/\/apps.wix.com\/profile-card-tpa\/app\/profile","widgetId":"14cefc05-d163-dbb7-e4ec-cd4f2c4d6ddd","refreshOnWidthChange":true,"mobileUrl":"https:\/\/apps.wix.com\/profile-card-tpa\/app\/profile","published":true,"mobilePublished":true,"seoEnabled":false,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":true,"componentFields":{},"tpaWidgetId":"profile","default":true}},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":false,"permissions":{"revoked":false},"appFields":{"platform":{"editorScriptUrl":"https:\/\/static.parastorage.com\/services\/profile-card-tpa-editor-script\/1.42.0\/editorScript.bundle.min.js"}}},"9":{"type":"public","applicationId":9,"appDefinitionId":"1480c568-5cbd-9392-5604-1148f5faffa0","appDefinitionName":"Get Found on Google","instance":"0NsPhDpK2-U47v5D5fgF1SiSelFsF-kVi37BusStQws.eyJpbnN0YW5jZUlkIjoiNDNmNTFjYzAtYTkwYi00NzI0LTlkMmQtMDhmYjcyZjczYTQ5IiwiYXBwRGVmSWQiOiIxNDgwYzU2OC01Y2JkLTkzOTItNTYwNC0xMTQ4ZjVmYWZmYTAiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiIxY2JhZDg2MS1jNzA0LTQ2YmMtYmY0YS1jOWI4M2ZhOWNlZjkiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiYWVhMDU0ZDItNDdjNy0wN2ZhLTMxMTUtMDIwOWU3M2M1YTMyIiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"43f51cc0-a90b-4724-9d2d-08fb72f73a49","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"1552":{"type":"public","applicationId":1552,"appDefinitionId":"14517e1a-3ff0-af98-408e-2bd6953c36a2","appDefinitionName":"Wix Chat","instance":"ZcCke3SdKXwdsbjBcpUi6E7Hv9lzJOEEIDibP6UcDDM.eyJpbnN0YW5jZUlkIjoiMmE2MzE3OTItMTA2MC00NTFiLWJjMjMtMDlkZWYzZjBiZWU5IiwiYXBwRGVmSWQiOiIxNDUxN2UxYS0zZmYwLWFmOTgtNDA4ZS0yYmQ2OTUzYzM2YTIiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsImJpVG9rZW4iOiJjNzM2NWY4MC1mZWFjLTA1YzUtMTAxYi0wMzJjNjYzYmRlOTIiLCJzaXRlT3duZXJJZCI6ImI3NTcwMzJmLWExY2ItNGMxYS1iMjM3LWUxMGMwYmY0NjljOCJ9","instanceId":"2a631792-1060-451b-bc23-09def3f0bee9","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{"14517f3f-ffc5-eced-f592-980aaa0bbb5c":{"widgetUrl":"https:\/\/engage.wixapps.net\/chat-widget-server\/renderChatWidget\/index","widgetId":"14517f3f-ffc5-eced-f592-980aaa0bbb5c","refreshOnWidthChange":true,"gluedOptions":{"placement":"BOTTOM_RIGHT","verticalMargin":0.0,"horizontalMargin":0.0},"published":true,"mobilePublished":true,"seoEnabled":true,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":false,"componentFields":{"iframeWithPlatform":true},"tpaWidgetId":"wix_visitors","default":true}},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{"platform":{"viewerScriptUrl":"https:\/\/static.parastorage.com\/services\/chat-worker\/1.380.0\/viewer-script.bundle.min.js","optionalApplication":true},"premiumBundle":{"parentAppId":"ee21fe60-48c5-45e9-95f4-6ca8f9b1c9d9","parentAppSlug":"ee21fe60-48c5-45e9-95f4-6ca8f9b1c9d9"},"mostPopularPackage":"Sales","featuresForNewPackagePicker":[{"forPackages":[{"value":"50","packageId":"Professional"},{"value":"150","packageId":"Sales"},{"value":"Unlimited","packageId":"Teams"}]},{"forPackages":[{"value":"true","packageId":"Professional"},{"value":"true","packageId":"Sales"},{"value":"true","packageId":"Teams"}]},{"forPackages":[{"value":"true","packageId":"Professional"},{"value":"true","packageId":"Sales"},{"value":"true","packageId":"Teams"}]},{"forPackages":[{"value":"true","packageId":"Professional"},{"value":"true","packageId":"Sales"},{"value":"true","packageId":"Teams"}]},{"forPackages":[{"value":"true","packageId":"Professional"},{"value":"true","packageId":"Sales"},{"value":"true","packageId":"Teams"}]},{"forPackages":[{"value":"true","packageId":"Professional"},{"value":"true","packageId":"Sales"},{"value":"true","packageId":"Teams"}]},{"forPackages":[{"value":"true","packageId":"Professional"},{"value":"true","packageId":"Sales"},{"value":"true","packageId":"Teams"}]},{"forPackages":[{"value":"true","packageId":"Professional"},{"value":"true","packageId":"Sales"},{"value":"true","packageId":"Teams"}]},{"forPackages":[{"value":"true","packageId":"Sales"},{"value":"true","packageId":"Teams"}]},{"forPackages":[{"value":"true","packageId":"Teams"}]}]}},"13":{"type":"sitemembers","applicationId":13,"collectionType":"Open","collectionFormFace":"Register","collectionExposure":"Public","smcollectionId":"edd55dd0-5a73-4b5b-ae75-ca34ac3b7b13"},"22":{"type":"public","applicationId":22,"appDefinitionId":"13aa9735-aa50-4bdb-877c-0bb46804bd71","appDefinitionName":"Promote SEO Patterns","instance":"cUZvLsym05eFy2yJK_0fDaIVOXYwb5TvOR1p1i3QEpQ.eyJpbnN0YW5jZUlkIjoiYzA4MGQyOWQtYTEwZi00MWE3LTlmMGQtN2FkOGQzMWU4OWNlIiwiYXBwRGVmSWQiOiIxM2FhOTczNS1hYTUwLTRiZGItODc3Yy0wYmI0NjgwNGJkNzEiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiJkOGNhODY5OS02YzVjLTQ5NTQtYWY5MS00ZWU3NDcxMjIyYzIiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiMmRkNTlhOGYtNGZjMy0wMTc5LTMzMzUtNzAyYTQ2ZDVlOWI1Iiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"c080d29d-a10f-41a7-9f0d-7ad8d31e89ce","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"27":{"type":"onboarding","applicationId":27,"storyId":"0cb502c0-eb0a-41d2-829c-fb2a299aac37","inUse":false},"12":{"type":"public","applicationId":12,"appDefinitionId":"146c0d71-352e-4464-9a03-2e868aabe7b9","appDefinitionName":"Ascend Tasks","instance":"MjwLPKBlgaRjH9Dfwe9HuI1MnRUATcgazkX9Xs4cQDA.eyJpbnN0YW5jZUlkIjoiNWUwOTkwYzAtNDg3NS00MzU5LWJhMjUtNjJlNDNlZDMyMDQ3IiwiYXBwRGVmSWQiOiIxNDZjMGQ3MS0zNTJlLTQ0NjQtOWEwMy0yZTg2OGFhYmU3YjkiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiI4YTM0NmMyZi0yMDhjLTRkMzgtYTNkZS1iNmQzMjUwN2ZhNDAiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiYjM1Y2Q4ZDItYTZiOS0wMzg3LTE2MWQtNjgxNmFiMTg0MDNjIiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"5e0990c0-4875-4359-ba25-62e43ed32047","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"7":{"type":"public","applicationId":7,"appDefinitionId":"55cd9036-36bb-480b-8ddc-afda3cb2eb8d","appDefinitionName":"PriceQuotes","instance":"M2qXCmf7njJU_wUjCpH-GbrJdfr63oLZTiifjgB_gzU.eyJpbnN0YW5jZUlkIjoiNWE0OGI0ODItN2U1Ni00MDZhLTk4MGUtNTM5NDEwOTdkOTE3IiwiYXBwRGVmSWQiOiI1NWNkOTAzNi0zNmJiLTQ4MGItOGRkYy1hZmRhM2NiMmViOGQiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiJmNzBhNGQ1OC03ZWVlLTQ2NTItYjYyYS00YWU2ODExZGFmYzQiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiYjcxZGZjOTAtOTA5YS0wMGI0LTM0MzYtNTk2Njg1NWNiOTZjIiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"5a48b482-7e56-406a-980e-53941097d917","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"-666":{"type":"metasite","metaSiteId":"ed554812-eecc-40de-ac38-0af295cb607b","appDefId":"22bef345-3c5b-4c18-b782-74d4085112ff","instance":"40YXkMtRlmPS5-g4RfT6NX4baQ4XbMDFKrcAcSlO8kU.eyJpbnN0YW5jZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwiYXBwRGVmSWQiOiIyMmJlZjM0NS0zYzViLTRjMTgtYjc4Mi03NGQ0MDg1MTEyZmYiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsInNpdGVPd25lcklkIjoiYjc1NzAzMmYtYTFjYi00YzFhLWIyMzctZTEwYzBiZjQ2OWM4In0","appDefinitionId":"22bef345-3c5b-4c18-b782-74d4085112ff","applicationId":-666},"3":{"type":"public","applicationId":3,"appDefinitionId":"14bca956-e09f-f4d6-14d7-466cb3f09103","appDefinitionName":"Wix Cashier","instance":"fdsE6q-Bgz39qrgwAm7131FSO3SCt7b-aVKgi4sfyI0.eyJpbnN0YW5jZUlkIjoiZDM5ZTg1YjktYmE0Ni00NGUyLWFjZWEtM2ExNDBhYWQzMjAzIiwiYXBwRGVmSWQiOiIxNGJjYTk1Ni1lMDlmLWY0ZDYtMTRkNy00NjZjYjNmMDkxMDMiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiI0Mzc2ZDQxMy0yODY3LTQ2NjItOGIwZC0xODM3NzFiNTdhNDAiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiM2VjYmNkYWItNTQ4YS0wNDNjLTAwZDItMzBlNjlmNjY1Mjc4Iiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"d39e85b9-ba46-44e2-acea-3a140aad3203","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{"platform":{"editorScriptUrl":"https:\/\/cashier.wixapps.net\/cashier-settings-server\/cashier-site-worker\/editor-script.js"}}},"18":{"type":"public","applicationId":18,"appDefinitionId":"ea2821fc-7d97-40a9-9f75-772f29178430","appDefinitionName":"Workflows","instance":"WVw-5fn8gs-Q5T27yK9LoHZDjkC_VzpadrL9HPiFtAI.eyJpbnN0YW5jZUlkIjoiZDJlMjJiNDEtM2Y3Yy00Mzk5LWI0ZTMtM2JkNmFiM2ZlYmQxIiwiYXBwRGVmSWQiOiJlYTI4MjFmYy03ZDk3LTQwYTktOWY3NS03NzJmMjkxNzg0MzAiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiIwMzRmOGU1Yy1jMmY1LTQ3YWEtYWE3Yi1mYTBlMWVjZTdkYzEiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiM2ZiNzYzNTMtZDFiMC0wMzQ3LTE4ZGItMzEyNDNlZjQ4YmFhIiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"d2e22b41-3f7c-4399-b4e3-3bd6ab3febd1","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"16":{"type":"public","applicationId":16,"appDefinitionId":"e3118e0a-b1c1-4e1d-b67d-ddf0cb92309b","appDefinitionName":"Promote VideoMaker Home","instance":"23kbg-zaPliIM0WC4Nd0pj8aBGxvdLn_Dz6NM-VzLg8.eyJpbnN0YW5jZUlkIjoiNmJlYzA5YWItZmY3MS00YjZkLTk4ZDEtYmRkNWE4YzhiYTFmIiwiYXBwRGVmSWQiOiJlMzExOGUwYS1iMWMxLTRlMWQtYjY3ZC1kZGYwY2I5MjMwOWIiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiIyZDM4M2M4Ni0yY2RjLTQxNGEtOTA1Ny0xZWUyYjMwMDg1ZDQiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiODZiOTQxYjktMTFiZC0wYmIzLTM0ZTktYjcyNzNkMDNkYTY0Iiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"6bec09ab-ff71-4b6d-98d1-bdd5a8c8ba1f","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"11":{"type":"public","applicationId":11,"appDefinitionId":"135c3d92-0fea-1f9d-2ba5-2a1dfb04297e","appDefinitionName":"Email Marketing","instance":"dcDA6A9xdkUu0YA0x-cea2ovv8Nzo_SC4hQSWPG99uI.eyJpbnN0YW5jZUlkIjoiMzQ4MTRkNjUtODczNS00NDA0LTk5OGUtMWM4Mjc1Y2QzNjM2IiwiYXBwRGVmSWQiOiIxMzVjM2Q5Mi0wZmVhLTFmOWQtMmJhNS0yYTFkZmIwNDI5N2UiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiJiY2NkNTk0Mi1jZjk1LTQ5N2YtODNmYy1jOWQ1NjlkMGFkODMiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiZDlkNDA1NzctNjlmOS0wNGRhLTM1YjYtMTY3MGUwMDY1NjRkIiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"34814d65-8735-4404-998e-1c8275cd3636","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{"141995eb-c700-8487-6366-a482f7432e2b":{"widgetUrl":"https:\/\/so-feed.codev.wixapps.net\/widget","widgetId":"141995eb-c700-8487-6366-a482f7432e2b","refreshOnWidthChange":true,"mobileUrl":"https:\/\/so-feed.codev.wixapps.net\/widget","published":true,"mobilePublished":true,"seoEnabled":true,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":false,"componentFields":{},"tpaWidgetId":"shoutout_feed","default":true}},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{"premiumBundle":{"parentAppId":"ee21fe60-48c5-45e9-95f4-6ca8f9b1c9d9","parentAppSlug":"ee21fe60-48c5-45e9-95f4-6ca8f9b1c9d9"}}},"26":{"type":"public","applicationId":26,"appDefinitionId":"4b10fcce-732d-4be3-9d46-801d271acda9","appDefinitionName":"Secrets Vault","instance":"HH4HLEgInzE9vrSiZjsC5JvDJs1myACxTXh-7mW3Kyg.eyJpbnN0YW5jZUlkIjoiYzAxYTZhZmItNGZiNy00ODNjLTg4YmItODM0MDJkNTlhODJmIiwiYXBwRGVmSWQiOiI0YjEwZmNjZS03MzJkLTRiZTMtOWQ0Ni04MDFkMjcxYWNkYTkiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiJmOWFiMzE4ZS01MWVjLTQxNzAtYmQyMS1iOGYwMDkzMTQwMDIiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiMmQ0ZjIyZTktYTE3Yi0wOGUyLTI0ODMtODliMmI4OTJjODU0Iiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"c01a6afb-4fb7-483c-88bb-83402d59a82f","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"23":{"type":"public","applicationId":23,"appDefinitionId":"d70b68e2-8d77-4e0c-9c00-c292d6e0025e","appDefinitionName":"Promote SEO Tools","instance":"vLN0P5suwvgVImFFh3T2GmSfErDiZlsr-FSquuRoWIE.eyJpbnN0YW5jZUlkIjoiMGUwNmViYWYtZGRiMi00NDM4LTg5MWEtNjZmNzQ3ZDZlMGQzIiwiYXBwRGVmSWQiOiJkNzBiNjhlMi04ZDc3LTRlMGMtOWMwMC1jMjkyZDZlMDAyNWUiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiJkZjYxZmYzOC00OGZjLTQyMjYtYTY2MS01MTY1OWVhNzQ0YmYiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiZTM1M2EzYmQtMzM3ZS0wNGU2LTI1MjItNmMwNWQyMWQ4MGE4Iiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"0e06ebaf-ddb2-4438-891a-66f747d6e0d3","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"8":{"type":"public","applicationId":8,"appDefinitionId":"f123e8f1-4350-4c9b-b269-04adfadda977","appDefinitionName":"Promote Home","instance":"k-iiMqeIjjHNoiUV5_IN0ieYh_99cuRmE4BtaDnZIR0.eyJpbnN0YW5jZUlkIjoiYjNiNzcxYjYtMjdmMC00MWVmLTlmZTgtY2M0ZGUwMjFhNDE2IiwiYXBwRGVmSWQiOiJmMTIzZThmMS00MzUwLTRjOWItYjI2OS0wNGFkZmFkZGE5NzciLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiIxOWQ5NGYyMS02OWFiLTRiMjQtODMxYS00ZGY1NzdiNTc3ZTMiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiNWVlMjM5YTQtYzkzYy0wMTMxLTMzZDAtYzZiZjc1ZWFjNDZkIiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"b3b771b6-27f0-41ef-9fe8-cc4de021a416","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"30":{"type":"public","applicationId":30,"appDefinitionId":"13c1402c-27f2-d4ab-7463-ee7c89e07578","appDefinitionName":"Wix Restaurants Menus","instance":"CDfDBb--0xepL8ceUiDj2_M5eZN-fxdkRY-eSQne0D0.eyJpbnN0YW5jZUlkIjoiYWU2YmYwM2ItMTYzZC00ZjJjLWExNTktZGY3NTMxMWM4MDMwIiwiYXBwRGVmSWQiOiIxM2MxNDAyYy0yN2YyLWQ0YWItNzQ2My1lZTdjODllMDc1NzgiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiJjNjg3Yjk3Ny1iMzMxLTRmMmQtOWVjZS0xZGU4YjA4NmUxNDUiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiNDMzZWI4MjktZjhmMS0wZmYyLTBkNjEtZDU4N2E0ZDdlMDRiIiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"ae6bf03b-163d-4f2c-a159-df75311c8030","sectionUrl":"https:\/\/apps.wixrestaurants.com\/?type=wixmenus.client","sectionMobileUrl":"https:\/\/apps.wixrestaurants.com\/?type=wixmenus.client","sectionPublished":true,"sectionMobilePublished":true,"sectionSeoEnabled":true,"sectionDefaultPage":"","sectionRefreshOnWidthChange":true,"widgets":{"13c1404b-b03b-ee00-84c1-51ae431a537f":{"widgetUrl":"https:\/\/apps.wixrestaurants.com\/?type=wixmenus.client","widgetId":"13c1404b-b03b-ee00-84c1-51ae431a537f","refreshOnWidthChange":true,"mobileUrl":"https:\/\/apps.wixrestaurants.com\/?type=wixmenus.client","appPage":{"id":"menu","name":"Menus","defaultPage":"","hidden":false,"multiInstanceEnabled":true,"order":1,"indexable":true,"fullPage":false,"landingPageInMobile":false,"hideFromMenu":false},"published":true,"mobilePublished":true,"seoEnabled":true,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":false,"componentFields":{},"default":true}},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":false,"permissions":{"revoked":true},"appFields":{}},"19":{"type":"public","applicationId":19,"appDefinitionId":"9bead16f-1c73-4cda-b6c4-28cff46988db","appDefinitionName":"Facebook Ads","instance":"LMBQADkp2V916ORSEliLtH-_1skG0f3sT5dc75Vuhfo.eyJpbnN0YW5jZUlkIjoiMGRmY2MxZmMtZjBlMi00Y2U5LWFmZmYtZDA3Nzg2YmM4NmU3IiwiYXBwRGVmSWQiOiI5YmVhZDE2Zi0xYzczLTRjZGEtYjZjNC0yOGNmZjQ2OTg4ZGIiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiJhZGNhMTk0OC04NDc1LTQzYTctODZiZC1hZGZlY2E5ZmZjNTgiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiZTBhOTg5ZWUtMWUyZS0wYzM3LTAzYzctZGE4NTEzNzdlNjljIiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"0dfcc1fc-f0e2-4ce9-afff-d07786bc86e7","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"4":{"type":"public","applicationId":4,"appDefinitionId":"141fbfae-511e-6817-c9f0-48993a7547d1","appDefinitionName":"Inbox","instance":"C4boIM_5Ak9ueHqfiDjVlVgpiAXTbADRHCZwUAoLsso.eyJpbnN0YW5jZUlkIjoiYzFjNTIxNzctZmUxYS00NjEyLTllOTItZjI2ODk3YmU0NTUyIiwiYXBwRGVmSWQiOiIxNDFmYmZhZS01MTFlLTY4MTctYzlmMC00ODk5M2E3NTQ3ZDEiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsIm9yaWdpbkluc3RhbmNlSWQiOiI0MDlkYjkwZC03OTBjLTRmZTktYmIxOC1kYjdhOTY4ZGU4ODkiLCJhaWQiOiI3ODYzZjgwNy1iMWYwLTRlZWUtYmQzYy00NjA0Yzc2ZWM4ZGQiLCJiaVRva2VuIjoiMmM5MDY5NjUtMTBkNi0wNmNjLTMyYWEtZjg5YTAyNzUyNTI5Iiwic2l0ZU93bmVySWQiOiJiNzU3MDMyZi1hMWNiLTRjMWEtYjIzNy1lMTBjMGJmNDY5YzgifQ","instanceId":"c1c52177-fe1a-4612-9e92-f26897be4552","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":true,"permissions":{"revoked":false},"appFields":{}},"4350":{"type":"public","applicationId":4350,"appDefinitionId":"4aebd0cb-fbdb-4da7-b5d1-d05660a30172","appDefinitionName":"My Wallet","instance":"l2aG5XMbf8vmvudkvG6gpepdG8KVOpSNcnYvLAq2wTU.eyJpbnN0YW5jZUlkIjoiYzQyZTNkNjMtYzMyZS00NmQyLTg2NDYtZWIwZGY2ODI3NmVhIiwiYXBwRGVmSWQiOiI0YWViZDBjYi1mYmRiLTRkYTctYjVkMS1kMDU2NjBhMzAxNzIiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsImJpVG9rZW4iOiIyOTdiNzU3MS0yZGUyLTA2MGMtMmE3ZS1lMWZmNjM0OTE2OTEiLCJzaXRlT3duZXJJZCI6ImI3NTcwMzJmLWExY2ItNGMxYS1iMjM3LWUxMGMwYmY0NjljOCJ9","instanceId":"c42e3d63-c32e-46d2-8646-eb0df68276ea","sectionUrl":"https:\/\/cashier.wixapps.net\/wallet","sectionMobileUrl":"https:\/\/cashier.wixapps.net\/wallet","sectionPublished":true,"sectionMobilePublished":true,"sectionSeoEnabled":false,"sectionDefaultPage":"","sectionRefreshOnWidthChange":true,"widgets":{"6467c15e-af3c-4e8d-b167-41bfb8efc32a":{"widgetUrl":"https:\/\/cashier.wixapps.net\/wallet","widgetId":"6467c15e-af3c-4e8d-b167-41bfb8efc32a","refreshOnWidthChange":true,"mobileUrl":"https:\/\/cashier.wixapps.net\/wallet","appPage":{"id":"my_wallet","name":"My Wallet","defaultPage":"","hidden":false,"multiInstanceEnabled":false,"order":1,"indexable":true,"fullPage":false,"landingPageInMobile":false,"hideFromMenu":false},"published":true,"mobilePublished":true,"seoEnabled":false,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":true,"componentFields":{},"default":true}},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":false,"permissions":{"revoked":false},"appFields":{}},"3035":{"type":"public","applicationId":3035,"appDefinitionId":"14cc59bc-f0b7-15b8-e1c7-89ce41d0e0c9","appDefinitionName":"Member's Area","instance":"Ybs2OO9RmIX2iZeNCqmCQUw1N0ATFRBQkh3zG-n6xvc.eyJpbnN0YW5jZUlkIjoiODQ1ZDE5ZmUtYmI5NS00NjE4LWE4YjgtOGE2YmM0MzYyZGZiIiwiYXBwRGVmSWQiOiIxNGNjNTliYy1mMGI3LTE1YjgtZTFjNy04OWNlNDFkMGUwYzkiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsImJpVG9rZW4iOiI2OTA4NTFlYy01NTU5LTA2YzYtMDQ4MC04MDk5NTFmZDRkODAiLCJzaXRlT3duZXJJZCI6ImI3NTcwMzJmLWExY2ItNGMxYS1iMjM3LWUxMGMwYmY0NjljOCJ9","instanceId":"845d19fe-bb95-4618-a8b8-8a6bc4362dfb","sectionPublished":true,"sectionMobilePublished":false,"sectionSeoEnabled":true,"widgets":{"14cc6044-6c73-4d1b-acfd-d27ebccaaaaf":{"widgetUrl":"https:\/\/www.wix.com\/","widgetId":"14cc6044-6c73-4d1b-acfd-d27ebccaaaaf","refreshOnWidthChange":true,"published":true,"mobilePublished":true,"seoEnabled":false,"preFetch":false,"shouldBeStretchedByDefault":false,"shouldBeStretchedByDefaultMobile":false,"componentFields":{},"tpaWidgetId":"santa_members","default":true}},"appRequirements":{"requireSiteMembers":false},"isWixTPA":true,"installedAtDashboard":false,"permissions":{"revoked":false},"appFields":{"platform":{"editorScriptUrl":"https:\/\/static.parastorage.com\/services\/santa-members-editor-app\/1.763.0\/editorAppModule.bundle.min.js","viewerScriptUrl":"https:\/\/static.parastorage.com\/services\/santa-members-viewer-app\/1.505.0\/app.bundle.min.js","routerServiceUrl":"\/_api\/santa-members-server"}}}},"premiumFeatures":[],"geo":"BRA","languageCode":"pt","locale":"pt-br","previewMode":false,"userId":"b757032f-a1cb-4c1a-b237-e10c0bf469c8","siteMetaData":{"preloader":{"uri":"","enabled":false},"adaptiveMobileOn":true,"quickActions":{"socialLinks":[],"colorScheme":"dark","configuration":{"quickActionsMenuEnabled":false,"navigationMenuEnabled":true,"phoneEnabled":false,"emailEnabled":false,"addressEnabled":false,"socialLinksEnabled":false}},"contactInfo":{"companyName":"","phone":"","fax":"","email":"","address":""},"renderHints":{"containsTPA":true,"isMeshReady":true,"containsAppPart":false,"containsAppPart2":false,"componentsCount":{"wysiwyg.viewer.components.QuickActionBar":1,"wysiwyg.viewer.components.HeaderContainer":1,"wysiwyg.viewer.components.FiveGridLine":1,"wysiwyg.viewer.components.Column":17,"wysiwyg.viewer.components.LoginSocialBar":1,"tpa.viewer.components.StripSlideshow":1,"wysiwyg.viewer.components.menus.DropDownMenu":1,"wysiwyg.viewer.components.LinkBar":1,"wysiwyg.viewer.components.StripColumnsContainer":15,"mobile.core.components.Page":11,"wysiwyg.viewer.components.SiteRegionContainer":1,"wysiwyg.viewer.components.PagesContainer":1,"wysiwyg.viewer.components.tpapps.TPAMultiSection":5,"wysiwyg.viewer.components.tpapps.TPAWidget":4,"wysiwyg.viewer.components.WPhoto":1,"wysiwyg.viewer.components.WRichText":6,"wysiwyg.common.components.anchor.viewer.Anchor":8,"wysiwyg.viewer.components.tpapps.TPAGluedWidget":1,"wysiwyg.viewer.components.mobile.TinyMenu":1,"wysiwyg.viewer.components.PageGroup":1,"wysiwyg.viewer.components.FooterContainer":1,"wysiwyg.viewer.components.tpapps.TPASection":5,"wysiwyg.common.components.verticalmenu.viewer.VerticalMenu":1,"platform.components.AppController":1},"applications":{"4aebd0cb-fbdb-4da7-b5d1-d05660a30172":{"widgetsCount":{"6467c15e-af3c-4e8d-b167-41bfb8efc32a":1}},"1505b775-e885-eb1b-b665-1e485d9bf90e":{"widgetsCount":{"151290e1-62a2-0775-6fbc-02182fad5dec":1}},"14cc59bc-f0b7-15b8-e1c7-89ce41d0e0c9":{"controllersCount":{"members":1}},"1522827f-c56c-a5c9-2ac9-00f9e6ae12d3":{"widgetsCount":{"15293875-09d7-6913-a093-084a9b6ae7f4":1}},"14cffd81-5215-0a7f-22f8-074b0e2401fb":{"widgetsCount":{"14dd1af6-3e02-63db-0ef2-72fbc7cc3136":1}},"1375baa8-8eca-5659-ce9d-455b2009250d":{"widgetsCount":{"1375babd-6f2b-87ed-ff19-5778602c8b86":1}},"14517e1a-3ff0-af98-408e-2bd6953c36a2":{"widgetsCount":{"14517f3f-ffc5-eced-f592-980aaa0bbb5c":1}},"1380b703-ce81-ff05-f115-39571d94dfcd":{"widgetsCount":{"1380bbb4-8df0-fd38-a235-88821cf3f8a4":1,"139a41fd-0b1d-975f-6f67-e8cbdf8ccc82":1,"14fd5970-8072-c276-1246-058b79e70c1a":1,"13a94f09-2766-3c40-4a32-8edb5acdd8bc":1,"1380bbc4-1485-9d44-4616-92e36b1ead6b":1,"1380bbab-4da3-36b0-efb4-2e0599971d14":1,"14e121c8-00a3-f7cc-6156-2c82a2ba8fcb":1,"1380bba0-253e-a800-a235-88821cf3f8a4":1}},"14ce28f7-7eb0-3745-22f8-074b0e2401fb":{"widgetsCount":{"14cefc05-d163-dbb7-e4ec-cd4f2c4d6ddd":1}}},"containsInteractions":false,"containsBPVariantsData":false}},"runningExperiments":{"bv_dynamicModelRequest":"new","headerMenuInertContent":"old","sv_includeRavenInPreview":"new","moveCustomStyleFromMasterPage":"500","helveticaCssInRenderer":"new","bv_removeDollarWFromSelf":"new","sv_earlyCloseWelcome":"new","dm_publishByPermissionsNotOwner":"new","bv_add_ssr_overrides":"new","removeBadlyDuplicatedPages":"new","sv_autoSaveNoMobileMerge":"new","sv_ampLinkTag":"new","bv_wixProGallery":"true","sv_ssrNoPagesData":"new","sv_twitterMetaTags":"new","sv_addPropsToHostInNativeComponent":"new","addBlackboxPerf":"new","remove_dollar_w_from_self":"new","sv_moveWixCodeToViewerApp":"new","sv_UploadButtonFilenameHover":"old","bv_removeOverflowOoi":"new","se_santaMembers":"new","platformPrefetchEditorScripts":"new","sv_UploadButtonValidateBeforeUpload":"true","bv_copyToClipboardWrapingFix":"new","sv_UploadButtonClientSideValidation":"true","bv_remove_add_chat_viewer_fixer":"new","bv_noopify_ssr_platform_timers":"new","bv_wixImage":"new","bv_cleanStructure":"new","sv_blogSocialCounters":"new","bv_preconnectSiteAssets":"new","bv_biLoggerUpgrade":"new","sv_mobileMembersAreaHorizontalMenu":"true","sv_meshLayout":"new","bv_scrollEffectsFixer":"new","allow_full_screen_on_mobile_devices":"new","bv_consentPolicy":"new","bv_dataFixersFromSiteAssetsVersions":"new","sv_add_item_height_matrix_gallery":"new","ds_useNewWixDataSchemasClient":"new","bv_responsiveFreemiumBanner":"new","bv_editorxUrlFallback":"new","bv_masterPageDomOrder":"new","bv_wixcode_realtime_namespace":"new","sv_multilingualSubDomains":"new","bv_fixSantaLegacyErrorResponse":"new","bv_footerHideOverflow":"new","bv_accessibilityMobileMenuArrowFix":"old","ds_preSaveAddAppInTemplateRightBeforeFirstSave":"old","bv_multilingualAutoRedirect":"new","wixCodeNoIframe":"new","bv_getSiteMapRespectsMenuSets":"old","extractPageRefsOnSave":"new","bv_removeQueryParams":"new","sv_tpaAddChatApp":"new","sv_restoreAutosaveWhenMobileFails":"new","bv_wixImagePhaseTwo":"new","reportBiErrorWhenAddingCompWithCustomeStyleId":"new","dm_updateGarbageCollectorFixer":"new","sv_fasterPagesDataOnLoad":"new","displayWixAdsNewVersion":"new","sv_bookingsFES":"new","sv_fixMobileTapDelay":"new","sv_patchDataDisablesMobileHintsInit":"new","oneAppWixAds":"true","bv_siteMembersMultilingual":"new","bv_restoreScroll":"new","se_siteMembersMultilingual":"new","sv_expireAppsInstances":"new","bv_greensock3":"new","bv_usePlatformAppMetaData":"new","bv_internalStyleForRotated":"new","bv_wixVideo":"new","bv_mediaIdInUploadButton":"new","sv_reparentMobileSOAP":"new","bv_coBrandingBanner":"new","bv_viewerCompIdInIframe":"new","ds_thunderboltNewRenderHints":"new","specs.wus.useNewDropdown":"false","sv_meshcors":"new","fontCssInRenderer":"new","se_lightBoxMobileDesktop":"new"},"urlFormatModel":{"format":"slash","forbiddenPageUriSEOs":["app","apps","_api","robots.txt","sitemap.xml","feed.xml","sites"],"pageIdToResolvedUriSEO":{}},"passwordProtectedPages":[],"useSandboxInHTMLComp":true,"routers":{"configMap":{"routers-kdhjontm":{"prefix":"account","appDefinitionId":"14cc59bc-f0b7-15b8-e1c7-89ce41d0e0c9","config":"{\"type\":\"private\",\"patterns\":{\"\/my-account\":{\"socialHome\":false,\"appData\":{\"appDefinitionId\":\"14cffd81-5215-0a7f-22f8-074b0e2401fb\",\"appPageId\":\"member_info\",\"menuOrder\":3,\"visibleForRoles\":[]},\"page\":\"5f3eb012-0672-47ef-947a-bbe93334a108\",\"seoData\":{\"title\":\"Minha conta\",\"description\":\"\",\"keywords\":\"\",\"noIndex\":\"true\"},\"title\":\"Minha conta\"},\"\/my-orders\":{\"socialHome\":false,\"appData\":{\"appDefinitionId\":\"1380b703-ce81-ff05-f115-39571d94dfcd\",\"appPageId\":\"order_history\",\"menuOrder\":2,\"visibleForRoles\":[]},\"page\":\"a0327473-b24d-47b8-98f3-751f29d0e0db\",\"seoData\":{\"title\":\"Meus pedidos\",\"description\":\"\",\"keywords\":\"\",\"noIndex\":\"true\"},\"title\":\"Meus pedidos\"},\"\/my-addresses\":{\"socialHome\":false,\"appData\":{\"appDefinitionId\":\"1505b775-e885-eb1b-b665-1e485d9bf90e\",\"appPageId\":\"my_addresses\",\"menuOrder\":2,\"visibleForRoles\":[]},\"page\":\"19a4d980-e40c-458f-8064-18b82a216740\",\"seoData\":{\"title\":\"Meus endereços\",\"description\":\"\",\"keywords\":\"\",\"noIndex\":\"true\"},\"title\":\"Meus endereços\"},\"\/my-wallet\":{\"socialHome\":false,\"appData\":{\"appDefinitionId\":\"4aebd0cb-fbdb-4da7-b5d1-d05660a30172\",\"appPageId\":\"my_wallet\",\"menuOrder\":2,\"visibleForRoles\":[]},\"page\":\"4fe3e580-ee49-4376-8f58-085266aad475\",\"seoData\":{\"title\":\"Minha carteira\",\"description\":\"\",\"keywords\":\"\",\"noIndex\":\"true\"},\"title\":\"Minha carteira\"}}}","group":"members","pages":{"5f3eb012-0672-47ef-947a-bbe93334a108":"pys0y","a0327473-b24d-47b8-98f3-751f29d0e0db":"a8wrb","19a4d980-e40c-458f-8064-18b82a216740":"kv9yq","4fe3e580-ee49-4376-8f58-085266aad475":"h1jm1"}},"routers-kdhjonto":{"prefix":"profile","appDefinitionId":"14cc59bc-f0b7-15b8-e1c7-89ce41d0e0c9","config":"{\"type\":\"public\"}","group":"members"}}},"siteMediaToken":"eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJhcHA6MzQ2NjQ5MDcwMDI5NzIwNiIsInN1YiI6InVzZXI6Yjc1NzAzMmYtYTFjYi00YzFhLWIyMzctZTEwYzBiZjQ2OWM4IiwiYXVkIjoidXJuOnNlcnZpY2U6ZmlsZS51cGxvYWQiLCJleHAiOjE1OTczMzY0MDUsImlhdCI6MTU5NjczMTYwNSwianRpIjoibkJtUW9WRG05dldFQ3RfT0pYTFVtUSJ9.aFZ6JSVXiVToxqFyl2G55YrrmjSIq7kHE6B0tnfMfxE","pagesPlatformApplications":{"masterPage":["14cc59bc-f0b7-15b8-e1c7-89ce41d0e0c9"]},"sitePropertiesInfo":{"siteDisplayName":"Todo Negócio AKI Per","locale":"pt-br","currency":"BRL","timeZone":"America\/Sao_Paulo","language":"pt","businessName":"Todo Negócio AKI Pertinho","logo":"b75703_44b4717615d04d2585e7213a5cee038a~mv2.png","categories":{"primary":"online-store"},"address":{"hint":{"text":"Rua Tenente Djalma Dutra, 683 - São José dos Pinhais-PR","placement":"REPLACE"},"isPhysical":true}},"seo":false,"pageList":{"pages":[{"pageId":"o0j6r","title":"Início","pageUriSEO":"início","pageJsonFileName":"b75703_ff7acda522bc9c276616aafc96893ab6_57.json"},{"pageId":"h1jm1","title":"Minha carteira","pageUriSEO":"my-wallet"},{"pageId":"wh212","title":"Carrinho","pageUriSEO":"cart-page","pageJsonFileName":"b75703_566cd6a7a3a74fcd99c0fed62490c52f_57.json"},{"pageId":"i31ih","title":"Agradecimento","pageUriSEO":"thank-you-page","pageJsonFileName":"b75703_6d273c0ac8cd0fc89f56f5743d5828c6_57.json"},{"pageId":"a8wrb","title":"Meus anúncios","pageUriSEO":"my-orders"},{"pageId":"rvwom","title":"Página de Produto","pageUriSEO":"product-page","pageJsonFileName":"b75703_05a2d3f79882543207c5af9431ff70df_57.json"},{"pageId":"g4m7a","title":"Loja","pageUriSEO":"shop","pageJsonFileName":"b75703_d0691ff82b0a34b52a38d3b4b4e30406_57.json"},{"pageId":"fnpl6","title":"Planos e Preços","pageUriSEO":"plans-pricing","pageJsonFileName":"b75703_df312e2c6b18d6ec077130b739079d64_57.json"},{"pageId":"pys0y","title":"Conta de anunciante","pageUriSEO":"my-account"},{"pageId":"srjgj","title":"Checkout","pageUriSEO":"checkout","pageJsonFileName":"b75703_ce828bc187b1169e67aa6499ad849536_6.json"},{"pageId":"kv9yq","title":"Meus endereços","pageUriSEO":"my-addresses"}],"mainPageId":"o0j6r","masterPageJsonFileName":"b75703_cd32827cc7a737f9a527b3068b070ac4_57.json","topology":[{"baseUrl":"https:\/\/pages.wixstatic.com\/","parts":"sites\/{filename}.z?v=3"},{"baseUrl":"https:\/\/staticorigin.wixstatic.com\/","parts":"sites\/{filename}.z?v=3"},{"baseUrl":"https:\/\/fallback.wix.com\/","parts":"wix-html-editor-pages-webapp\/page\/{filename}"}],"fixedPagePath":{"baseUrl":"siteassets.parastorage.com\/pages","parts":"\/fixedData?ck={ck}&experiments={experiments}&isHttps={isHttps}&isUrlMigrated={isUrlMigrated}&metaSiteId={metaSiteId}&pageId={pageId}&quickActionsMenuEnabled={quickActionsMenuEnabled}&siteId=1b9e9ea3-dfd2-4dbc-8ba1-a39a2a645328&v=3&version={version}"}},"platformControllersOnPage":{"o0j6r":{"1380b703-ce81-ff05-f115-39571d94dfcd":["139a41fd-0b1d-975f-6f67-e8cbdf8ccc82","1380bbc4-1485-9d44-4616-92e36b1ead6b"],"14517e1a-3ff0-af98-408e-2bd6953c36a2":["14517f3f-ffc5-eced-f592-980aaa0bbb5c"],"14cc59bc-f0b7-15b8-e1c7-89ce41d0e0c9":["members"]}},"landingPageId":"o0j6r","dacVersionOverrides":{"editor-elements":"1.1427.0"}};
        var publicModel = {"domain":"wixsite.com","externalBaseUrl":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho","unicodeExternalBaseUrl":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho","timeSincePublish":80443294,"favicon":"","deviceInfo":{"deviceType":"Desktop","browserType":"Chrome","browserVersion":84},"siteRevision":57,"siteCacheRevision":1596651165275,"sessionInfo":{"hs":1911110695,"svSession":"2da52bbe72326fce2ec99dabbcfcea404c79a2be5d7109d4d75d74611a87212a620f0a7d02037a529040c8d063da41fc1e60994d53964e647acf431e4f798bcdb318bc428dfbbc734ea99fba8f4828431678ba29dfb4b9a0d776f768c181173f","ctToken":"QUtjdDQxbVA2VGlhTUFMWC1qWlhxbkVVRmFoSmRKV3RLRlBVWi1zdmpka3x7InVzZXJBZ2VudCI6Ik1vemlsbGEvNS4wIChXaW5kb3dzIE5UIDEwLjA7IFdpbjY0OyB4NjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS84NC4wLjQxNDcuMTA1IFNhZmFyaS81MzcuMzYiLCJ2YWxpZFRocm91Z2giOjE1OTczNDE0ODc0ODF9","isAnonymous":false,"visitorId":"7863f807-b1f0-4eee-bd3c-4604c76ec8dd","siteMemberId":null},"metaSiteFlags":[],"siteMembersProtectedPages":["h1jm1","a8wrb","pys0y","kv9yq"],"indexable":true,"hasBlogAmp":false,"renderTime":1596731605184,"siteDisplayName":"Todo Negócio AKI Per","siteAssets":{"cacheVersions":{"dataFixer":5}},"siteMeshReady":true,"layoutMechanism":"MESH","requestId":"1596736687.47872115398120198","newDeviceInfo":{"uaString":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/84.0.4147.105 Safari\/537.36","os":{"type":"Windows","name":"Windows 10"},"browser":{"type":"Chrome","name":"Chrome 84.0.4147.105","major":84},"engine":{"type":"WebKit"},"deviceClass":{"type":"Desktop"}},"cssGridSupported":true,"dynamicModelUrl":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho\/_api\/v2\/dynamicmodel"};

        var googleAnalytics = "";
        var ipAnonymization = false;

        var googleRemarketing = "";
        var googleTagManager = "";
        var facebookRemarketing = "";
        var yandexMetrika = "";
    </script>
    <script type="text/javascript">
        var commonConfig = {
            brand: 'wix'
        };
    </script>
    
    

    
        
        <script>
            !function(n){var t={};function e(o){if(t[o])return t[o].exports;var i=t[o]={i:o,l:!1,exports:{}};return n[o].call(i.exports,i,i.exports,e),i.l=!0,i.exports}e.m=n,e.c=t,e.d=function(n,t,o){e.o(n,t)||Object.defineProperty(n,t,{enumerable:!0,get:o})},e.r=function(n){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(n,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(n,"__esModule",{value:!0})},e.t=function(n,t){if(1&t&&(n=e(n)),8&t)return n;if(4&t&&"object"==typeof n&&n&&n.__esModule)return n;var o=Object.create(null);if(e.r(o),Object.defineProperty(o,"default",{enumerable:!0,value:n}),2&t&&"string"!=typeof n)for(var i in n)e.d(o,i,function(t){return n[t]}.bind(null,i));return o},e.n=function(n){var t=n&&n.__esModule?function(){return n.default}:function(){return n};return e.d(t,"a",t),t},e.o=function(n,t){return Object.prototype.hasOwnProperty.call(n,t)},e.p="https://static.parastorage.com/services/cookie-consent-policy-client/1.177.0/",e(e.s=0)}([function(n,t,e){"use strict";function o(n,t){try{"function"==typeof n&&n(t)}catch(n){console&&console.error(n)}}e.r(t),e.d(t,"ConsentPolicyManager",(function(){return m}));var i={essential:!0,functional:!0,analytics:!0,advertising:!0,dataToThirdParty:!0},r={essential:!0,functional:!0,analytics:!0,advertising:!1,dataToThirdParty:!0},c=["wix.com","editorx.com"];function a(n,t){return t===n||t.endsWith("."+n)}function s(n){return t=c,e=n||location.hostname,t.some((function(n){return a(n,e)}));var t,e}var u={func:"functional",anl:"analytics",adv:"advertising",dt3:"dataToThirdParty",ess:"essential"};function l(n){var t=f();if(t&&!t.defaultPolicy){var e=function(n){var t="",e="";if(c.forEach((function(n){a(n,location.hostname)&&(t="."+n,e="/")})),!t&&!e){t=location.hostname;var o=n.split(location.hostname);if("/"===(e=o[1]?""+o[1]:"/")){var i=t.split(".");i.shift(),t="."+i.join(".")}}return{host:t,path:e}}(n),o=e.path,i=e.host;return document.cookie="consent-policy=; expires=Thu, 01 Jan 1970 00:00:00 GMT; domain="+i+"; path="+o+";",!0}return!1}function f(){var n,t=function(){var n=document.cookie.match("[;\\s ]?consent-policy=([\\S]+(?:;?))"),t=n?n.pop():void 0;return(t=t&&t.replace(";",""))||void 0}();if(!t||"string"!=typeof t)return!1;var e={};try{var o=JSON.parse(decodeURIComponent(t));return Object.keys(u).forEach((function(n){"number"==typeof o[n]&&(e[u[n]]=1===o[n])})),n=function(n){var t;"number"==typeof n&&(t=new Date(1e3*n*60));return t}(o.ts),{defaultPolicy:!!o.temp,policy:e,createdDate:n}}catch(n){return!1}}function y(n,t){var e=f();return e||{defaultPolicy:!0,policy:function(n,t){return d(t||(s(n)?r:i))}(n,t)}}function d(n){return JSON.parse(JSON.stringify(n))}function p(n,t,e){var o;!!document.documentMode?(o=document.createEvent("CustomEvent")).initCustomEvent(n,!0,!1,e):o=new CustomEvent(n,{detail:e,bubbles:!0}),t&&t.dispatchEvent&&t.dispatchEvent(o)}var v="consentPolicyChanged",h="consentPolicyManagerReady";function g(n){return void 0===n&&(n=""),void 0===(t=n)&&(t=""),(s()||!t?"":0===t.indexOf("http")?t:"\\\\"+t)+"/_api/cookie-consent-policy/v1/consent-policies";var t}var P=function(){return(P=Object.assign||function(n){for(var t,e=1,o=arguments.length;e<o;e++)for(var i in t=arguments[e])Object.prototype.hasOwnProperty.call(t,i)&&(n[i]=t[i]);return n}).apply(this,arguments)},b=function(n){p(v,document,n)},m=function(){function n(){var n=this;this.config={baseUrl:""},this.hostname=window.location.hostname,this.initRan=!1,this.getValidPolicy=function(t){var e={},o=n.getCurrentConsentPolicy().policy;return"object"==typeof t&&Object.keys(i).forEach((function(n){"boolean"==typeof t[n]&&(e[n]=t[n])})),P(P({},o),e)},this.shouldTriggerConsentPolicyChanged=function(t){return t.consentPolicy&&n.initRan&&n.getCurrentConsentPolicy().defaultPolicy&&JSON.stringify(t.consentPolicy)!==JSON.stringify(n.getCurrentConsentPolicy().policy)},this.init=function(t){var e,o="string"==typeof t?{baseUrl:t}:{baseUrl:t.baseUrl,consentPolicy:t.consentPolicy}||{};o.consentPolicy&&(o.consentPolicy=n.getValidPolicy(o.consentPolicy)),n.shouldTriggerConsentPolicyChanged(o)&&b({defaultPolicy:!0,policy:o.consentPolicy}),n.initRan=!0,n.config=P(P({},n.config),o),n.config.baseUrl=(e=n.config.baseUrl||"").endsWith("/")?e.slice(0,-1):e},this.setConsentPolicy=function(t,e,i){if(void 0===t){var r="setConsentPolicy: no policy sent as parameter";i&&i(r),console.error(r)}var c=function(n){i&&i("Failed setting policy. details: "+n)},a=JSON.stringify(P({policy:P(P({},n.getValidPolicy(t)),{essential:!0}),location:location.href},n.config.baseUrl?{baseUrl:n.config.baseUrl}:{})),u=window.wixEmbedsAPI,l=!s()&&u&&u.getAppToken&&u.getAppToken("22bef345-3c5b-4c18-b782-74d4085112ff");!function(n,t,e,i,r){var c=new XMLHttpRequest;c.open("POST",n,!0),c.onreadystatechange=function(){if(4===c.readyState){var n=c.status;n<200||n>=300?o(e,n):o(t,c.responseText)}},c.setRequestHeader("content-type","application/json"),r&&c.setRequestHeader("authorization",r),c.send(i||null)}(g(n.config.baseUrl),(function(n){try{var t=JSON.parse(n),o={defaultPolicy:!1,policy:t.consent.policy},i=t.consent.timestamp;i&&(o.createdDate=new Date(i)),b(o),e&&e(o)}catch(n){c(n)}}),c,a,l)},this.getCurrentConsentPolicy=function(){return y(n.hostname,n.config.consentPolicy)},this._getConsentPolicyHeader=function(){return t=n.hostname,e=n.config.consentPolicy,i=y(t,e).policy,r=Object.keys(u).reduce((function(n,t){var e=u[t];return n[t]=i[e]?1:0,n}),{}),c=encodeURIComponent(JSON.stringify(r)),(o={})["consent-policy"]=c,o;var t,e,o,i,r,c}}return n.prototype.resetPolicy=function(){var n=this,t=l(this.config.baseUrl||"");return t&&setTimeout((function(){b(n.getCurrentConsentPolicy())}),5),t},n}();"undefined"!=typeof window&&(window.consentPolicyManager=new m,p(h,window,window.consentPolicyManager))}]);
//# sourceMappingURL=app.bundle.min.js.map
        </script>
    
   

    <script>
        var wixBiSession = {
            initialTimestamp: Date.now()
            , ssrRequestTimestamp: 1596731605207
            , requestId: publicModel.requestId
            , genGUID: function () {
                return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,function(c){var r=Math.random()*16|0,v=c=='x'?r:(r&0x3|0x8);return v.toString(16);});
            }
            , sessionId: 'c741fced-9865-47d9-b1e5-04b2e0906e7d'
            , initialRequestTimestamp: performance.timeOrigin ? performance.timeOrigin : Date.now() - performance.now()
            
            
            , is_rollout: 0
            , isSAVrollout: 0
            , isDACrollout: 1
            , is_platform_loaded: 1
            , suppressbi: false
            , dc: '96'
            , renderType: 'bolt'
            , siteRevision: '57'
            , siteCacheRevision: '1596651165275'
            , wixBoltExclusionReason: ''
            , wixBoltExclusionReasonMoreInfo: ''
            , checkVisibility: (function () {
                var alwaysVisible = document.hidden !== true;
                function checkVisibility() {
                    alwaysVisible = alwaysVisible && document.hidden !== true;
                    return alwaysVisible;
                }
                document.addEventListener('visibilitychange', checkVisibility, false);
                return checkVisibility;
            })()
            , cacheCookie: document.cookie.match(/ssr-caching="?cache[,#]\s*desc=(\w+)(?:[,#]\s*varnish=(\w+))?(?:[,#]\s*dc[,#]\s*desc=(\w+))?(?:"|;|$)/)
            , setCaching: function (bodyCacheable) {
                if (!bodyCacheable) {
                    wixBiSession.caching = undefined;
                }

                var parts = wixBiSession.cacheCookie;
                if (parts) {
                    set(parts);
                }

                if (window.PerformanceServerTiming) {
                    var serverTiming = performance.getEntriesByType('navigation')[0].serverTiming;
                    if (serverTiming && serverTiming.length) {
                        var names = [, 'cache', 'varnish', 'dc'];
                        parts = [];
                        serverTiming.forEach(function (entry) {
                            var i = names.indexOf(entry.name);
                            if (i > 0) {
                                parts[i] = entry.description;
                            }
                        });
                        set(parts);
                    }
                }

                if (!wixBiSession.caching) {
                    wixBiSession.caching = 'none';
                    wixBiSession.isCached = false;
                }

                function set(parts) {
                    if (bodyCacheable && parts[1]) {
                        wixBiSession.caching = parts[1] + ',' + (parts[2] || 'none');
                        wixBiSession.isCached = isCached(parts[1]) || isCached(parts[2]);
                    }
                    if (parts[3]) {
                        wixBiSession.microPop = parts[3];
                    }
                }
                function isCached(part) {
                    return !!part && part.indexOf('hit') === 0;
                }
            }
            , sendBeacon: function (url) {
                if (!wixBiSession.suppressbi) {
                
                    var sent = false;
                    try {
                        sent = navigator.sendBeacon(url);
                    } catch (e) {}
                    if (!sent) {
                        (new Image()).src = url;
                    }
                
                }
            }
            , sendBeat: (function () {
                var beatUrl = 'https://frog.wix.com/bt?src=29&evid=3'
                    + '&v=1.6455.0'
                    + '&msid=ed554812-eecc-40de-ac38-0af295cb607b'
                    + '&isp=0'
                    + '&st=2'
                    + '&dc=96'
                    + '&iss=1';
                var prevMark = 'fetchStart';
                return function(et, name, extra, pageNumber) {
                    var tts = Math.round(performance.now());
                    var ts = et === 1 ? 0 : Date.now() - wixBiSession.initialTimestamp;
                    if (name && performance.mark) {
                        var mark = name + ' (beat ' + et + ')';
                        performance.mark(mark);
                        if (performance.measure) {
                            performance.measure('\u2B50' + mark, prevMark, mark);
                        }
                        prevMark = mark;
                    }
                    var analytics = true;
                    if (window.consentPolicyManager) {
                        var pm = consentPolicyManager.getCurrentConsentPolicy();
                        if (!pm.policy.essential) {
                            return;
                        }
                        analytics = pm.policy.analytics && pm.policy.functional;
                    }
                    extra = (analytics && extra) || '';
                    if (extra.indexOf('pn=') === -1) {
                        extra += '&pn=' + (pageNumber || '1');
                    }
                    var url = location.href;
                    if (!analytics) {
                        url = url.replace(/\?.*$/, '');
                    } else {
                        var referrer = document.referrer;
                        if (referrer) {
                            extra += '&ref=' + encodeURIComponent(referrer);
                        }
                        var match = document.cookie.match(/_wixCIDX=([^;]*)/)
                        if (match) {
                            extra += '&client_id=' + match[1];
                        }
                        extra += genField('visitorId', 'vid');
                        extra += genField('siteMemberId', 'mid');
                        if (extra.indexOf('sr=') === -1 && screen.width) {
                            extra += '&sr=' + screen.width + 'x' + screen.height;
                        }
                        if (screen.availWidth) {
                            extra += '&sar=' + screen.availWidth + 'x' + screen.availHeight;
                        }
                        if (extra.indexOf('wr=') === -1 && window.innerWidth) {
                            extra += '&wr=' + window.innerWidth + 'x' + window.innerHeight;
                        }
                        if (window.outerWidth) {
                            extra += '&wor=' + window.outerWidth + 'x' + window.outerHeight;
                        }
                        if (extra.indexOf('ita=') === -1) {
                            extra += '&ita=' + toBool(wixBiSession.checkVisibility());
                        }
                    }
                    if (wixBiSession.siteRevision || wixBiSession.siteCacheRevision) {
                        extra += '&siterev=' + wixBiSession.siteRevision + "-" + wixBiSession.siteCacheRevision;
                    }
                    if (wixBiSession.hasOwnProperty('isUsingMesh')) {
                        extra += '&ism=' + toBool(wixBiSession.isUsingMesh);
                    }
                    if (wixBiSession.hasOwnProperty('caching')) {
                        extra += genField('caching') + '&is_cached=' + toBool(wixBiSession.isCached);
                    }
                    wixBiSession.sendBeacon(beatUrl
                        + '&et=' + et
                        + (name ? '&event_name=' + encodeURIComponent(name) : '')
                        + '&ts=' + ts
                        + '&tts=' + tts
                        + '&_brandId=' + commonConfig.brand
                        + '&vsi=' + wixBiSession.viewerSessionId
                        + '&rid=' + wixBiSession.requestId
                        + '&viewer_name=' + encodeURIComponent(wixBiSession.renderType)
                        + '&is_rollout=' + wixBiSession.is_rollout
                        + '&is_platform_loaded=' + wixBiSession.is_platform_loaded
                        + genField('sessionId')
                        + '&url=' + encodeURIComponent(url.replace(/^http(s)?:\/\/(www\.)?/, ''))
                        + extra
                    );
                };

                function genField(name, label) {
                    return wixBiSession[name] ? '&' + (label || name) + '=' + wixBiSession[name] : '';
                }
                function toBool(v) {
                    return v ? '1' : '0';
                }
            })()
        };
        wixBiSession.viewerSessionId = wixBiSession.genGUID();
        wixBiSession.setCaching(true);
        wixBiSession.sendBeat(1, 'Init');
    </script>
    
    <script type="text/javascript">
        (function(x,e,o,s,n){var a=window.fedops||{};a.apps=a.apps||{};a.apps[x]={startLoadTime:e&&e.now&&e.now()};try{a.sessionId=o.getItem("fedops.logger.sessionId")}catch(x){}a.sessionId=a.sessionId||wixBiSession.viewerSessionId;window.fedops=a;var d="//frog.wix.com/bolt-performance?appName="+x+"&src=72&evid=21"+'&dc=96'+"&is_rollout="+wixBiSession.is_rollout+ "&is_cached="+wixBiSession.isCached+"&session_id="+a.sessionId+"&_="+s() + '&is_sav_rollout=' + wixBiSession.isSAVrollout+ '&is_dac_rollout=' + wixBiSession.isDACrollout;wixBiSession.sendBeacon(d)})('bolt-viewer',window.performance,window.localStorage,Math.random,window.navigator);
    </script>
    
    
    
    
    
    
    
    <!-- DATA -->
    <script type="text/javascript">
        
            var adData = {};
            var mobileAdData = {};
        
        var usersDomain = "https://users.wix.com/wix-users";
        
    </script>
    
    
    
    
    
    
    
    
    
    <!--head html embeds start-->
    
    <!--head html embeds end-->
    
    
    
    <script type="text/javascript">
      var santaBase = 'https://static.parastorage.com/services/santa/1.11206.0';
      var boltBase = 'https://static.parastorage.com/services/wix-bolt/1.6455.0';
      var boltVersion = '1.6455.0';
    </script>
    

    
    
    
    <script>
      var requirejs = {
        onNodeCreated: function(node) {
          var src = node.getAttribute('src');
          var shouldIgnore = ['googletagmanager.com', 'google-analytics.com', 'googleadservices.com', 'doubleclick.net', 'connect.facebook.net', 'player.twitch.tv'].some(function (domain) {
              return src.indexOf(domain) !== -1;
          });
          if (!shouldIgnore) {
              node.setAttribute('crossorigin', 'anonymous')
          }
        }
      }
    </script>

    <script>
      window.messageBuffer = [];
      window.messageHandler = function(event) {messageBuffer.push(event)};
      window.addEventListener('message', window.messageHandler, false);
    </script>

    
    <script id="sentry">(function(c,t,u,n,p,l,y,z,v){function e(b){if(!w){w=!0;var d=t.getElementsByTagName(u)[0],a=t.createElement(u);a.src=z;a.crossorigin="anonymous";a.addEventListener("load",function(){try{c[n]=q;c[p]=r;var a=c[l],d=a.init;a.init=function(a){for(var b in a)Object.prototype.hasOwnProperty.call(a,b)&&(v[b]=a[b]);d(v)};B(b,a)}catch(A){console.error(A)}});d.parentNode.insertBefore(a,d)}}function B(b,d){try{for(var a=0;a<b.length;a++)if("function"===typeof b[a])b[a]();var f=m.data,g=!1,h=!1;for(a=0;a<f.length;a++)if(f[a].f){h=
            !0;var e=f[a];!1===g&&"init"!==e.f&&d.init();g=!0;d[e.f].apply(d,e.a)}!1===h&&d.init();var k=c[n],l=c[p];for(a=0;a<f.length;a++)f[a].e&&k?k.apply(c,f[a].e):f[a].p&&l&&l.apply(c,[f[a].p])}catch(C){console.error(C)}}for(var g=!0,x=!1,k=0;k<document.scripts.length;k++)if(-1<document.scripts[k].src.indexOf(y)){g="no"!==document.scripts[k].getAttribute("data-lazy");break}var w=!1,h=[],m=function(b){(b.e||b.p||b.f&&-1<b.f.indexOf("capture")||b.f&&-1<b.f.indexOf("showReportDialog"))&&g&&e(h);m.data.push(b)};
            m.data=[];c[l]={onLoad:function(b){h.push(b);g&&!x||e(h)},forceLoad:function(){x=!0;g&&setTimeout(function(){e(h)})}};"init addBreadcrumb captureMessage captureException captureEvent configureScope withScope showReportDialog".split(" ").forEach(function(b){c[l][b]=function(){m({f:b,a:arguments})}});var q=c[n];c[n]=function(b,d,a,f,e){m({e:[].slice.call(arguments)});q&&q.apply(c,arguments)};var r=c[p];c[p]=function(b){m({p:b.reason});r&&r.apply(c,arguments)};g||setTimeout(function(){e(h)})})(window,document,
            "script","onerror","onunhandledrejection","Sentry","8b4e078a51d04e0e9efdf470027f0ec1","https://browser.sentry-cdn.com/4.6.2/bundle.min.js",{"dsn":"https://8b4e078a51d04e0e9efdf470027f0ec1@sentry.wixpress.com/3"});</script>
    
    

    
        <script async src="https://static.parastorage.com/services/wix-bolt/1.6455.0/bolt-main/app/bolt-custom-elements.min.js" crossorigin="anonymous"></script>
    

    
    <script>
        window.dynamicModel = fetch(publicModel.dynamicModelUrl).then(function(res) { return res.json(); });
        if (wixBiSession && !wixBiSession.visitorId) {
            window.dynamicModel.then(function (dm) {
                if (dm.visitorId) {
                    wixBiSession.visitorId = dm.visitorId;
                }
            });
        }
    </script>
    

    <script async data-main="https://static.parastorage.com/services/wix-bolt/1.6455.0/bolt-main/app/main-r.min.js" src="https://static.parastorage.com/unpkg/requirejs-bolt@2.3.6/requirejs.min.js"></script>

    
    
    
    <style id="viewerMainStyle">
        a,abbr,acronym,address,applet,b,big,blockquote,body,button,caption,center,cite,code,dd,del,dfn,div,dl,dt,em,fieldset,font,footer,form,h1,h2,h3,h4,h5,h6,header,html,i,iframe,img,ins,kbd,label,legend,li,nav,object,ol,p,pre,q,s,samp,section,small,span,strike,strong,sub,sup,table,tbody,td,tfoot,th,thead,title,tr,tt,u,ul,var,wix-iframe{margin:0;padding:0;border:0;outline:0;vertical-align:baseline;background:0 0}wix-iframe{display:block}body{font-size:10px;font-family:Arial,Helvetica,sans-serif}input,select,textarea{font-family:Helvetica,Arial,sans-serif;box-sizing:border-box}ol,ul{list-style:none}blockquote,q{quotes:none}ins{text-decoration:none}del{text-decoration:line-through}table{border-collapse:collapse;border-spacing:0}a{cursor:pointer;text-decoration:none}body,html{height:100%}body{overflow-x:auto;overflow-y:scroll}body.overflowHidden{overflow:hidden}.testStyles{overflow-y:hidden}.reset-button{background:0 0;border:0;outline:0;color:inherit;font:inherit;line-height:normal;overflow:visible;padding:0;-webkit-appearance:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none}:focus{outline:0}.wixSiteProperties{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.SITE_ROOT{min-height:100%;position:relative;margin:0 auto}.POPUPS_ROOT{left:0;top:0;width:100vw;height:100%;overflow-x:auto;overflow-y:scroll;position:fixed;z-index:99999}.POPUPS_ROOT.mobile{z-index:1005;-webkit-overflow-scrolling:touch}.POPUPS_ROOT.responsive .POPUPS_WRAPPER{position:absolute;top:0;left:0;width:100%;height:100%}.POPUPS_ROOT:not(.responsive) .POPUPS_WRAPPER{position:relative;overflow:auto}.POPUPS_ROOT:not(.responsive) .POPUPS_WRAPPER>div{margin:0 auto}.auto-generated-link{color:inherit}.warmup .hidden-on-warmup{visibility:hidden}body:not([data-js-loaded]) [data-hide-prejs]{visibility:hidden}html.device-phone body{overflow-y:auto}html.device-mobile-optimized.device-android{margin-bottom:1px}html.device-mobile-optimized.blockSiteScrolling>body{position:fixed;width:100%}html.device-mobile-optimized.media-zoom-mode>body{touch-action:manipulation}html.device-mobile-optimized.media-zoom-mode>body>#SITE_CONTAINER{height:100%;overflow:hidden}html.device-mobile-optimized.media-zoom-mode>body>#SITE_CONTAINER>.noop{height:100%}html.device-mobile-optimized.media-zoom-mode>body>#SITE_CONTAINER>.noop>.siteAspectsContainer{height:100%;z-index:1005}.siteAspectsContainer{position:absolute;top:0;margin:0 auto;left:0;right:0}body.prewarmup #SITE_ROOT{overflow-x:hidden;overflow-y:hidden}body.device-mobile-optimized{overflow-x:hidden;overflow-y:scroll}body.device-mobile-optimized.qa-mode{overflow-y:auto}body.device-mobile-optimized #SITE_CONTAINER{width:320px;overflow-x:visible;margin:0 auto;position:relative}body.device-mobile-optimized>*{max-width:100%!important}body.device-mobile-optimized .SITE_ROOT{overflow-x:hidden;overflow-y:hidden}body.device-mobile-non-optimized #SITE_CONTAINER>:not(.mobile-non-optimized-overflow) .SITE_ROOT{overflow-x:hidden;overflow-y:auto}body.device-mobile-non-optimized.fullScreenMode{background-color:#5f6360}body.device-mobile-non-optimized.fullScreenMode #MOBILE_ACTIONS_MENU,body.device-mobile-non-optimized.fullScreenMode #SITE_BACKGROUND,body.device-mobile-non-optimized.fullScreenMode .SITE_ROOT{visibility:hidden}body.fullScreenMode #WIX_ADS{visibility:hidden}body.fullScreenMode{overflow-x:hidden!important;overflow-y:hidden!important}body.fullScreenMode.device-mobile-optimized #TINY_MENU{opacity:0;pointer-events:none}body.fullScreenMode-scrollable.device-mobile-optimized{overflow-x:hidden!important;overflow-y:auto!important}body.fullScreenMode-scrollable.device-mobile-optimized #masterPage,body.fullScreenMode-scrollable.device-mobile-optimized .SITE_ROOT{overflow-x:hidden!important;overflow-y:hidden!important}body.fullScreenMode-scrollable.device-mobile-optimized #SITE_BACKGROUND,body.fullScreenMode-scrollable.device-mobile-optimized #masterPage{height:auto!important}body.fullScreenMode-scrollable.device-mobile-optimized #masterPage.mesh-layout{height:0!important}.fullScreenOverlay{z-index:1005;position:fixed;left:0;top:-60px;right:0;bottom:0;display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;overflow-y:hidden}.fullScreenOverlay>.fullScreenOverlayContent{margin:0 auto;position:absolute;right:0;top:60px;left:0;bottom:0;overflow:hidden;-webkit-transform:translateZ(0);transform:translateZ(0)}.mobile-actions-menu-wrapper{z-index:1000}body[contenteditable]{overflow-x:auto;overflow-y:auto}.bold{font-weight:700}.italic{font-style:italic}.underline{text-decoration:underline}.lineThrough{text-decoration:line-through}.singleLineText{white-space:nowrap;text-overflow:ellipsis}.alignLeft{text-align:left}.alignCenter{text-align:center}.alignRight{text-align:right}.alignJustify{text-align:justify}ol.font_100,ul.font_100{color:#080808;font-family:'Arial, Helvetica, sans-serif',serif;font-size:10px;font-style:normal;font-variant:normal;font-weight:400;margin:0;text-decoration:none;line-height:normal;letter-spacing:normal}ol.font_100 li,ul.font_100 li{margin-bottom:12px}letter{position:relative;display:inline-block}word{display:inline-block;white-space:nowrap}letter.space,word.space{display:inline}ol.wix-list-text-align,ul.wix-list-text-align{list-style-position:inside}ol.wix-list-text-align h1,ol.wix-list-text-align h2,ol.wix-list-text-align h3,ol.wix-list-text-align h4,ol.wix-list-text-align h5,ol.wix-list-text-align h6,ol.wix-list-text-align p,ul.wix-list-text-align h1,ul.wix-list-text-align h2,ul.wix-list-text-align h3,ul.wix-list-text-align h4,ul.wix-list-text-align h5,ul.wix-list-text-align h6,ul.wix-list-text-align p{display:inline}#popoverLayer{z-index:100}.wixapps-less-spacers-align.ltr{text-align:left}.wixapps-less-spacers-align.center{text-align:center}.wixapps-less-spacers-align.rtl{text-align:right}.wixapps-less-spacers-align>a,.wixapps-less-spacers-align>div{display:inline-block!important}.flex_display{display:-webkit-box;display:-webkit-flex;display:flex}.flex_vbox{box-sizing:border-box;padding-top:.01em;padding-bottom:.01em}a.wixAppsLink img{cursor:pointer}.singleLine{white-space:nowrap;display:block;overflow:hidden;text-overflow:ellipsis;word-wrap:normal}[data-z-counter]{z-index:0}[data-z-counter="0"]{z-index:auto}.circle-preloader{-webkit-animation:semi-rotate 1s 1ms linear infinite;animation:semi-rotate 1s 1ms linear infinite;height:30px;left:50%;margin-left:-15px;margin-top:-15px;overflow:hidden;position:absolute;top:50%;-webkit-transform-origin:100% 50%;transform-origin:100% 50%;width:15px}.circle-preloader::before{content:'';top:0;left:0;right:-100%;bottom:0;border:3px solid currentColor;border-color:currentColor transparent transparent currentColor;border-radius:50%;position:absolute;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-animation:inner-rotate .5s 1ms linear infinite alternate;animation:inner-rotate .5s 1ms linear infinite alternate;color:#7fccf7}.circle-preloader::after{content:'';top:0;left:0;right:-100%;bottom:0;border:3px solid currentColor;border-color:currentColor transparent transparent currentColor;border-radius:50%;position:absolute;-webkit-transform:rotate(-45deg);transform:rotate(-45deg);-webkit-animation:inner-rotate .5s 1ms linear infinite alternate;animation:inner-rotate .5s 1ms linear infinite alternate;color:#3899ec;opacity:0}.circle-preloader.white::before{color:#f0f0f0}.circle-preloader.white::after{color:#dcdcdc}@-webkit-keyframes inner-rotate{to{opacity:1;-webkit-transform:rotate(115deg);transform:rotate(115deg)}}@keyframes inner-rotate{to{opacity:1;-webkit-transform:rotate(115deg);transform:rotate(115deg)}}@-webkit-keyframes semi-rotate{from{-webkit-animation-timing-function:ease-out;animation-timing-function:ease-out;-webkit-transform:rotate(180deg);transform:rotate(180deg)}45%{-webkit-transform:rotate(198deg);transform:rotate(198deg)}55%{-webkit-transform:rotate(234deg);transform:rotate(234deg)}to{-webkit-transform:rotate(540deg);transform:rotate(540deg)}}@keyframes semi-rotate{from{-webkit-animation-timing-function:ease-out;animation-timing-function:ease-out;-webkit-transform:rotate(180deg);transform:rotate(180deg)}45%{-webkit-transform:rotate(198deg);transform:rotate(198deg)}55%{-webkit-transform:rotate(234deg);transform:rotate(234deg)}to{-webkit-transform:rotate(540deg);transform:rotate(540deg)}}.hidden-comp-ghost-mode{opacity:.5}.collapsed-comp-mode::after{position:absolute;top:0;bottom:0;left:0;right:0;content:'';background:-webkit-repeating-linear-gradient(135deg,transparent,transparent 40%,#2b5672c7 40%,#2b5672c7 45%,#cbcddee8 45%,#cbcddee8 50%,transparent 50%);background:repeating-linear-gradient(-45deg,transparent,transparent 40%,#2b5672c7 40%,#2b5672c7 45%,#cbcddee8 45%,#cbcddee8 50%,transparent 50%);background-size:10px 10px;background-repeat:repeat;pointer-events:none}.g-transparent-a:link,.g-transparent-a:visited{border-color:transparent}.transitioning-comp *{transition:inherit!important;-webkit-transition:inherit!important}.selectionSharerContainer{position:absolute;background-color:#fff;box-shadow:0 4px 10px 0 rgba(57,86,113,.24);width:142px;height:45px;border-radius:100px;text-align:center}.selectionSharerContainer:after{content:"";position:absolute;bottom:-10px;left:42%;border-width:10px 10px 0;border-style:solid;border-color:#fff transparent;display:block;width:0}.selectionSharerContainer .selectionSharerOption{display:inline-block;cursor:pointer;vertical-align:top;padding:13px 11px 11px 13px;margin:1px;z-index:-1}.selectionSharerContainer .selectionSharerVerticalSeparator{margin-top:9px;margin-bottom:18px;background-color:#eaf7ff;height:26px;width:1px;display:inline-block}.visual-focus-on .focus-ring:not(.has-custom-focus):focus,.visual-focus-on .focus-ring:not(.has-custom-focus):focus~.wixSdkShowFocusOnSibling{box-shadow:0 0 0 1px #fff,0 0 0 3px #116dff;z-index:999}body.prewarmup .hidden-during-prewarmup{visibility:hidden}#masterPage.mesh-layout[data-mesh-layout=grid]{display:-ms-grid;display:grid;-ms-grid-rows:max-content max-content min-content max-content;grid-template-rows:-webkit-max-content -webkit-max-content -webkit-min-content -webkit-max-content;grid-template-rows:max-content max-content min-content max-content;-ms-grid-columns:100%;grid-template-columns:100%;-webkit-box-align:start;-webkit-align-items:start;align-items:start;-webkit-box-pack:stretch;-webkit-justify-content:stretch;justify-content:stretch}#masterPage.mesh-layout[data-mesh-layout=grid] #PAGES_CONTAINER,#masterPage.mesh-layout[data-mesh-layout=grid] #SITE_FOOTER,#masterPage.mesh-layout[data-mesh-layout=grid] #SITE_FOOTER-placeholder,#masterPage.mesh-layout[data-mesh-layout=grid] #SITE_HEADER,#masterPage.mesh-layout[data-mesh-layout=grid] #SITE_HEADER-placeholder,#masterPage.mesh-layout[data-mesh-layout=grid] #SOSP_CONTAINER_CUSTOM_ID[data-state~=mobileView],#masterPage.mesh-layout[data-mesh-layout=grid] #soapAfterPagesContainer,#masterPage.mesh-layout[data-mesh-layout=grid] #soapBeforePagesContainer{-ms-grid-column:1;-ms-grid-row-align:start;-ms-grid-column-align:start}#masterPage.mesh-layout[data-mesh-layout=grid] #SITE_HEADER,#masterPage.mesh-layout[data-mesh-layout=grid] #SITE_HEADER-placeholder{-ms-grid-row:1;grid-area:1/1/2/2}#masterPage.mesh-layout[data-mesh-layout=grid] #SOSP_CONTAINER_CUSTOM_ID[data-state~=mobileView]{-ms-grid-row:2;grid-area:2/1/3/2}#masterPage.mesh-layout[data-mesh-layout=grid] #PAGES_CONTAINER,#masterPage.mesh-layout[data-mesh-layout=grid] #soapAfterPagesContainer,#masterPage.mesh-layout[data-mesh-layout=grid] #soapBeforePagesContainer{-ms-grid-row:3;grid-area:3/1/4/2}#masterPage.mesh-layout[data-mesh-layout=grid] #soapAfterPagesContainer,#masterPage.mesh-layout[data-mesh-layout=grid] #soapBeforePagesContainer{width:100%}#masterPage.mesh-layout[data-mesh-layout=grid] #PAGES_CONTAINER{-webkit-align-self:stretch;align-self:stretch}#masterPage.mesh-layout[data-mesh-layout=grid] main#PAGES_CONTAINER{display:block}#masterPage.mesh-layout[data-mesh-layout=grid] #SITE_FOOTER,#masterPage.mesh-layout[data-mesh-layout=grid] #SITE_FOOTER-placeholder{-ms-grid-row:4;grid-area:4/1/5/2}#masterPage.mesh-layout[data-mesh-layout=grid] #PAGES_CONTAINERcenteredContent,#masterPage.mesh-layout[data-mesh-layout=grid] #PAGES_CONTAINERinlineContent,#masterPage.mesh-layout[data-mesh-layout=grid] #SITE_PAGES{height:100%}#masterPage.mesh-layout.desktop>*{width:100%}#masterPage.mesh-layout #PAGES_CONTAINER,#masterPage.mesh-layout #SITE_FOOTER,#masterPage.mesh-layout #SITE_HEADER,#masterPage.mesh-layout #SOSP_CONTAINER_CUSTOM_ID[data-state~=mobileView],#masterPage.mesh-layout #masterPageinlineContent{position:relative}#masterPage.mesh-layout #SITE_FOOTER-placeholder,#masterPage.mesh-layout #SITE_HEADER-placeholder{display:none}#masterPage.mesh-layout #SITE_HEADER[data-state~=fixedPosition]~#SITE_HEADER-placeholder{display:block}#masterPage.mesh-layout #SITE_FOOTER[data-state~=fixedPosition]~#SITE_FOOTER-placeholder{display:block}#masterPage.mesh-layout #SITE_PAGES{height:auto;position:relative}#SITE_ROOT img:not([src]){visibility:hidden}#SITE_ROOT svg img:not([src]){visibility:visible}wix-image{display:block}
    </style>
    

    
    

    
        

            
                <style id="v7.languages.css">
                    /*
This CSS resource incorporates links to font software which is the valuable copyrighted
property of Monotype Imaging and/or its suppliers. You may not attempt to copy, install,
redistribute, convert, modify or reverse engineer this font software. Please contact Monotype
Imaging with any questions regarding Web fonts:  http://webfonts.fonts.com
*/

/* latin */
@font-face {
    font-family: "Helvetica-W01-Roman";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ea95b44a-eab7-4bd1-861c-e73535e7f652.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ea95b44a-eab7-4bd1-861c-e73535e7f652.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4021a3b9-f782-438b-aeb4-c008109a8b64.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/669f79ed-002c-4ff6-965c-9da453968504.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/d17bc040-9e8b-4397-8356-8153f4a64edf.svg#d17bc040-9e8b-4397-8356-8153f4a64edf") format("svg");
}

@font-face {
    font-family: "Helvetica-W01-Bold";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f70da45a-a05c-490c-ad62-7db4894b012a.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f70da45a-a05c-490c-ad62-7db4894b012a.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c5749443-93da-4592-b794-42f28d62ef72.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/73805f15-38e4-4fb7-8a08-d56bf29b483b.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/874bbc4a-0091-49f0-93ef-ea4e69c3cc7a.svg#874bbc4a-0091-49f0-93ef-ea4e69c3cc7a") format("svg");
}

@font-face {
    font-family: "Braggadocio-W01";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f305266f-adfb-4e4f-9055-1d7328de8ce6.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f305266f-adfb-4e4f-9055-1d7328de8ce6.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/518e4577-eecc-4ecd-adb4-2ee21df35b20.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f46241ad-1f5d-4935-ad69-b0a78c2e191d.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b2a0a25d-e054-4c65-bffa-e5760b48dec3.svg#b2a0a25d-e054-4c65-bffa-e5760b48dec3") format("svg");
}

@font-face {
    font-family: "Clarendon-W01-Medium-692107";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c6993450-d795-4fd3-b306-38481733894c.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c6993450-d795-4fd3-b306-38481733894c.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b6878f57-4d64-4d70-926d-fa4dec6173a5.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0a6b6eff-6b5d-46d4-b681-f356eef1e4c1.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/600b1038-76a8-43b4-a2f7-2a6eb0681f95.svg#600b1038-76a8-43b4-a2f7-2a6eb0681f95") format("svg");
}

@font-face {
    font-family: "DIN-Next-W01-Light";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3e0b2cd7-9657-438b-b4af-e04122e8f1f7.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3e0b2cd7-9657-438b-b4af-e04122e8f1f7.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/bc176270-17fa-4c78-a343-9fe52824e501.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3516f91d-ac48-42cd-acfe-1be691152cc4.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/d1b1e866-a411-42ba-8f75-72bf28e23694.svg#d1b1e866-a411-42ba-8f75-72bf28e23694") format("svg");
}

@font-face {
    font-family: "SnellRoundhandW01-Scrip";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/fea0fb7b-884b-4567-a6dc-addb8e67baaa.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/fea0fb7b-884b-4567-a6dc-addb8e67baaa.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/efbfc170-aaf0-4472-91f4-dbb5bc2f4c59.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/d974669d-978c-4bcf-8843-b2b7c366d097.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/5b2427b5-3c1e-4b17-9f3c-720a332c9142.svg#5b2427b5-3c1e-4b17-9f3c-720a332c9142") format("svg");
}

@font-face {
    font-family: "Stencil-W01-Bold";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/cc642b17-a005-4f1e-86e8-baffa4647445.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/cc642b17-a005-4f1e-86e8-baffa4647445.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/a9eddc47-990d-47a3-be4e-c8cdec0090c6.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/8d108476-7a62-4664-821f-03c8a522c030.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/7823e34c-67dc-467a-bbfb-efbb5f6c90f0.svg#7823e34c-67dc-467a-bbfb-efbb5f6c90f0") format("svg");
}

@font-face {
    font-family: "Helvetica-W01-Light";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/717f8140-20c9-4892-9815-38b48f14ce2b.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/717f8140-20c9-4892-9815-38b48f14ce2b.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/03805817-4611-4dbc-8c65-0f73031c3973.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/d5f9f72d-afb7-4c57-8348-b4bdac42edbb.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/05ad458f-263b-413f-b054-6001a987ff3e.svg#05ad458f-263b-413f-b054-6001a987ff3e") format("svg");
}

@font-face {
    font-family: "Victoria-Titling-MT-W90";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2b6731dc-305d-4dcd-928e-805163e26288.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2b6731dc-305d-4dcd-928e-805163e26288.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/faceff42-b106-448b-b4cf-5b3a02ad61f1.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/82f103e4-7b1c-49af-862f-fe576da76996.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/46f6946a-4039-46e8-b001-be3e53068d46.svg#46f6946a-4039-46e8-b001-be3e53068d46") format("svg");
}

@font-face {
    font-family: "AmericanTypwrterITCW01--731025";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/dff8aebe-deee-47a7-8575-b2f39c8473f8.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/dff8aebe-deee-47a7-8575-b2f39c8473f8.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0c0f4d28-4c13-4e84-9a36-e63cd529ae86.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/7f26a278-84b3-4587-bf07-c8cdf7e347a9.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/254ab931-e6d6-4307-9762-5914ded49f13.svg#254ab931-e6d6-4307-9762-5914ded49f13") format("svg");
}

@font-face {
    font-family: "Soho-W01-Thin-Condensed";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b2d6b869-3f47-4c92-83d3-4546ffb860d0.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b2d6b869-3f47-4c92-83d3-4546ffb860d0.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f84b539d-ed34-4400-a139-c0f909af49aa.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9ef27401-09c0-434f-b0f0-784445b52ea2.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4ba3546a-32f7-4e7d-be64-8da01b23d46e.svg#4ba3546a-32f7-4e7d-be64-8da01b23d46e") format("svg");
}

@font-face {
    font-family: "Pacifica-W00-Condensed";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e50a5bb1-8246-4412-8c27-4a18ba89a0fd.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e50a5bb1-8246-4412-8c27-4a18ba89a0fd.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/6849614c-986c-45b1-a1a7-39c891759bb9.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/8ccb835c-4668-432d-8d1d-099b48aafe4e.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/028040ec-b956-41d8-a07d-b4d3466b8ed8.svg#028040ec-b956-41d8-a07d-b4d3466b8ed8") format("svg");
}

@font-face {
    font-family: "Avenida-W01";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/a8138b05-e5ff-482f-a8f6-8be894e01fc3.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/a8138b05-e5ff-482f-a8f6-8be894e01fc3.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/53f05821-c783-4593-bf20-c3d770f32863.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b7215bbe-7870-4733-9e81-28398fbed38b.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/bc2def79-bd99-49b9-98b3-502e34cc5552.svg#bc2def79-bd99-49b9-98b3-502e34cc5552") format("svg");
}

@font-face {
    font-family: "ITC-Arecibo-W01-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/036d6c0b-d067-431a-ab39-be3b89b1322f.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/036d6c0b-d067-431a-ab39-be3b89b1322f.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/5d6cd606-b520-4335-96e1-755691d666e8.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/03d7d783-5b99-4340-b373-97c00246ec27.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/a5fab48f-93a0-403a-b60e-bfdb0b69d973.svg#a5fab48f-93a0-403a-b60e-bfdb0b69d973") format("svg");
}

@font-face {
    font-family: "Droid-Serif-W01-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/de5702ce-174b-4ee6-a608-6482d5d7eb71.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/de5702ce-174b-4ee6-a608-6482d5d7eb71.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/83ae2051-dcdd-4931-9946-8be747a40d00.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/63f35b58-a40f-4f53-bb3e-20396f202214.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/19db6ebc-2d1b-4835-9588-3fa45ff36f4e.svg#19db6ebc-2d1b-4835-9588-3fa45ff36f4e") format("svg");
}

@font-face {
    font-family: "Museo-W01-700";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3b3d99a2-6b36-4912-a93e-29277020a5cf.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3b3d99a2-6b36-4912-a93e-29277020a5cf.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/28d74e9b-4ea9-4e3c-b265-c67a72c66856.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b432b4e1-014a-4ed8-865c-249744f856b0.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/8e63fd1e-adc9-460e-9ef7-bbf98ee32a71.svg#8e63fd1e-adc9-460e-9ef7-bbf98ee32a71") format("svg");
}

@font-face {
    font-family: "Museo-Slab-W01-100";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/01ab709f-22cf-4831-b24a-8cf4eb852687.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/01ab709f-22cf-4831-b24a-8cf4eb852687.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/cacc0862-f146-4746-92b1-60e6114a66c4.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/54006f54-b61e-4103-abf8-b1d0294a2a9c.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e5841f2e-b306-4583-bfc3-a0e06742fedd.svg#e5841f2e-b306-4583-bfc3-a0e06742fedd") format("svg");
}

@font-face {
    font-family: "Geotica-W01-Four-Open";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/91cc94e6-2c98-4b42-aaec-086abb6a9370.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/91cc94e6-2c98-4b42-aaec-086abb6a9370.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/cc0b2292-9358-41ee-b3b9-429952586f69.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/8558b493-da55-4e6f-b473-56d9c7dff2a4.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ee507e8d-069a-4cb6-b184-62b1f3ab0102.svg#ee507e8d-069a-4cb6-b184-62b1f3ab0102") format("svg");
}

@font-face {
    font-family: "Marzo-W00-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/45563891-20ab-4087-b16c-b3cfc26faac1.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/45563891-20ab-4087-b16c-b3cfc26faac1.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e947b76a-edcf-4519-bc3d-c2da35865717.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c09cb36e-5e79-4033-b854-41e57fbf44fa.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f4245069-28b7-43b7-8a10-708b9f3c398b.svg#f4245069-28b7-43b7-8a10-708b9f3c398b") format("svg");
}

@font-face {
    font-family: "ReklameScriptW00-Medium";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/5af7511a-dccc-450d-b2a2-bb8e3bb62540.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/5af7511a-dccc-450d-b2a2-bb8e3bb62540.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/05b176f5-c622-4c35-af98-c0c056dd5b66.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9dcb5a3c-1c64-4c9c-a402-995bed762eb7.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/1e87d66a-d7f1-4869-8430-51662777be57.svg#1e87d66a-d7f1-4869-8430-51662777be57") format("svg");
}

@font-face {
    font-family: "Nimbus-Sans-TW01Con";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2101adaa-6a98-4fa9-b085-3b04c3722637.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2101adaa-6a98-4fa9-b085-3b04c3722637.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/8fb1090e-b4d0-4685-ac8f-3d0c29d60130.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/5d5fc44e-e84b-48ca-a5a7-bed8bdbf79a1.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/24512b2a-e22d-4ebb-887c-a334d039433c.svg#24512b2a-e22d-4ebb-887c-a334d039433c") format("svg");
}

@font-face {
    font-family: "Bodoni-W01-Poster";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ab0e3d15-2f64-49c1-8898-817a2235e719.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ab0e3d15-2f64-49c1-8898-817a2235e719.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4d1b9848-7ebd-472c-9d31-4af0aa7faaea.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/197b5ef7-65e6-4af6-9fd9-bc9fc63038c7.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/a9bda117-c293-40b5-a2d8-9f923f32623c.svg#a9bda117-c293-40b5-a2d8-9f923f32623c") format("svg");
}

/* Mobile system fallbacks */

@font-face {
    font-family: "Comic-Sans-W01-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0d67e115-f220-4a6a-81c2-ae0035bda922.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0d67e115-f220-4a6a-81c2-ae0035bda922.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/234c98b8-36ae-45ab-8a55-77980708b2bc.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/7ff2970c-1d51-47be-863d-b33afda8fb40.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f1afa7d8-abee-4268-9cf8-85d43150fdb1.svg#f1afa7d8-abee-4268-9cf8-85d43150fdb1") format("svg");
}

@font-face {
    font-family: "Courier-PS-W01";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b2977c8d-4907-4cc3-b5ed-3dec9ca68102.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b2977c8d-4907-4cc3-b5ed-3dec9ca68102.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b059d02a-a222-4c63-9fd3-705eaeea1c16.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/52e3d484-7188-4c9e-964e-b7a75e9dfa2f.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c2182c36-8eb4-4a56-a0ff-dba7492ce96c.svg#c2182c36-8eb4-4a56-a0ff-dba7492ce96c") format("svg");
}

@font-face {
    font-family: "Impact-W01-2010";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9ae7059b-dd17-4a4c-8872-5cb4dd551277.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9ae7059b-dd17-4a4c-8872-5cb4dd551277.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4cefdf47-0136-4169-9933-3225dbbec9d9.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f7450934-42f3-4193-befa-c825772a9454.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/25aa5449-ccc1-4f0e-ab3f-4cf3b959208f.svg#25aa5449-ccc1-4f0e-ab3f-4cf3b959208f") format("svg");
}

@font-face {
    font-family: "Lucida-Console-W01";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/527cb305-deee-4810-b337-67756678c830.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/527cb305-deee-4810-b337-67756678c830.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/60f4a13f-3943-432a-bb51-b612e41239c5.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/38229089-ebec-4782-b8f2-304cfdcea8d8.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f855783c-1079-4396-a7b7-f7d9179145be.svg#f855783c-1079-4396-a7b7-f7d9179145be") format("svg");
}

@font-face{
    font-family:"Tahoma-W01-Regular";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/1b155b1c-e651-4a51-9d03-0ca480aeaf9f.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/1b155b1c-e651-4a51-9d03-0ca480aeaf9f.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/20323430-24f4-4767-9d4d-060d1e89758a.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/6e17e62d-30cb-4840-8e9d-328c6b62316e.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/04ab3894-45ce-42ef-aa11-e7c0cd7f7da9.svg#04ab3894-45ce-42ef-aa11-e7c0cd7f7da9") format("svg");
}

@font-face{
    font-family:"Arial-W01-Black";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/bf85e414-1b16-4cd1-8ce8-dad15daa7daa.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/bf85e414-1b16-4cd1-8ce8-dad15daa7daa.eot?#iefix") format("eot"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c6f5bcd6-66fc-44af-be95-bb1f2b38d080.woff") format("woff"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/7b5b436b-a511-402a-88d6-dbac700cee36.ttf") format("truetype"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/a5adcd35-c36a-4b18-953d-47c029de4ef6.svg#a5adcd35-c36a-4b18-953d-47c029de4ef6") format("svg");
}

/* Greek and others */

@font-face{
    font-family:"Tahoma-W15--Regular";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f0dd334c-878c-442c-bda3-0dbd122e87f1.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f0dd334c-878c-442c-bda3-0dbd122e87f1.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ae844b11-5158-4caf-90b4-7ace49ac3440.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e63ef4f4-b7b9-4f13-8db5-d7f5cf89839f.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/5ad2ed93-1ba0-4b2c-a421-22c5bcfb5b79.svg#5ad2ed93-1ba0-4b2c-a421-22c5bcfb5b79") format("svg");
}

@font-face{
    font-family:"Tahoma-W99-Regular";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c3ebf729-2608-4787-9e5a-248f329aface.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c3ebf729-2608-4787-9e5a-248f329aface.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/d3bbaa1b-d5e3-431f-93a7-9cea63601bb6.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/78cb924f-227d-4ab9-83d5-f2b2e6656da5.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ca045297-34e1-462e-acc8-75ef196ada02.svg#ca045297-34e1-462e-acc8-75ef196ada02") format("svg");
}

/*******************/

@font-face {
    font-family: "Coquette-W00-Light";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b8c1ddea-29ea-42ec-8a48-32a89e792d3b.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b8c1ddea-29ea-42ec-8a48-32a89e792d3b.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4e5374b3-a214-41e5-81f0-a34c9292da7e.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c20581c8-0023-4888-aeaa-9d32636dc17f.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e514ed32-1687-47d8-8b39-423fb7664d33.svg#e514ed32-1687-47d8-8b39-423fb7664d33") format("svg");
}

@font-face {
    font-family: "Rosewood-W01-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/bd86870e-0679-4116-aa13-96aa1d6c5944.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/bd86870e-0679-4116-aa13-96aa1d6c5944.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4d9bc879-ab51-45da-bf37-c9710cd1cc32.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/a5564fdb-3616-4f27-a4e4-d932b6ae5b4a.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f128ef28-daf3-477b-8027-0fd8bdad2b91.svg#f128ef28-daf3-477b-8027-0fd8bdad2b91") format("svg");
}

@font-face {
    font-family: "segoe_printregular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/segoe_print-webfont.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/segoe_print-webfont.eot?#iefix") format("eot"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/segoe_print-webfont.woff") format("woff"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/segoe_print-webfont.ttf") format("truetype"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/segoe_print-webfont.svg#f128ef28-daf3-477b-8027-0fd8bdad2b91") format("svg");
}

@font-face {
    font-family: 'Open Sans';
    font-style: normal;
    font-weight: 400;
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-regular-webfont.eot');
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-regular-webfont.eot?#iefix') format('embedded-opentype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-regular-webfont.woff') format('woff'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-regular-webfont.ttf') format('truetype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-regular-webfont.svg#open_sansregular') format('svg');
}

@font-face {
    font-family: 'Open Sans';
    font-style: normal;
    font-weight: 700;
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-bold-webfont.eot');
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-bold-webfont.eot?#iefix') format('embedded-opentype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-bold-webfont.woff') format('woff'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-bold-webfont.ttf') format('truetype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-bold-webfont.svg#open_sansregular') format('svg');
}

@font-face {
    font-family: 'Open Sans';
    font-style: italic;
    font-weight: 400;
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-italic-webfont.eot');
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-italic-webfont.eot?#iefix') format('embedded-opentype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-italic-webfont.woff') format('woff'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-italic-webfont.ttf') format('truetype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-italic-webfont.svg#open_sansregular') format('svg');
}

@font-face {
    font-family: 'Open Sans';
    font-style: italic;
    font-weight: 700;
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-bolditalic-webfont.eot');
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-bolditalic-webfont.eot?#iefix') format('embedded-opentype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-bolditalic-webfont.woff') format('woff'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-bolditalic-webfont.ttf') format('truetype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-bolditalic-webfont.svg#open_sansregular') format('svg');
}

@font-face{
    font-family:"Avenir-LT-W01_35-Light1475496";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/edefe737-dc78-4aa3-ad03-3c6f908330ed.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/edefe737-dc78-4aa3-ad03-3c6f908330ed.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0078f486-8e52-42c0-ad81-3c8d3d43f48e.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/908c4810-64db-4b46-bb8e-823eb41f68c0.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4577388c-510f-4366-addb-8b663bcc762a.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b0268c31-e450-4159-bfea-e0d20e2b5c0c.svg#b0268c31-e450-4159-bfea-e0d20e2b5c0c") format("svg");
}
@font-face{
    font-family:"Avenir-LT-W01_85-Heavy1475544";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/6af9989e-235b-4c75-8c08-a83bdaef3f66.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/6af9989e-235b-4c75-8c08-a83bdaef3f66.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/d513e15e-8f35-4129-ad05-481815e52625.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/61bd362e-7162-46bd-b67e-28f366c4afbe.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ccd17c6b-e7ed-4b73-b0d2-76712a4ef46b.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/20577853-40a7-4ada-a3fb-dd6e9392f401.svg#20577853-40a7-4ada-a3fb-dd6e9392f401") format("svg");
}
@font-face{
    font-family:"BaskervilleMTW01-SmBdIt";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0224f3fd-52d3-499a-ae2f-637a041f87f0.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0224f3fd-52d3-499a-ae2f-637a041f87f0.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c887df8e-b6c3-4c97-85b8-91cfdde77b07.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/5c4d5432-75c4-4f6b-a6e7-8af4d54a33d1.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2ee46b89-b7cb-4bbe-9d60-b7ca4354b706.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9714d635-13b3-48b2-9315-5d0f72a69ab9.svg#9714d635-13b3-48b2-9315-5d0f72a69ab9") format("svg");
}
@font-face{
    font-family:"Belinda-W00-Regular";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/63d38753-a8d9-4262-b844-3a007ad848b4.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/63d38753-a8d9-4262-b844-3a007ad848b4.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/242487aa-209a-4dbd-aca2-64a3c73a8946.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4381b252-d9f8-4201-bbf3-9440e21259e7.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/46c2c4f2-cd15-4b7b-a4b4-aa04dbbd1655.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/334f8999-3703-47f3-b147-96b6dc3bf4b2.svg#334f8999-3703-47f3-b147-96b6dc3bf4b2") format("svg");
}
@font-face{
    font-family:"Brandon-Grot-W01-Light";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e00ba30a-0bf3-4c76-9392-8641fa237a92.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e00ba30a-0bf3-4c76-9392-8641fa237a92.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/69b40392-453a-438a-a121-a49e5fbc9213.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9362bca5-b362-4543-a051-2129e2def911.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/85060878-ca6c-43cc-ac31-7edccfdca71b.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/47f089a6-c8ce-46fa-b98f-03b8c0619d8a.svg#47f089a6-c8ce-46fa-b98f-03b8c0619d8a") format("svg");
}
@font-face{
    font-family:"Bree-W01-Thin-Oblique";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4e33bf74-813a-4818-8313-6ea9039db056.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4e33bf74-813a-4818-8313-6ea9039db056.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ceb3b4a3-0083-44ae-95cb-e362f95cc91b.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4d716cea-5ba0-437a-b5a8-89ad159ea2be.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c458fc09-c8dd-4423-9767-e3e27082f155.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/85ffb31e-78ee-4e21-83d8-4313269135a9.svg#85ffb31e-78ee-4e21-83d8-4313269135a9") format("svg");
}
@font-face{
    font-family:"Adobe-Caslon-W01-SmBd";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/d2804130-67b0-4fcf-98fe-d781df92a56e.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/d2804130-67b0-4fcf-98fe-d781df92a56e.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/becfadb1-eaca-4817-afbd-fe4d61e1f661.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/6530bac7-21ac-4e52-a014-dce6a8d937ab.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b34e8a45-c92d-4402-89bc-43cc51c6b4e0.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0804bb4a-399c-4547-9fa8-0acf6268d8f6.svg#0804bb4a-399c-4547-9fa8-0acf6268d8f6") format("svg");
}
@font-face{
    font-family:"Didot-W01-Italic";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9c2cfd19-472b-4ef5-ad73-43eee68dc43b.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9c2cfd19-472b-4ef5-ad73-43eee68dc43b.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/abe3d3a9-c990-459f-9407-54ac96cd2f00.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/09a4b57b-7400-4d30-b4ba-d6e303c57868.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/a0cb08d5-975f-4c8d-bcdc-d771a014d92a.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/86d60a09-e8f8-4003-b688-0f8a2aba6532.svg#86d60a09-e8f8-4003-b688-0f8a2aba6532") format("svg");
}
@font-face{
    font-family:"Futura-LT-W01-Light";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2b40e918-d269-4fd9-a572-19f5fec7cd7f.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2b40e918-d269-4fd9-a572-19f5fec7cd7f.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/26091050-06ef-4fd5-b199-21b27c0ed85e.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/cca525a8-ad89-43ae-aced-bcb49fb271dc.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/88cc7a39-1834-4468-936a-f3c25b5d81a1.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/14d6bf5d-15f1-4794-b18e-c03fb9a5187e.svg#14d6bf5d-15f1-4794-b18e-c03fb9a5187e") format("svg");
}
@font-face{
    font-family:"Futura-LT-W01-Book";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/cf053eae-ba1f-44f3-940c-a34b68ccbbdf.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/cf053eae-ba1f-44f3-940c-a34b68ccbbdf.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/8bf38806-3423-4080-b38f-d08542f7e4ac.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e2b9cbeb-fa8e-41cd-8a6a-46044b29ba52.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c2a69697-4f06-4764-abd4-625031a84e31.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/dc423cc1-bf86-415c-bc7d-ad7dde416a34.svg#dc423cc1-bf86-415c-bc7d-ad7dde416a34") format("svg");
}
@font-face{
    font-family:"Kepler-W03-Light-SCd-Cp";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/fc00d5ae-6d96-4b5c-b68b-4f5bdb562c98.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/fc00d5ae-6d96-4b5c-b68b-4f5bdb562c98.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b2b1472c-55f2-478a-a9c9-9373214a27e5.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/20f7861b-3ff7-47f3-b0f5-1e0626824a63.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/5c51e7a0-6ecc-46eb-a9ee-376f8c4073af.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/37bea6d0-2f14-4e48-a76f-fd85171dcf26.svg#37bea6d0-2f14-4e48-a76f-fd85171dcf26") format("svg");
}
@font-face{
    font-family:"Lulo-Clean-W01-One-Bold";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0163ac22-50a7-406e-aa64-c62ee6fbf3d7.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0163ac22-50a7-406e-aa64-c62ee6fbf3d7.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/aee74cb3-c913-4b54-9722-6001c92325f2.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/80de9d5d-ab5f-40ce-911b-104e51e93d7c.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/1b46b05b-cfdd-4d82-8c2f-5c6cfba1fe60.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/be340f0b-a2d4-41df-acb1-4dc124330a88.svg#be340f0b-a2d4-41df-acb1-4dc124330a88") format("svg");
}
@font-face{
    font-family:"Proxima-N-W01-Reg";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/7e90123f-e4a7-4689-b41f-6bcfe331c00a.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/7e90123f-e4a7-4689-b41f-6bcfe331c00a.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/64017d81-9430-4cba-8219-8f5cc28b923e.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e56ecb6d-da41-4bd9-982d-2d295bec9ab0.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2aff4f81-3e97-4a83-9e6c-45e33c024796.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ab9cd062-380f-4b53-b1a7-c0bec7402235.svg#ab9cd062-380f-4b53-b1a7-c0bec7402235") format("svg");
}
@font-face{
    font-family:"Trend-Sans-W00-Four";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/392aa98f-a1bf-4dc4-9def-a5d27c73a0de.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/392aa98f-a1bf-4dc4-9def-a5d27c73a0de.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/29c66f1e-5243-4f34-8a19-47405f72954c.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c81cca03-5f1a-4252-9950-096e60e2bde9.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/569b48ce-f71b-4e2d-a80a-1920efbd7187.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f284409f-3669-43df-bfe1-f9f9ee1bbc07.svg#f284409f-3669-43df-bfe1-f9f9ee1bbc07") format("svg");
}

@font-face{
    font-family:"DINNeuzeitGroteskLTW01-_812426";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b41558bd-2862-46c0-abf7-536d2542fa26.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b41558bd-2862-46c0-abf7-536d2542fa26.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/5cee8d6e-89ad-4d8c-a0ac-584d316b15ae.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/388ef902-2c31-4818-abb1-a40dcd81f6d6.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/29c60077-2614-4061-aa8d-5bcfdf7354bb.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/76250d27-b353-4f3b-90c6-0ff635fabaab.svg#76250d27-b353-4f3b-90c6-0ff635fabaab") format("svg");
}
@font-face{
    font-family:"Peaches-and-Cream-Regular-W00";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2250f930-9a6d-4486-a0eb-6b407c5d6c9b.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2250f930-9a6d-4486-a0eb-6b407c5d6c9b.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3c5beda8-45cc-4f76-abca-8eccfeb6220c.woff2") format("woff2"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b36b499f-d776-461c-bacb-fcbebe1cb9b4.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/896d3828-26ce-462a-9f70-62e0b5c90a70.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0dccbec2-a882-4dd9-8da0-3a035c808ce0.svg#0dccbec2-a882-4dd9-8da0-3a035c808ce0") format("svg");
}

/* latin-ext */

@font-face {
    font-family: "Helvetica-W02-Roman";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e4bd4516-4480-43df-aa6e-4e9b9029f53e.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e4bd4516-4480-43df-aa6e-4e9b9029f53e.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b56b944e-bbe0-4450-a241-de2125d3e682.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/7da02f05-ae8b-43a1-aeb9-83b3c0527c06.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/66cac56e-d017-4544-9d0c-f7d978f0c5c2.svg#66cac56e-d017-4544-9d0c-f7d978f0c5c2") format("svg");
}

@font-face {
    font-family: "Helvetica-W02-Bold";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/8c0d8b0f-d7d6-4a72-a418-c2373e4cbf27.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/8c0d8b0f-d7d6-4a72-a418-c2373e4cbf27.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/192dac76-a6d9-413d-bb74-22308f2e0cc5.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/47584448-98c4-436c-89b9-8d6fbeb2a776.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/375c70e5-6822-492b-8408-7cd350440af7.svg#375c70e5-6822-492b-8408-7cd350440af7") format("svg");
}

@font-face {
    font-family: "Clarendon-W02-Medium-693834";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/be976e1d-6edc-4a1b-b50e-a6d326b5a02f.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/be976e1d-6edc-4a1b-b50e-a6d326b5a02f.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/01681361-4a95-4651-a6c8-4005d0fc4a79.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/fdc26895-148e-4fa8-898d-5eb459dabecf.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/d59136e2-c38a-4ad4-8dec-2d258c12fd80.svg#d59136e2-c38a-4ad4-8dec-2d258c12fd80") format("svg");
}

@font-face {
    font-family: "DIN-Next-W02-Light";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/48e5a0e1-2d56-46e5-8fc4-3d6d5c973cbf.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/48e5a0e1-2d56-46e5-8fc4-3d6d5c973cbf.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/07d62b21-8d7a-4c36-be86-d32ab1089972.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c0050890-bbed-44b9-94df-2611d72dbb06.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9f774d17-c03a-418e-a375-34f3beecbc7a.svg#9f774d17-c03a-418e-a375-34f3beecbc7a") format("svg");
}

@font-face {
    font-family: "AmericanTypwrterITCW02--737091";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/04bcef92-4ec9-4491-9f06-433987df0eea.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/04bcef92-4ec9-4491-9f06-433987df0eea.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4e5713c6-f9bf-44d7-bc17-775b7c102f1c.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/80e40eb9-815f-4b42-9e99-297117a6ef52.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/25bb0c90-be7f-4dfc-bfff-5cd159d09832.svg#25bb0c90-be7f-4dfc-bfff-5cd159d09832") format("svg");
}

@font-face {
    font-family: "Helvetica-W02-Light";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ff80873b-6ac3-44f7-b029-1b4111beac76.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ff80873b-6ac3-44f7-b029-1b4111beac76.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/80c34ad2-27c2-4d99-90fa-985fd64ab81a.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b8cb02c2-5b58-48d8-9501-8d02869154c2.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/92c941ea-2b06-4b72-9165-17476d424d6c.svg#92c941ea-2b06-4b72-9165-17476d424d6c") format("svg");
}

@font-face {
    font-family: "Soho-W02-Thin-Condensed";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/61d1e245-4016-4f23-ad7a-409a44cabe90.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/61d1e245-4016-4f23-ad7a-409a44cabe90.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/68eb3cfd-be6c-4f9e-8ca4-e13ce8d29329.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/6db04d94-de0b-4bf0-bf94-113fd27e7440.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/84e110e9-fd29-4036-b9ad-27968a6ba793.svg#84e110e9-fd29-4036-b9ad-27968a6ba793") format("svg");
}

@font-face {
    font-family: "Avenida-W02";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/131201ff-3951-4583-b4d9-2bc668927583.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/131201ff-3951-4583-b4d9-2bc668927583.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/582278da-0505-4fbe-9102-2b529c7c973a.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b82fbde2-1655-4728-96a9-90ef022c4590.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/d325b64f-214b-4fc0-80d6-4c61621cd542.svg#d325b64f-214b-4fc0-80d6-4c61621cd542") format("svg");
}

@font-face {
    font-family: "Droid-Serif-W02-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/872d17cf-70ac-4722-b8ef-0f1578125042.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/872d17cf-70ac-4722-b8ef-0f1578125042.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/764779cf-076d-427a-87b4-136ccc83fba0.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f32cc734-5673-41a1-bd6e-1900c78691f5.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f627e21b-c1a5-4e7a-b072-37391ee8dcef.svg#f627e21b-c1a5-4e7a-b072-37391ee8dcef") format("svg");
}

/* Mobile system fallbacks */

@font-face {
    font-family: "Comic-Sans-W02-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/6a8b1499-f534-46fe-a0af-835bc83226cd.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/6a8b1499-f534-46fe-a0af-835bc83226cd.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/301e2ea2-8153-453c-9051-0a729098e682.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/cbe882c0-2ac0-4a28-8fe7-14e527942047.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ec680f09-6b07-442d-ab11-cea208cc138d.svg#ec680f09-6b07-442d-ab11-cea208cc138d") format("svg");
}

@font-face {
    font-family: "Courier-PS-W02";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/440875eb-e437-41fc-8aae-b5658bbea3b7.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/440875eb-e437-41fc-8aae-b5658bbea3b7.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/bcc470b9-5a9b-45e9-bf60-6daca06bc70e.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f9018056-f579-4c4c-95ea-9bd02b859724.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f6d0e775-b2fc-4bc8-8967-cd78486d451c.svg#f6d0e775-b2fc-4bc8-8967-cd78486d451c") format("svg");
}

@font-face {
    font-family: "Impact-W02-2010";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/02fb45ce-d7cc-491c-a176-e2a883a632b2.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/02fb45ce-d7cc-491c-a176-e2a883a632b2.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/eb1185bb-8f9d-4855-83fa-d06f0efef677.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/5386718d-bec6-41c5-b998-12dd1c859c53.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/01aba52b-d32b-41fc-a681-d7b4dfa43041.svg#01aba52b-d32b-41fc-a681-d7b4dfa43041") format("svg");
}

@font-face {
    font-family: "Lucida-Console-W02";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/5606db21-eb18-48fa-979b-63bdf28555c0.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/5606db21-eb18-48fa-979b-63bdf28555c0.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3e5b24ea-4345-4830-8c7d-0e7ef26b4e63.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/7b175f51-ff6c-47d2-908c-ee8538c2880d.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/bd1a6a52-e0c2-4a1b-b5a4-2d25ec2b5706.svg#bd1a6a52-e0c2-4a1b-b5a4-2d25ec2b5706") format("svg");
}

@font-face {
    font-family: "Tahoma-W02-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/bb223dcd-0a16-4e5a-b38b-4f2a29f2bcbb.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/bb223dcd-0a16-4e5a-b38b-4f2a29f2bcbb.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/94e45703-fbd7-46e5-9fcd-228ae59d6266.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ef282b80-58de-4b03-a90f-c5703d54e3b7.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/cb11dfc6-f3c4-4a58-83ac-df735ba9c428.svg#cb11dfc6-f3c4-4a58-83ac-df735ba9c428") format("svg");
}

@font-face {
    font-family: "Rosewood-W08-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f432fcbc-ae52-4db1-a4b3-c7145e69b3b6.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f432fcbc-ae52-4db1-a4b3-c7145e69b3b6.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/62a23651-230c-4724-b2c0-087544ed1a27.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e46f32da-eb61-45e5-a1b8-49f3a5f782f8.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9e73fac6-b45b-4ac5-a601-9a0d70cd45b2.svg#9e73fac6-b45b-4ac5-a601-9a0d70cd45b2") format("svg");
}

@font-face{
    font-family:"Arial-W02-Black";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c06088a2-994d-44b4-9b38-55d2ae9e13a9.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c06088a2-994d-44b4-9b38-55d2ae9e13a9.eot?#iefix") format("eot"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/41280d6d-9240-4d82-9e98-3ea1a1913501.woff") format("woff"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/bc33f504-28ac-46ae-b258-d4fd1f599c47.ttf") format("truetype"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0faa6338-fe10-42e6-9346-2c6626ddcd73.svg#0faa6338-fe10-42e6-9346-2c6626ddcd73") format("svg");
}

/* cyrillic */
@font-face {
    font-family: "DIN-Next-W10-Light";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3d009cd7-c8fe-40c0-93da-74f4ea8c530b.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3d009cd7-c8fe-40c0-93da-74f4ea8c530b.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/a9e95a29-98a7-404a-90ee-1929ad09c696.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0a7663fd-eae8-4e50-a67a-225271f8cceb.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/58ae9be9-5d95-44b6-8b6c-e6da6a46822c.svg#58ae9be9-5d95-44b6-8b6c-e6da6a46822c") format("svg");
}

@font-face {
    font-family: "Helvetica-LT-W10-Bold";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9fe262dc-5a55-4d75-91a4-aed76bd32190.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9fe262dc-5a55-4d75-91a4-aed76bd32190.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0a3939d0-3833-4db3-8b85-f64c2b3350d2.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/1b128d6d-126f-4c9c-8f87-3e7d30a1671c.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b791c850-fde1-48b3-adf0-8998d55b0866.svg#b791c850-fde1-48b3-adf0-8998d55b0866") format("svg");
}

@font-face {
    font-family: "Helvetica-LT-W10-Roman";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/686a6a06-e711-4bd2-b393-8504a497bb3c.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/686a6a06-e711-4bd2-b393-8504a497bb3c.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/6f8d1983-4d34-4fa4-9110-988f6c495757.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/7903ee3f-e9ab-4bdc-b7d2-d232de2da580.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9c58e9ea-fdea-4b9c-b0f9-0a2157389ed0.svg#9c58e9ea-fdea-4b9c-b0f9-0a2157389ed0") format("svg");
}

@font-face {
    font-family: "Bodoni-Poster-W10";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3f2ac2b4-0662-446d-8b8a-51738492ea04.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3f2ac2b4-0662-446d-8b8a-51738492ea04.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e04da7b7-ccbf-4cbf-b19a-947551d17de6.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/cb3483cd-190a-4634-b345-d88f22f1e6f5.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/fea2ad42-3ce1-43c4-b571-39159cc109a6.svg#fea2ad42-3ce1-43c4-b571-39159cc109a6") format("svg");
}

@font-face {
    font-family: "Droid-Serif-W10-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/d039cfc8-41eb-46d5-ad1a-faf4f0d26222.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/d039cfc8-41eb-46d5-ad1a-faf4f0d26222.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/571d67cb-de3d-41af-8c0a-06a53d490466.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/70f941f5-d702-4e7b-8b15-ee65e6b855b9.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e0ffd68e-55a8-4537-b2d1-c51865ac15ee.svg#e0ffd68e-55a8-4537-b2d1-c51865ac15ee") format("svg");
}

/* Mobile system fallbacks */

@font-face {
    font-family: "Comic-Sans-W10-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/6ea78fbd-72da-406c-bd23-556297e62ebb.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/6ea78fbd-72da-406c-bd23-556297e62ebb.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/73381861-eb6a-4f7c-8c14-cd34a714f943.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/93adf2cf-f54c-4a73-8ec7-43fe0b2c91a1.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/a89d4dba-ce62-4aaa-8187-bea28a2b3a90.svg#a89d4dba-ce62-4aaa-8187-bea28a2b3a90") format("svg");
}

@font-face {
    font-family: "Courier-PS-W10";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/efcef8d3-4e54-4965-a5f0-67f288d40c0a.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/efcef8d3-4e54-4965-a5f0-67f288d40c0a.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2593bfe2-2f34-4218-a1e2-fde3bdc686e1.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e84e67b7-d822-43f4-80a9-315fddffd712.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/7bbc8148-b9e2-49ad-bd2a-b6a8ba78efa6.svg#7bbc8148-b9e2-49ad-bd2a-b6a8ba78efa6") format("svg");
}

@font-face {
    font-family: "Impact-W10-2010";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2f6579cb-5ade-4b70-a96a-8fe9485fe73f.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2f6579cb-5ade-4b70-a96a-8fe9485fe73f.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/1c7b5ef1-5b09-4473-8003-a974846653a7.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/805172a0-d718-48ac-9053-873641b3e236.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/1979f98e-b074-4385-81b0-772f28a00668.svg#1979f98e-b074-4385-81b0-772f28a00668") format("svg");
}

@font-face {
    font-family: "Lucida-Console-W10-0";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e9678295-b67a-4b01-bfb4-a357fa5dd939.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e9678295-b67a-4b01-bfb4-a357fa5dd939.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2c0bffef-a666-4646-a4bc-7faf1fa689f5.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4696d714-e3c0-4351-9df8-2e4449d30c3d.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/936712ee-6903-4ab8-b6ad-99e7ca1721d0.svg#936712ee-6903-4ab8-b6ad-99e7ca1721d0") format("svg");
}

@font-face {
    font-family: "Tahoma-W10-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/50c03b26-fd3d-4fa1-96d0-d88b72129c4f.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/50c03b26-fd3d-4fa1-96d0-d88b72129c4f.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9ee00678-b6d7-4b4f-8448-70cfa267d36b.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/6861fb60-a657-44e2-92fa-86bd26cd2657.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/bf5f466c-6f51-449d-91b3-32f1f0c2b796.svg#bf5f466c-6f51-449d-91b3-32f1f0c2b796") format("svg");
}

@font-face{
    font-family:"Arial-W10-Black";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/26819459-0b68-486b-ae05-2ecdbd222feb.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/26819459-0b68-486b-ae05-2ecdbd222feb.eot?#iefix") format("eot"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/7cfb7eb0-2332-4048-a7f4-2c3fa389c3a3.woff") format("woff"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2edafc36-cb97-4b1a-8803-a7b2e6125929.ttf") format("truetype"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/00760470-0987-4c68-844d-564282fc8ff9.svg#00760470-0987-4c68-844d-564282fc8ff9") format("svg");
}

/* korean */
@font-face {
    font-family: "FBBlueGothicL";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/902109a4-ea36-40b3-a234-05747684a610.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/902109a4-ea36-40b3-a234-05747684a610.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/1a10c1c0-157a-4f57-96c1-1af2fc242e06.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/31b02a27-3c41-4593-bfbf-84702627c9fd.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e4aaa0ee-fcdd-4558-9d8e-be75c6b8c417.svg#e4aaa0ee-fcdd-4558-9d8e-be75c6b8c417") format("svg");
}

@font-face {
    font-family: "FBChamBlue";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3df084ed-47e4-4347-91c7-44d290c2c093.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3df084ed-47e4-4347-91c7-44d290c2c093.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/75c0e570-e4e0-4e86-a031-1ade01e5b3f5.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b9eacc4f-ef9b-4ff5-bf09-ffca8edc43e2.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/12333ad5-3ac0-4a7d-b109-6d8c8101515a.svg#12333ad5-3ac0-4a7d-b109-6d8c8101515a") format("svg");
}

@font-face {
    font-family: "FBGreen";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/89bbab6a-1291-4439-9384-bc7e36aae8e0.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/89bbab6a-1291-4439-9384-bc7e36aae8e0.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/399c1f00-ff31-4f87-868c-bcbfcabcdd51.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ad6cc8e5-052c-4d6c-ab7b-66b2f70edb5f.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0045c511-e366-4e81-bd42-131808ac750f.svg#0045c511-e366-4e81-bd42-131808ac750f") format("svg");
}

@font-face {
    font-family: "FBNeoGothic";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3323e5a2-cefa-4887-9de9-9fd287987664.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3323e5a2-cefa-4887-9de9-9fd287987664.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c52a9d59-984f-45b4-bfd7-6f6af54eb89f.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/58e6245d-754a-4a05-9bd2-25a655e31640.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/29c28905-cc56-4077-86f5-917ad8e34c1c.svg#29c28905-cc56-4077-86f5-917ad8e34c1c") format("svg");
}

@font-face {
    font-family: "FBPlum";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/837a8a7f-bb60-42ed-a5bc-c9368cc1ecba.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/837a8a7f-bb60-42ed-a5bc-c9368cc1ecba.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/101fd386-ed60-4ed9-8ac2-80d0492347ac.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/5539addf-e60b-4fba-a356-cbab8abd16c6.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/6329eea0-a953-45d7-9074-6f0594e27df7.svg#6329eea0-a953-45d7-9074-6f0594e27df7") format("svg");
}

@font-face {
    font-family: "NanumGothic-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/nanum-gothic-regular.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/nanum-gothic-regular.eot?#iefix") format("eot"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/nanum-gothic-regular.woff") format("woff"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/nanum-gothic-regular.ttf") format("truetype");
}

@font-face {
    font-family: "BM-HANNA";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/bm-hanna.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/bm-hanna.eot?#iefix") format("eot"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/bm-hanna.woff") format("woff"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/bm-hanna.ttf") format("truetype");
}

/* arabic */
@font-face {
    font-family: "AhmedLTW20-OutlineRegul";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3b019dda-5201-4a96-ab40-449f0785e578.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3b019dda-5201-4a96-ab40-449f0785e578.eot?#iefix") format("eot"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/bc9495bd-5edc-4c5b-be28-dfb45e27e688.woff") format("woff"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/bcaca41c-2840-4aef-9fb4-f0c66589e9cd.ttf") format("truetype"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b5000ada-6fa4-4aae-8c7e-6e6abda2be56.svg#b5000ada-6fa4-4aae-8c7e-6e6abda2be56") format("svg");
}

@font-face {
    font-family: "Arian-LT-W20-Light";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3e151393-e605-418c-8050-fb734e7b64b3.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3e151393-e605-418c-8050-fb734e7b64b3.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c977bad6-94c3-457c-9771-d8e0017a33c2.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/a7bdf7c7-b425-4dae-b583-9f86ec510f9f.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/da80aad9-b3bc-417c-963f-b9033a872ec1.svg#da80aad9-b3bc-417c-963f-b9033a872ec1") format("svg");
}

@font-face {
    font-family: "Arian-LT-W20-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/64ef878b-c690-447b-a020-f4491b2de821.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/64ef878b-c690-447b-a020-f4491b2de821.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c257a373-9919-458c-b7b2-83850775058d.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/afa67eb7-2358-4d1d-bdcd-da0436f5cfb2.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/57ba934e-c7af-4166-a22c-48eaf65f26bb.svg#57ba934e-c7af-4166-a22c-48eaf65f26bb") format("svg");
}

@font-face {
    font-family: "Janna-LT-W20-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/a9c47d30-0eca-434f-8082-ac141c4c97b3.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/a9c47d30-0eca-434f-8082-ac141c4c97b3.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/26c24286-5aab-4747-81b9-54330e77fb14.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9c4c7fff-85b6-442f-9726-af5f49d49e53.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/a24f53ee-e15e-4931-89a3-b6f17fbfcd72.svg#a24f53ee-e15e-4931-89a3-b6f17fbfcd72") format("svg");
}

@font-face {
    font-family: "Kufi-LT-W20-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/774ebfa2-6ac0-48cf-8c15-1394d7bab265.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/774ebfa2-6ac0-48cf-8c15-1394d7bab265.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e0e311dc-5674-493c-8c19-f0a0a1422837.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/96829dee-2b11-4389-a3b6-35eabd423234.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e7b93a7e-e623-4628-809c-4ae5df08148b.svg#e7b93a7e-e623-4628-809c-4ae5df08148b") format("svg");
}

@font-face {
    font-family: "HelveticaNeueLTW20-Ligh";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ab7f002d-5f09-4a65-b7ad-9f01ec5bfaf0.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ab7f002d-5f09-4a65-b7ad-9f01ec5bfaf0.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b8ee7e47-48e4-4b5b-8a74-cf02708fb54a.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/074fa346-a8c5-4331-9d93-7a06123af067.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e953f49c-15a9-4394-97dd-a3f230e12e0b.svg#e953f49c-15a9-4394-97dd-a3f230e12e0b") format("svg");
}

@font-face {
    font-family: "Midan-W20";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4d56c718-5282-4923-867f-763af2fa8575.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4d56c718-5282-4923-867f-763af2fa8575.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/be87d34b-77db-4286-87d9-d2964115c6c5.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/539016b8-1f78-4507-b542-c9e55b269ac6.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/3b8c2857-0ab3-4ea6-90bc-9928bf53340c.svg#3b8c2857-0ab3-4ea6-90bc-9928bf53340c") format("svg");
}

@font-face {
    font-family: "TanseekModernW20-Light";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/73d94c9b-15bd-4af9-bda1-c5ee4ed1c409.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/73d94c9b-15bd-4af9-bda1-c5ee4ed1c409.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/688d77ff-8c0d-4baf-ac95-f45c034e1caf.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/177fb002-a619-4d25-8a79-af7d0e9a1ee6.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/4fa09e39-beb9-46ca-bfcc-f9518ab4a9bd.svg#4fa09e39-beb9-46ca-bfcc-f9518ab4a9bd") format("svg");
}

@font-face {
    font-family: "DINNextLTW23-UltraLight";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b4a0535b-3a89-43bd-b3fb-b6619d0b0a09.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b4a0535b-3a89-43bd-b3fb-b6619d0b0a09.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/63b0b154-64e6-4846-be80-b601f3ce9b28.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f3f08f13-d46f-4589-90ac-70c0a21cd061.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/10870395-15e4-40b0-8f7e-5ffab7195224.svg#10870395-15e4-40b0-8f7e-5ffab7195224") format("svg");
}

@font-face {
    font-family: "ArabicTypesettingW23-Re";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/28b4ce0b-3a59-4f7c-ab3f-909d63dd0351.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/28b4ce0b-3a59-4f7c-ab3f-909d63dd0351.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/5a32e87e-0f32-4971-a43f-4ec453bc74ca.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/50f516bf-5611-4134-9556-2131aaea2b78.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/8db4ca73-82e1-4259-afcd-c1f15b14f62b.svg#8db4ca73-82e1-4259-afcd-c1f15b14f62b") format("svg");
}

@font-face {
    font-family: "CoHeadlineW23-ArabicBol";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/925638f2-9ed0-4f9a-a78d-61d6eddd2b54.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/925638f2-9ed0-4f9a-a78d-61d6eddd2b54.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b15a6899-c706-46a9-8c2b-a80b62ba301b.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/36ad9b9b-5fb9-49e6-ad2d-1daafccea16a.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/05e393a0-71df-4e02-b8ba-6f68f2b23b92.svg#05e393a0-71df-4e02-b8ba-6f68f2b23b92") format("svg");
}

@font-face{
    font-family:'Amiri';
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/amiri-regular.eot');
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/amiri-regular.eot?#iefix') format('embedded-opentype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/amiri-regular.woff') format('woff'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/amiri-regular.ttf') format('truetype');
}

@font-face{
    font-family:'Droid-Naskh';
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/droidnaskh-regular.eot');
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/droidnaskh-regular.eot?#iefix') format('embedded-opentype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/droidnaskh-regular.woff') format('woff'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/droidnaskh-regular.ttf') format('truetype');
}

/* hebrew */
@font-face {
    font-family: "Adler-W26-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/8fa9b915-180f-4b72-aee7-22fd066c52c6.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/8fa9b915-180f-4b72-aee7-22fd066c52c6.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/fcb3f76f-a112-479e-ab7f-ab1c2be906c9.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/ceda4e97-a631-4986-8cab-709e1775be33.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/353c7faf-0d58-475b-8caa-f1d863e0cf1d.svg#353c7faf-0d58-475b-8caa-f1d863e0cf1d") format("svg");
}

@font-face {
    font-family: "Frank-Ruhl-W26-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/90882399-52f1-42a9-986b-c2c49d3fb409.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/90882399-52f1-42a9-986b-c2c49d3fb409.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/0e834425-e268-4b38-b5a8-f24b8632d6ae.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/cb5aceab-5dbf-4c09-b650-7c9d526cc117.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/850e45c9-2003-49fa-8e3f-c7dfd6579acc.svg#850e45c9-2003-49fa-8e3f-c7dfd6579acc") format("svg");
}

@font-face {
    font-family: "Haim-Arukeem-W26-Medium";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/6de8df0c-23af-49b9-9578-42db4c756d2d.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/6de8df0c-23af-49b9-9578-42db4c756d2d.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/f70c24b0-d6be-4d04-99cd-46efc41d00b4.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/2dd64ac4-7c3a-47fb-acdb-063b811c93d5.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/a7ab1444-5d94-4474-9d31-86df47d8d5c1.svg#a7ab1444-5d94-4474-9d31-86df47d8d5c1") format("svg");
}

@font-face {
    font-family: "Miriam-W26-Medium";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/acfa87dd-5042-40e1-87e9-12e4a559269f.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/acfa87dd-5042-40e1-87e9-12e4a559269f.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/21aeb0a3-3309-4415-818b-36f94e2a1a3a.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c5acaffd-7553-42ff-a693-8b9be795b4b3.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/dd50d8fb-6769-469f-8bfa-9caed8e6df18.svg#dd50d8fb-6769-469f-8bfa-9caed8e6df18") format("svg");
}

@font-face {
    font-family: "Nekudot-W26-Bold";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c0a57107-844c-4847-afc6-00f3cb3c4d5f.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c0a57107-844c-4847-afc6-00f3cb3c4d5f.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/c28b65cd-9544-42f1-9ffc-d6ffa544e6fb.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/9aa74607-c9af-4c4b-9a3f-fc76488dca25.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/00381de4-f82a-4939-b8e1-1bbde51ac4ce.svg#00381de4-f82a-4939-b8e1-1bbde51ac4ce") format("svg");
}

@font-face {
    font-family: "Gulash-W26-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/7c672276-1d07-4ff2-8b1d-3245af0dc5cc.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/7c672276-1d07-4ff2-8b1d-3245af0dc5cc.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/64f53eeb-1d5e-493c-aa3b-aa8e2c066320.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/7e32a874-81bc-4d38-87aa-ff626ce5a400.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/857d7efc-7a9c-457d-8aa5-44f0992e6441.svg#857d7efc-7a9c-457d-8aa5-44f0992e6441") format("svg");
}

@font-face {
    font-family: "Shabazi-W26-Bold";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/dc7f3c57-fb2d-4656-9224-ef9f1c88477e.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/dc7f3c57-fb2d-4656-9224-ef9f1c88477e.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/09048cb1-f6a6-4b44-9d96-6d20013ef7e8.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/fec4486e-254a-4cb4-b1a0-859cf2190792.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b25da79b-ff9a-486e-bf4f-2893c47da939.svg#b25da79b-ff9a-486e-bf4f-2893c47da939") format("svg");
}

@font-face{
    font-family:"Chips-W26-Normal";
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/aa157336-ffa1-476e-9a72-e9f516e87ca3.eot?#iefix");
    src:url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/aa157336-ffa1-476e-9a72-e9f516e87ca3.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/e526922d-4fe2-4e4d-834d-6b62ebd244da.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/03e7eb16-072f-4c53-b299-08535bff2421.ttf") format("truetype"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/b21a0ec6-8efb-40de-99f1-20a11d482401.svg#b21a0ec6-8efb-40de-99f1-20a11d482401") format("svg");
}

@font-face {
    font-family: "Alef-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/alef-regular.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/alef-regular.eot?#iefix") format("eot"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/alef-regular.woff") format("woff"),url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/alef-regular.ttf") format("truetype");
}

@font-face {
    font-family: "OpenSansHebrewCondensed-Regular";
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-hebrew-condensed-regular.eot?#iefix");
    src: url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-hebrew-condensed-regular.eot?#iefix") format("eot"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-hebrew-condensed-regular.woff") format("woff"),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/opensans-hebrew-condensed-regular.ttf") format("truetype");
}

@font-face{
    font-family:'almoni-dl-aaa-300';
    font-weight:300; /*(light)*/
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/almoni-dl-aaa-300.eot');
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/almoni-dl-aaa-300.eot?#iefix') format('embedded-opentype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/almoni-dl-aaa-300.woff') format('woff'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/almoni-dl-aaa-300.ttf') format('truetype');
}

@font-face{
    font-family:'almoni-dl-aaa-400';
    font-weight:400; /*(regular)*/
    font-style: normal;
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/almoni-dl-aaa-400.eot');
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/almoni-dl-aaa-400.eot?#iefix') format('embedded-opentype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/almoni-dl-aaa-400.woff') format('woff'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/almoni-dl-aaa-400.ttf') format('truetype');
}

@font-face{
    font-family:'almoni-dl-aaa-700';
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/almoni-dl-aaa-700.eot');
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/almoni-dl-aaa-700.eot?#iefix') format('embedded-opentype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/almoni-dl-aaa-700.woff') format('woff'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/almoni-dl-aaa-700.ttf') format('truetype');
}

@font-face{
    font-family:'asimon-aaa-400';
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/asimon-aaa-400.eot');
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/asimon-aaa-400.eot?#iefix') format('embedded-opentype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/asimon-aaa-400.woff') format('woff'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/asimon-aaa-400.ttf') format('truetype');
}

@font-face{
    font-family:'atlas-aaa-500';
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/atlas-aaa-500.eot');
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/atlas-aaa-500.eot?#iefix') format('embedded-opentype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/atlas-aaa-500.woff') format('woff'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/atlas-aaa-500.ttf') format('truetype');
}

@font-face{
    font-family:'mixtape-aaa-400';
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/mixtape-aaa-400.eot');
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/mixtape-aaa-400.eot?#iefix') format('embedded-opentype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/mixtape-aaa-400.woff') format('woff'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/mixtape-aaa-400.ttf') format('truetype');
}

@font-face{
    font-family:'museum-aaa-400';
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/museum-aaa-400.eot');
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/museum-aaa-400.eot?#iefix') format('embedded-opentype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/museum-aaa-400.woff') format('woff'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/museum-aaa-400.ttf') format('truetype');
}

@font-face{
    font-family:'omes-aaa-400';
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/omes-aaa-400.eot');
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/omes-aaa-400.eot?#iefix') format('embedded-opentype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/omes-aaa-400.woff') format('woff'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/omes-aaa-400.ttf') format('truetype');
}

@font-face{
    font-family:'MeodedPashut-oeregular';
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/meodedpashut_oeregular.eot');
    src: url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/meodedpashut_oeregular.eot?#iefix') format('embedded-opentype'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/meodedpashut_oeregular.woff') format('woff'),
    url('//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/open-source/meodedpashut_oeregular.ttf') format('truetype'),
    url("//static.parastorage.com/services/third-party/fonts/user-site-fonts/fonts/meodedpashut_oeregular.svg#meodedpashut_oeregular") format("svg");
}

/* This fonts are from google fonts, We added them so we can configure the weights */

/** Roboto Thin**/

@font-face {
    font-family: "Roboto-Thin";
    src: url("//fonts.gstatic.com/s/roboto/v18/hNdh1kLam5Qu9t6-swGJgPesZW2xOQ-xsNqO47m55DA.eot?#iefix");
    src: url("//fonts.gstatic.com/s/roboto/v18/hNdh1kLam5Qu9t6-swGJgPesZW2xOQ-xsNqO47m55DA.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/roboto/v18/e7MeVAyvogMqFwwl61PKhPesZW2xOQ-xsNqO47m55DA.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/roboto/v18/idLYXfFa1c7oAPILDl4z0fesZW2xOQ-xsNqO47m55DA.woff") format("woff"),
    url("//fonts.gstatic.com/s/roboto/v18/BhNUF0UvSiDyKi5GMZK0cPesZW2xOQ-xsNqO47m55DA.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=Rd0cKaNHVPp3zNwTc2cJ6fesZW2xOQ-xsNqO47m55DA&skey=5473b731ec7fc9c1&v=v18#Roboto") format("svg");
}

@font-face {
    font-family: "Roboto-Thin";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/roboto/v18/3KAd02OzFSDbt78HTOt2og.eot?#iefix");
    src: url("//fonts.gstatic.com/s/roboto/v18/3KAd02OzFSDbt78HTOt2og.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/roboto/v18/fIKu7GwZTy_12XzG_jt8eA.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/roboto/v18/Xyjz-jNkfiYuJf8UC3Lizw.woff") format("woff"),
    url("//fonts.gstatic.com/s/roboto/v18/5M21SdFLkD52QavfmHs6cA.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=1w8PsahvVyy4URc6MP8jWQ&skey=a0a0114a1dcab3ac&v=v18#Roboto") format("svg");
}

@font-face {
    font-family: "Roboto-Thin";
    font-style: italic;
    src: url("//fonts.gstatic.com/s/roboto/v18/dzxs_VxZUhdM2mEBkNa8slQlYEbsez9cZjKsNMjLOwM.eot?#iefix");
    src: url("//fonts.gstatic.com/s/roboto/v18/dzxs_VxZUhdM2mEBkNa8slQlYEbsez9cZjKsNMjLOwM.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/roboto/v18/dzxs_VxZUhdM2mEBkNa8svk_vArhqVIZ0nv9q090hN8.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/roboto/v18/dzxs_VxZUhdM2mEBkNa8shsxEYwM7FgeyaSgU71cLG0.woff") format("woff"),
    url("//fonts.gstatic.com/s/roboto/v18/dzxs_VxZUhdM2mEBkNa8si3USBnSvpkopQaUR-2r7iU.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=dzxs_VxZUhdM2mEBkNa8sqWUboTb-jS2tyCOQMtm97g&skey=8f53aa2e7deadc4a&v=v18#Roboto") format("svg");
}

@font-face {
    font-family: "Roboto-Thin";
    font-weight: 700;
    font-style: italic;
    src: url("//fonts.gstatic.com/s/roboto/v18/87ImaWi619lMX9BhLChOt_esZW2xOQ-xsNqO47m55DA.eot?#iefix");
    src: url("//fonts.gstatic.com/s/roboto/v18/87ImaWi619lMX9BhLChOt_esZW2xOQ-xsNqO47m55DA.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/roboto/v18/vSzulfKSK0LLjjfeaxcREvesZW2xOQ-xsNqO47m55DA.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/roboto/v18/dFWsweFqlD8ExfyN7Gh_GPesZW2xOQ-xsNqO47m55DA.woff") format("woff"),
    url("//fonts.gstatic.com/s/roboto/v18/OKegwhKhBNN-dhuHI27Hy_esZW2xOQ-xsNqO47m55DA.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=uIFaDMJQtos_JDdGgbxITvesZW2xOQ-xsNqO47m55DA&skey=c608c610063635f9&v=v18#Roboto") format("svg");
}


/** Roboto Bold**/

@font-face {
    font-family: "Roboto-Bold";
    src: url("//fonts.gstatic.com/s/roboto/v18/97uahxiqZRoncBaCEI3aW_Y6323mHUZFJMgTvxaG2iE.eot?#iefix");
    src: url("//fonts.gstatic.com/s/roboto/v18/97uahxiqZRoncBaCEI3aW_Y6323mHUZFJMgTvxaG2iE.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/roboto/v18/97uahxiqZRoncBaCEI3aW1tXRa8TVwTICgirnJhmVJw.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/roboto/v18/97uahxiqZRoncBaCEI3aWz8E0i7KZn-EPnyo3HZu7kw.woff") format("woff"),
    url("//fonts.gstatic.com/s/roboto/v18/97uahxiqZRoncBaCEI3aW6CWcynf_cDxXwCLxiixG1c.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=97uahxiqZRoncBaCEI3aW5bd9NUM7myrQQz30yPaGQ4&skey=c06e7213f788649e&v=v18#Roboto") format("svg");
}

@font-face {
    font-family: "Roboto-Bold";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/roboto/v18/9_7S_tWeGDh5Pq3u05RVkvY6323mHUZFJMgTvxaG2iE.eot?#iefix");
    src: url("//fonts.gstatic.com/s/roboto/v18/9_7S_tWeGDh5Pq3u05RVkvY6323mHUZFJMgTvxaG2iE.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/roboto/v18/9_7S_tWeGDh5Pq3u05RVkltXRa8TVwTICgirnJhmVJw.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/roboto/v18/9_7S_tWeGDh5Pq3u05RVkj8E0i7KZn-EPnyo3HZu7kw.woff") format("woff"),
    url("//fonts.gstatic.com/s/roboto/v18/9_7S_tWeGDh5Pq3u05RVkqCWcynf_cDxXwCLxiixG1c.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=9_7S_tWeGDh5Pq3u05RVkpbd9NUM7myrQQz30yPaGQ4&skey=934406f772f9777d&v=v18#Roboto") format("svg");
}

@font-face {
    font-family: "Roboto-Bold";
    font-style: italic;
    src: url("//fonts.gstatic.com/s/roboto/v18/t6Nd4cfPRhZP44Q5QAjcC-ZiE7IA0Up7-VwGqa0iGVY.eot?#iefix");
    src: url("//fonts.gstatic.com/s/roboto/v18/t6Nd4cfPRhZP44Q5QAjcC-ZiE7IA0Up7-VwGqa0iGVY.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/roboto/v18/t6Nd4cfPRhZP44Q5QAjcC6g5eI2G47JWe0-AuFtD150.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/roboto/v18/t6Nd4cfPRhZP44Q5QAjcC9Ih4imgI8P11RFo6YPCPC0.woff") format("woff"),
    url("//fonts.gstatic.com/s/roboto/v18/t6Nd4cfPRhZP44Q5QAjcC102b4v3fUxqf9CZJ1qUoIA.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=t6Nd4cfPRhZP44Q5QAjcC5S_ZaL0arjVp2tkn2-HJhM&skey=dd030d266f3beccc&v=v18#Roboto") format("svg");
}

@font-face {
    font-family: "Roboto-Bold";
    font-weight: 700;
    font-style: italic;
    src: url("//fonts.gstatic.com/s/roboto/v18/bmC0pGMXrhphrZJmniIZpeZiE7IA0Up7-VwGqa0iGVY.eot?#iefix");
    src: url("//fonts.gstatic.com/s/roboto/v18/bmC0pGMXrhphrZJmniIZpeZiE7IA0Up7-VwGqa0iGVY.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/roboto/v18/bmC0pGMXrhphrZJmniIZpag5eI2G47JWe0-AuFtD150.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/roboto/v18/bmC0pGMXrhphrZJmniIZpdIh4imgI8P11RFo6YPCPC0.woff") format("woff"),
    url("//fonts.gstatic.com/s/roboto/v18/bmC0pGMXrhphrZJmniIZpV02b4v3fUxqf9CZJ1qUoIA.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=bmC0pGMXrhphrZJmniIZpZS_ZaL0arjVp2tkn2-HJhM&skey=b80be3241fe40325&v=v18#Roboto") format("svg");
}

/** WorkSans-ExtraLight**/

@font-face {
    font-family: "WorkSans-ExtraLight";
    src: url("//fonts.gstatic.com/s/worksans/v3/u_mYNr_qYP37m7vgvmIYZ6lSqKUsDpiXlwfj-ZM2w_A.eot?#iefix");
    src: url("//fonts.gstatic.com/s/worksans/v3/u_mYNr_qYP37m7vgvmIYZ6lSqKUsDpiXlwfj-ZM2w_A.eot.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/worksans/v3/u_mYNr_qYP37m7vgvmIYZxUOjZSKWg4xBWp_C_qQx0o.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/worksans/v3/u_mYNr_qYP37m7vgvmIYZxa1RVmPjeKy21_GQJaLlJI.woff") format("woff"),
    url("//fonts.gstatic.com/s/worksans/v3/u_mYNr_qYP37m7vgvmIYZ9qQynqKV_9Plp7mupa0S4g.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=u_mYNr_qYP37m7vgvmIYZ91LKoZ82bBu2f46DhHcs3c&skey=7c020d2757de915d&v=v3#WorkSans") format("svg");
}


@font-face {
    font-family: "WorkSans-ExtraLight";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/worksans/v3/FD_Udbezj8EHXbdsqLUpl6lSqKUsDpiXlwfj-ZM2w_A.eot?#iefix");
    src: url("//fonts.gstatic.com/s/worksans/v3/FD_Udbezj8EHXbdsqLUpl6lSqKUsDpiXlwfj-ZM2w_A.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/worksans/v3/FD_Udbezj8EHXbdsqLUplxUOjZSKWg4xBWp_C_qQx0o.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/worksans/v3/FD_Udbezj8EHXbdsqLUplxa1RVmPjeKy21_GQJaLlJI.woff") format("woff"),
    url("//fonts.gstatic.com/s/worksans/v3/FD_Udbezj8EHXbdsqLUpl9qQynqKV_9Plp7mupa0S4g.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=FD_Udbezj8EHXbdsqLUpl91LKoZ82bBu2f46DhHcs3c&skey=ebac65da87d8d365&v=v3#WorkSans") format("svg");
}

/** WorkSans-SemiBold**/

@font-face {
    font-family: "WorkSans-SemiBold";
    src: url("//fonts.gstatic.com/s/worksans/v3/z9rX03Xuz9ZNHTMg1_ghGalSqKUsDpiXlwfj-ZM2w_A.eot?#iefix");
    src: url("//fonts.gstatic.com/s/worksans/v3/z9rX03Xuz9ZNHTMg1_ghGalSqKUsDpiXlwfj-ZM2w_A.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/worksans/v3/z9rX03Xuz9ZNHTMg1_ghGRUOjZSKWg4xBWp_C_qQx0o.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/worksans/v3/z9rX03Xuz9ZNHTMg1_ghGRa1RVmPjeKy21_GQJaLlJI.woff") format("woff"),
    url("//fonts.gstatic.com/s/worksans/v3/z9rX03Xuz9ZNHTMg1_ghGdqQynqKV_9Plp7mupa0S4g.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=z9rX03Xuz9ZNHTMg1_ghGd1LKoZ82bBu2f46DhHcs3c&skey=d84f72eaa49bc5a2&v=v3#WorkSans") format("svg");
}


@font-face {
    font-family: "WorkSans-SemiBold";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/worksans/v3/4udXuXg54JlPEP5iKO5AmalSqKUsDpiXlwfj-ZM2w_A.eot?#iefix");
    src: url("//fonts.gstatic.com/s/worksans/v3/4udXuXg54JlPEP5iKO5AmalSqKUsDpiXlwfj-ZM2w_A.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/worksans/v3/4udXuXg54JlPEP5iKO5AmRUOjZSKWg4xBWp_C_qQx0o.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/worksans/v3/4udXuXg54JlPEP5iKO5AmRa1RVmPjeKy21_GQJaLlJI.woff") format("woff"),
    url("//fonts.gstatic.com/s/worksans/v3/4udXuXg54JlPEP5iKO5AmdqQynqKV_9Plp7mupa0S4g.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=4udXuXg54JlPEP5iKO5Amd1LKoZ82bBu2f46DhHcs3c&skey=f1df08d30998b725&v=v3#WorkSans") format("svg");
}


/* Poppins-ExtraLight */

@font-face {
    font-family: "Poppins-ExtraLight";
    src: url("//fonts.gstatic.com/s/poppins/v5/h3r77AwDsldr1E_2g4qqGFQlYEbsez9cZjKsNMjLOwM.eot?#iefix");
    src: url("//fonts.gstatic.com/s/poppins/v5/h3r77AwDsldr1E_2g4qqGFQlYEbsez9cZjKsNMjLOwM.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/poppins/v5/h3r77AwDsldr1E_2g4qqGPk_vArhqVIZ0nv9q090hN8.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/poppins/v5/h3r77AwDsldr1E_2g4qqGBsxEYwM7FgeyaSgU71cLG0.woff") format("woff"),
    url("//fonts.gstatic.com/s/poppins/v5/h3r77AwDsldr1E_2g4qqGC3USBnSvpkopQaUR-2r7iU.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=h3r77AwDsldr1E_2g4qqGKWUboTb-jS2tyCOQMtm97g&skey=1bdc08fe61c3cc9e&v=v5#Poppins") format("svg");
}


@font-face {
    font-family: "Poppins-ExtraLight";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/poppins/v5/2NBlOVek2HIa2EeuV_3Cbw.eot?#iefix");
    src: url("//fonts.gstatic.com/s/poppins/v5/2NBlOVek2HIa2EeuV_3Cbw.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/poppins/v5/rijG6I_IOXJjsH07UEo2mw.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/poppins/v5/p0A1C4_gK5NzKtuGSwNurQ.woff") format("woff"),
    url("//fonts.gstatic.com/s/poppins/v5/rATt6MpBkxjRr3sy5fMEDg.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=dvQ6luzB0ViWP07p6fisSw&skey=87759fb096548f6d&v=v5#Poppins") format("svg");
}

@font-face {
    font-family: "Poppins-ExtraLight";
    font-style: italic;
    src: url("//fonts.gstatic.com/s/poppins/v5/-GlaWpWcSgdVagNuOGuFKalSqKUsDpiXlwfj-ZM2w_A.eot?#iefix");
    src: url("//fonts.gstatic.com/s/poppins/v5/-GlaWpWcSgdVagNuOGuFKalSqKUsDpiXlwfj-ZM2w_A.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/poppins/v5/-GlaWpWcSgdVagNuOGuFKRUOjZSKWg4xBWp_C_qQx0o.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/poppins/v5/-GlaWpWcSgdVagNuOGuFKRa1RVmPjeKy21_GQJaLlJI.woff") format("woff"),
    url("//fonts.gstatic.com/s/poppins/v5/-GlaWpWcSgdVagNuOGuFKdqQynqKV_9Plp7mupa0S4g.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=-GlaWpWcSgdVagNuOGuFKd1LKoZ82bBu2f46DhHcs3c&skey=e6f64e60fb8d9268&v=v5#Poppins") format("svg");
}

@font-face {
    font-family: "Poppins-ExtraLight";
    font-weight: 700;
    font-style: italic;
    src: url("//fonts.gstatic.com/s/poppins/v5/Fm41upUVp7KTKUZhL0PfQfY6323mHUZFJMgTvxaG2iE.eot?#iefix");
    src: url("//fonts.gstatic.com/s/poppins/v5/Fm41upUVp7KTKUZhL0PfQfY6323mHUZFJMgTvxaG2iE.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/poppins/v5/Fm41upUVp7KTKUZhL0PfQVtXRa8TVwTICgirnJhmVJw.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/poppins/v5/Fm41upUVp7KTKUZhL0PfQT8E0i7KZn-EPnyo3HZu7kw.woff") format("woff"),
    url("//fonts.gstatic.com/s/poppins/v5/Fm41upUVp7KTKUZhL0PfQaCWcynf_cDxXwCLxiixG1c.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=Fm41upUVp7KTKUZhL0PfQZbd9NUM7myrQQz30yPaGQ4&skey=f21d6e783fa43c88&v=v5#Poppins") format("svg");
}

/* Poppins-SemiBold */

@font-face {
    font-family: "Poppins-SemiBold";
    src: url("//fonts.gstatic.com/s/poppins/v5/9VWMTeb5jtXkNoTv949NpVQlYEbsez9cZjKsNMjLOwM.eot?#iefix");
    src: url("//fonts.gstatic.com/s/poppins/v5/9VWMTeb5jtXkNoTv949NpVQlYEbsez9cZjKsNMjLOwM.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/poppins/v5/9VWMTeb5jtXkNoTv949Npfk_vArhqVIZ0nv9q090hN8.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/poppins/v5/9VWMTeb5jtXkNoTv949NpRsxEYwM7FgeyaSgU71cLG0.woff") format("woff"),
    url("//fonts.gstatic.com/s/poppins/v5/9VWMTeb5jtXkNoTv949NpS3USBnSvpkopQaUR-2r7iU.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=9VWMTeb5jtXkNoTv949NpaWUboTb-jS2tyCOQMtm97g&skey=ce7ef9d62ca89319&v=v5#Poppins") format("svg");
}


@font-face {
    font-family: "Poppins-SemiBold";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/poppins/v5/aDjpMND83pDErGXlVEr-SVQlYEbsez9cZjKsNMjLOwM.eot?#iefix");
    src: url("//fonts.gstatic.com/s/poppins/v5/aDjpMND83pDErGXlVEr-SVQlYEbsez9cZjKsNMjLOwM.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/poppins/v5/aDjpMND83pDErGXlVEr-Sfk_vArhqVIZ0nv9q090hN8.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/poppins/v5/aDjpMND83pDErGXlVEr-SRsxEYwM7FgeyaSgU71cLG0.woff") format("woff"),
    url("//fonts.gstatic.com/s/poppins/v5/aDjpMND83pDErGXlVEr-SS3USBnSvpkopQaUR-2r7iU.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=aDjpMND83pDErGXlVEr-SaWUboTb-jS2tyCOQMtm97g&skey=cea76fe63715a67a&v=v5#Poppins") format("svg");
}

@font-face {
    font-family: "Poppins-SemiBold";
    font-style: italic;
    src: url("//fonts.gstatic.com/s/poppins/v5/RbebACOccNN-5ixkDIVLjalSqKUsDpiXlwfj-ZM2w_A.eot?#iefix");
    src: url("//fonts.gstatic.com/s/poppins/v5/RbebACOccNN-5ixkDIVLjalSqKUsDpiXlwfj-ZM2w_A.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/poppins/v5/RbebACOccNN-5ixkDIVLjRUOjZSKWg4xBWp_C_qQx0o.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/poppins/v5/RbebACOccNN-5ixkDIVLjRa1RVmPjeKy21_GQJaLlJI.woff") format("woff"),
    url("//fonts.gstatic.com/s/poppins/v5/RbebACOccNN-5ixkDIVLjdqQynqKV_9Plp7mupa0S4g.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=RbebACOccNN-5ixkDIVLjd1LKoZ82bBu2f46DhHcs3c&skey=7fbc556774b13ef0&v=v5#Poppins") format("svg");
}

@font-face {
    font-family: "Poppins-SemiBold";
    font-weight: 700;
    font-style: italic;
    src: url("//fonts.gstatic.com/s/poppins/v5/c4FPK8_hIFKoX59qcGwdCqlSqKUsDpiXlwfj-ZM2w_A.eot?#iefix");
    src: url("//fonts.gstatic.com/s/poppins/v5/c4FPK8_hIFKoX59qcGwdCqlSqKUsDpiXlwfj-ZM2w_A.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/poppins/v5/c4FPK8_hIFKoX59qcGwdChUOjZSKWg4xBWp_C_qQx0o.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/poppins/v5/c4FPK8_hIFKoX59qcGwdCha1RVmPjeKy21_GQJaLlJI.woff") format("woff"),
    url("//fonts.gstatic.com/s/poppins/v5/c4FPK8_hIFKoX59qcGwdCtqQynqKV_9Plp7mupa0S4g.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=c4FPK8_hIFKoX59qcGwdCt1LKoZ82bBu2f46DhHcs3c&skey=29c3bd833a54ba8c&v=v5#Poppins") format("svg");
}

/* Barlow-ExtraLight */

@font-face {
    font-family: "Barlow-ExtraLight";
    src: url("//fonts.gstatic.com/s/barlow/v1/51v0xj5VPw1cLYHNhfd8NPY6323mHUZFJMgTvxaG2iE.eot?#iefix");
    src: url("//fonts.gstatic.com/s/barlow/v1/51v0xj5VPw1cLYHNhfd8NPY6323mHUZFJMgTvxaG2iE.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/barlow/v1/51v0xj5VPw1cLYHNhfd8NFtXRa8TVwTICgirnJhmVJw.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/barlow/v1/51v0xj5VPw1cLYHNhfd8ND8E0i7KZn-EPnyo3HZu7kw.woff") format("woff"),
    url("//fonts.gstatic.com/s/barlow/v1/51v0xj5VPw1cLYHNhfd8NKCWcynf_cDxXwCLxiixG1c.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=51v0xj5VPw1cLYHNhfd8NJbd9NUM7myrQQz30yPaGQ4&skey=e8c74abecf94633e&v=v1#Barlow") format("svg");
}


@font-face {
    font-family: "Barlow-ExtraLight";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/barlow/ /SWLcTgmyMR1GjdNjixEPiQ.eot?#iefix");
    src: url("//fonts.gstatic.com/s/barlow/v1/SWLcTgmyMR1GjdNjixEPiQ.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/barlow/v1/2woyxyDnPU0v4IiqYU9D1g.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/barlow/v1/-HJgNsTwx9qXGSxqew62RQ.woff") format("woff"),
    url("//fonts.gstatic.com/s/barlow/v1/qoExc9IJQUjYXhlVZNNLgg.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=lYNHuF7-w_9_po3MKWoAsw&skey=32d7acf8757dbad0&v=v1#Barlow") format("svg");
}

@font-face {
    font-family: "Barlow-ExtraLight";
    font-style: italic;
    src: url("//fonts.gstatic.com/s/barlow/v1/14AxwKgJhKIO-YYUP_KtZeZiE7IA0Up7-VwGqa0iGVY.eot?#iefix");
    src: url("//fonts.gstatic.com/s/barlow/v1/14AxwKgJhKIO-YYUP_KtZeZiE7IA0Up7-VwGqa0iGVY.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/barlow/v1/14AxwKgJhKIO-YYUP_KtZag5eI2G47JWe0-AuFtD150.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/barlow/v1/14AxwKgJhKIO-YYUP_KtZdIh4imgI8P11RFo6YPCPC0.woff") format("woff"),
    url("//fonts.gstatic.com/s/barlow/v1/14AxwKgJhKIO-YYUP_KtZV02b4v3fUxqf9CZJ1qUoIA.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=14AxwKgJhKIO-YYUP_KtZZS_ZaL0arjVp2tkn2-HJhM&skey=9a40589dc4645af7&v=v1#Barlow") format("svg");
}

@font-face {
    font-family: "Barlow-ExtraLight";
    font-weight: 700;
    font-style: italic;
    src: url("//fonts.gstatic.com/s/barlow/v1/8p49G4DnpMZgB5cGwNFgJvesZW2xOQ-xsNqO47m55DA.eot?#iefix");
    src: url("//fonts.gstatic.com/s/barlow/v1/8p49G4DnpMZgB5cGwNFgJvesZW2xOQ-xsNqO47m55DA.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/barlow/v1/cdbGxfKO8gdkBd5U5TuXqPesZW2xOQ-xsNqO47m55DA.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/barlow/v1/W1XpMGU0WrpbCawEdG1FM_esZW2xOQ-xsNqO47m55DA.woff") format("woff"),
    url("//fonts.gstatic.com/s/barlow/v1/_lIpJP17FZmSeklpAeOdnvesZW2xOQ-xsNqO47m55DA.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=MGR_1eUqfxpTc1K5cbfqWvesZW2xOQ-xsNqO47m55DA&skey=ae428d300932fbee&v=v1#Barlow") format("svg");
}

/* Barlow-Medium */

@font-face {
    font-family: "Barlow-Medium";
    src: url("//fonts.gstatic.com/s/barlow/v1/ZqlneECqpsd9SXlmAsD2E_Y6323mHUZFJMgTvxaG2iE.eot?#iefix");
    src: url("//fonts.gstatic.com/s/barlow/v1/ZqlneECqpsd9SXlmAsD2E_Y6323mHUZFJMgTvxaG2iE.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/barlow/v1/ZqlneECqpsd9SXlmAsD2E1tXRa8TVwTICgirnJhmVJw.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/barlow/v1/ZqlneECqpsd9SXlmAsD2Ez8E0i7KZn-EPnyo3HZu7kw.woff") format("woff"),
    url("//fonts.gstatic.com/s/barlow/v1/ZqlneECqpsd9SXlmAsD2E6CWcynf_cDxXwCLxiixG1c.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=ZqlneECqpsd9SXlmAsD2E5bd9NUM7myrQQz30yPaGQ4&skey=4c8d0d0b13516148&v=v1#Barlow") format("svg");
}

@font-face {
    font-family: "Barlow-Medium";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/barlow/v1/yS165lxqGuDghyUMXeu6xfY6323mHUZFJMgTvxaG2iE.eot?#iefix");
    src: url("//fonts.gstatic.com/s/barlow/v1/yS165lxqGuDghyUMXeu6xfY6323mHUZFJMgTvxaG2iE.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/barlow/v1/yS165lxqGuDghyUMXeu6xVtXRa8TVwTICgirnJhmVJw.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/barlow/v1/yS165lxqGuDghyUMXeu6xT8E0i7KZn-EPnyo3HZu7kw.woff") format("woff"),
    url("//fonts.gstatic.com/s/barlow/v1/yS165lxqGuDghyUMXeu6xaCWcynf_cDxXwCLxiixG1c.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=yS165lxqGuDghyUMXeu6xZbd9NUM7myrQQz30yPaGQ4&skey=f60e73b1bbf362f3&v=v1#Barlow") format("svg");
}

@font-face {
    font-family: "Barlow-Medium";
    font-style: italic;
    src: url("//fonts.gstatic.com/s/barlow/v1/xJLokI-F3wr7NRWXgS0pZ-ZiE7IA0Up7-VwGqa0iGVY.eot?#iefix");
    src: url("//fonts.gstatic.com/s/barlow/v1/xJLokI-F3wr7NRWXgS0pZ-ZiE7IA0Up7-VwGqa0iGVY.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/barlow/v1/xJLokI-F3wr7NRWXgS0pZ6g5eI2G47JWe0-AuFtD150.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/barlow/v1/xJLokI-F3wr7NRWXgS0pZ9Ih4imgI8P11RFo6YPCPC0.woff") format("woff"),
    url("//fonts.gstatic.com/s/barlow/v1/xJLokI-F3wr7NRWXgS0pZ102b4v3fUxqf9CZJ1qUoIA.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=xJLokI-F3wr7NRWXgS0pZ5S_ZaL0arjVp2tkn2-HJhM&skey=989d87b0113009a2&v=v1#Barlow") format("svg");
}

@font-face {
    font-family: "Barlow-Medium";
    font-weight: 700;
    font-style: italic;
    src: url("//fonts.gstatic.com/s/barlow/v1/hw7DQwyFvE7wFOFzpow4xuZiE7IA0Up7-VwGqa0iGVY.eot?#iefix");
    src: url("//fonts.gstatic.com/s/barlow/v1/hw7DQwyFvE7wFOFzpow4xuZiE7IA0Up7-VwGqa0iGVY.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/barlow/v1/hw7DQwyFvE7wFOFzpow4xqg5eI2G47JWe0-AuFtD150.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/barlow/v1/hw7DQwyFvE7wFOFzpow4xtIh4imgI8P11RFo6YPCPC0.woff") format("woff"),
    url("//fonts.gstatic.com/s/barlow/v1/hw7DQwyFvE7wFOFzpow4xl02b4v3fUxqf9CZJ1qUoIA.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=hw7DQwyFvE7wFOFzpow4xpS_ZaL0arjVp2tkn2-HJhM&skey=25c93348b6ec64d8&v=v1#Barlow") format("svg");
}

/** Oswald-ExtraLight **/

@font-face {
    font-family: "Oswald-ExtraLight";
    src: url("//fonts.gstatic.com/s/oswald/v16/GwZ_PiN1Aind9Eyjp868E_Y6323mHUZFJMgTvxaG2iE.eot?#iefix");
    src: url("//fonts.gstatic.com/s/oswald/v16/GwZ_PiN1Aind9Eyjp868E_Y6323mHUZFJMgTvxaG2iE.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/oswald/v16/GwZ_PiN1Aind9Eyjp868E1tXRa8TVwTICgirnJhmVJw.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/oswald/v16/GwZ_PiN1Aind9Eyjp868Ez8E0i7KZn-EPnyo3HZu7kw.woff") format("woff"),
    url("//fonts.gstatic.com/s/oswald/v16/GwZ_PiN1Aind9Eyjp868E6CWcynf_cDxXwCLxiixG1c.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=GwZ_PiN1Aind9Eyjp868E5bd9NUM7myrQQz30yPaGQ4&skey=bb2021537ac38f74&v=v16#Oswald") format("svg");
}


@font-face {
    font-family: "Oswald-ExtraLight";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/oswald/v16/aBQVVQvnHeKhkWtMdHDrBA.eot?#iefix");
    src: url("//fonts.gstatic.com/s/oswald/v16/aBQVVQvnHeKhkWtMdHDrBA.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/oswald/v16/RqRF4AQrkUh3ft98NHH2mA.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/oswald/v16/PyqsDANUgLi2UsdO-d4iZQ.woff") format("woff"),
    url("//fonts.gstatic.com/s/oswald/v16/AWM5wXtMJeRP-AcRTgT4qQ.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=fxOl0NmPFyuGF72xEC-uaw&skey=653237e53512d0de&v=v16#Oswald") format("svg");
}

/** Oswald-Medium **/

@font-face {
    font-family: "Oswald-Medium";
    src: url("//fonts.gstatic.com/s/oswald/v16/cgaIrkaP9Empe8_PwXbajPY6323mHUZFJMgTvxaG2iE.eot?#iefix");
    src: url("//fonts.gstatic.com/s/oswald/v16/cgaIrkaP9Empe8_PwXbajPY6323mHUZFJMgTvxaG2iE.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/oswald/v16/cgaIrkaP9Empe8_PwXbajFtXRa8TVwTICgirnJhmVJw.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/oswald/v16/cgaIrkaP9Empe8_PwXbajD8E0i7KZn-EPnyo3HZu7kw.woff") format("woff"),
    url("//fonts.gstatic.com/s/oswald/v16/cgaIrkaP9Empe8_PwXbajKCWcynf_cDxXwCLxiixG1c.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=cgaIrkaP9Empe8_PwXbajJbd9NUM7myrQQz30yPaGQ4&skey=4b4aed5676a34753&v=v16#Oswald") format("svg");
}


@font-face {
    font-family: "Oswald-Medium";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/oswald/v16/dI-qzxlKVQA6TUC5RKSb3_Y6323mHUZFJMgTvxaG2iE.eot?#iefix");
    src: url("//fonts.gstatic.com/s/oswald/v16/dI-qzxlKVQA6TUC5RKSb3_Y6323mHUZFJMgTvxaG2iE.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/oswald/v16/dI-qzxlKVQA6TUC5RKSb31tXRa8TVwTICgirnJhmVJw.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/oswald/v16/dI-qzxlKVQA6TUC5RKSb3z8E0i7KZn-EPnyo3HZu7kw.woff") format("woff"),
    url("//fonts.gstatic.com/s/oswald/v16/dI-qzxlKVQA6TUC5RKSb36CWcynf_cDxXwCLxiixG1c.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=dI-qzxlKVQA6TUC5RKSb35bd9NUM7myrQQz30yPaGQ4&skey=23b674776eaa386b&v=v16#Oswald") format("svg");
}


/* CormorantGaramond-Light */

@font-face {
    font-family: "CormorantGaramond-Light";
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVbBfiualwvFStSOsxMaA9Xk.eot?#iefix");
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVbBfiualwvFStSOsxMaA9Xk.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVSNMxVe3WGf96EDbCaLCBKE.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVergGQquJ_f3dxTxEJk8ZKM.woff") format("woff"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVXYC8UqYVZ_Us7w6eA7MdZE.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=iEjm9hVxcattz37Y8gZwVQItn0uMP03uW4URT5yNJ1A&skey=4f9ed6f80d6d2fa0&v=v5#CormorantGaramond") format("svg");
}

@font-face {
    font-family: "CormorantGaramond-Light";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVazXwemCpFqMs4XqHkBvwCw.eot?#iefix");
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVazXwemCpFqMs4XqHkBvwCw.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVXP87xhFzkXvitf5EbJwljk.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVebEnH4R5m1MLXJyCi0BC78.woff") format("woff"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVXXouEby_DX2rsmMI51GE6g.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=iEjm9hVxcattz37Y8gZwVagJAOahgqhI62iGMRZxLgA&skey=4b255bdbddcd870c&v=v5#CormorantGaramond") format("svg");
}

@font-face {
    font-family: "CormorantGaramond-Light";
    font-style: italic;
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAo6DDMtmvJ_B6GwP8DnSGlc.eot?#iefix");
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAo6DDMtmvJ_B6GwP8DnSGlc.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAhjqQayVfgmnRFwqYqN-Dis.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAhNmD6bOwmI0fiYv_Ehe03s.woff") format("woff"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAoUBHI3ylZGW9V5Fst4kWps.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=zuqx3k1yUEl3Eavo-ZPEAm2yWSqasHTScCEp__B8ZG8&skey=5a7e0a432eb14fbf&v=v5#CormorantGaramond") format("svg");
}

@font-face {
    font-family: "CormorantGaramond-Light";
    font-weight: 700;
    font-style: italic;
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEApsqEKC2V_AfCL0idPKEkUg.eot?#iefix");
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEApsqEKC2V_AfCL0idPKEkUg.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAjp2K1CgsixPpkXulytJk5A.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAhX141arjC0UgpdoDjjeeVk.woff") format("woff"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAs_ggsKlhsDnft5n268BUmY.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=zuqx3k1yUEl3Eavo-ZPEAhPsKNRAg-HYnzxRksprgig&skey=a646f7df62b0db07&v=v5#CormorantGaramond") format("svg");
}

/* CormorantGaramond-SemiBold */

@font-face {
    font-family: "CormorantGaramond-SemiBold";
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVbVz384BzEPyLpTPeKMcRYU.eot?#iefix");
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVbVz384BzEPyLpTPeKMcRYU.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVVBiiiFZ1SMKhjDurTuPCI4.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVbaDr2DD9WOmTsY4M3S93hU.woff") format("woff"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVeXPWxx9SjLSy6MMhsXoUuc.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=iEjm9hVxcattz37Y8gZwVYO0Qi8fZokth4SQK1TX-KE&skey=e242efc8b3e67934&v=v5#CormorantGaramond") format("svg");
}

@font-face {
    font-family: "CormorantGaramond-SemiBold";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVdloJvQ3p58mlwV6TqgfA7M.eot?#iefix");
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVdloJvQ3p58mlwV6TqgfA7M.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVVYUpUlN7yzNHgIMH66hSOI.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVQIBIRsdTZvmhTwexVJEOCE.woff") format("woff"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/iEjm9hVxcattz37Y8gZwVaDtWBNc4GTxi9CQqfNpXFo.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=iEjm9hVxcattz37Y8gZwVb6HL2eGTYrO_zDfBqjt1MM&skey=3181ffd829cb74e8&v=v5#CormorantGaramond") format("svg");
}

@font-face {
    font-family: "CormorantGaramond-SemiBold";
    font-style: italic;
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAsYoq9jXh7-YfoVtEE3lLX0.eot?#iefix");
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAsYoq9jXh7-YfoVtEE3lLX0.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAoNfVaeyxI1fRb3LCiKLt24.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAggc7XrJygm306pFqSI3kLU.woff") format("woff"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAtfqxAW0UHKApQgkrKaDcls.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=zuqx3k1yUEl3Eavo-ZPEAie-e-6qXDi5M9WaClpJAY0&skey=d056cd8e7bb95ad3&v=v5#CormorantGaramond") format("svg");
}

@font-face {
    font-family: "CormorantGaramond-SemiBold";
    font-weight: 700;
    font-style: italic;
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAgFSqQyBKGFf_cwATpqgiXs.eot?#iefix");
    src: url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAgFSqQyBKGFf_cwATpqgiXs.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAoWXH9gdibkBmfnjU2pcZcs.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAsgX3acpz6D8mJOI1MynZxQ.woff") format("woff"),
    url("//fonts.gstatic.com/s/cormorantgaramond/v5/zuqx3k1yUEl3Eavo-ZPEAr5MZRoaqvZ37XiNNIvX6C0.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=zuqx3k1yUEl3Eavo-ZPEAh8ZTJ6KlBZ1Ts_1-_3vUrI&skey=f5baa31c9854d669&v=v5#CormorantGaramond") format("svg");
}

@font-face {
    font-family: 'CormorantGaramond';
    font-style: normal;
    font-weight: 400;
    src: url('//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/CormorantGaramond/v1/cormorant-garamond-v7-latin-ext_latin_cyrillic-regular.woff2') format('woff2'),
    url('//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/CormorantGaramond/v1/cormorant-garamond-v7-latin-ext_latin_cyrillic-regular.woff') format('woff');
}

@font-face {
    font-family: 'CormorantGaramond';
    font-style: italic;
    font-weight: 400;
    src: url('//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/CormorantGaramond/v1/cormorant-garamond-v7-latin-ext_latin_cyrillic-italic.woff2') format('woff2'),
    url('//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/CormorantGaramond/v1/cormorant-garamond-v7-latin-ext_latin_cyrillic-italic.woff') format('woff');
}

@font-face {
    font-family: 'CormorantGaramond';
    font-style: normal;
    font-weight: 700;
    src: url('//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/CormorantGaramond/v1/cormorant-garamond-v7-latin-ext_latin_cyrillic-700.woff2') format('woff2'),
    url('//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/CormorantGaramond/v1/cormorant-garamond-v7-latin-ext_latin_cyrillic-700.woff') format('woff');
}

@font-face {
    font-family: 'CormorantGaramond';
    font-style: italic;
    font-weight: 700;
    src: url('//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/CormorantGaramond/v1/cormorant-garamond-v7-latin-ext_latin_cyrillic-700italic.woff2') format('woff2'),
    url('//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/CormorantGaramond/v1/cormorant-garamond-v7-latin-ext_latin_cyrillic-700italic.woff') format('woff');
}

/* PlayfairDisplay-Bold */

@font-face {
    font-family: "PlayfairDisplay-Bold";
    src: url("//fonts.gstatic.com/s/playfairdisplay/v13/UC3ZEjagJi85gF9qFaBgIPmrPH9ZsFqytabBz9sgz_Q.eot?#iefix");
    src: url("//fonts.gstatic.com/s/playfairdisplay/v13/UC3ZEjagJi85gF9qFaBgIPmrPH9ZsFqytabBz9sgz_Q.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/playfairdisplay/v13/UC3ZEjagJi85gF9qFaBgIIWMvkC5IXg8PD2cMeMDjBI.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/playfairdisplay/v13/UC3ZEjagJi85gF9qFaBgIMITpqSvb0EhPNqvdm-qG4s.woff") format("woff"),
    url("//fonts.gstatic.com/s/playfairdisplay/v13/UC3ZEjagJi85gF9qFaBgIETnlckwlsa9ycyidjAp5Kc.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=UC3ZEjagJi85gF9qFaBgIMnytsXa_r9I1moNmPEKxr4&skey=c119c2be8134ed06&v=v13#PlayfairDisplay") format("svg");
}

@font-face {
    font-family: "PlayfairDisplay-Bold";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/playfairdisplay/v13/UC3ZEjagJi85gF9qFaBgIPqcSpnvWCHzQNKqku5JWIY.eot?#iefix");
    src: url("//fonts.gstatic.com/s/playfairdisplay/v13/UC3ZEjagJi85gF9qFaBgIPqcSpnvWCHzQNKqku5JWIY.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/playfairdisplay/v13/UC3ZEjagJi85gF9qFaBgILxv9TIgpWQaRKdG-_MdlP0.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/playfairdisplay/v13/UC3ZEjagJi85gF9qFaBgIIidMZaDCgb76Cj_Fd30HHc.woff") format("woff"),
    url("//fonts.gstatic.com/s/playfairdisplay/v13/UC3ZEjagJi85gF9qFaBgIBczLBIbQ3AJzFR3-m2VmLg.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=UC3ZEjagJi85gF9qFaBgIKCikRNRa47LAyIy5yIVXvc&skey=5c26bbaa7df0e616&v=v13#PlayfairDisplay") format("svg");
}

@font-face {
    font-family: "PlayfairDisplay-Bold";
    font-style: italic;
    src: url("//fonts.gstatic.com/s/playfairdisplay/v13/n7G4PqJvFP2Kubl0VBLDEFESDfruYL5oKOAJzNJb7ys.eot?#iefix");
    src: url("//fonts.gstatic.com/s/playfairdisplay/v13/n7G4PqJvFP2Kubl0VBLDEFESDfruYL5oKOAJzNJb7ys.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/playfairdisplay/v13/n7G4PqJvFP2Kubl0VBLDEPizZYmr4BUkAcTxjCN2kLE.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/playfairdisplay/v13/n7G4PqJvFP2Kubl0VBLDENxHfcsPlDajrhlFKgOPuYg.woff") format("woff"),
    url("//fonts.gstatic.com/s/playfairdisplay/v13/n7G4PqJvFP2Kubl0VBLDELo34k-OXaeZF4ilAYxgJ0c.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=n7G4PqJvFP2Kubl0VBLDEK8_Qdjw54vp4QRNW69d70M&skey=a95cefd51a12ec17&v=v13#PlayfairDisplay") format("svg");
}

@font-face {
    font-family: "PlayfairDisplay-Bold";
    font-weight: 700;
    font-style: italic;
    src: url("//fonts.gstatic.com/s/playfairdisplay/v13/n7G4PqJvFP2Kubl0VBLDEIwnLPDplx5S8AKag-I5qXU.eot?#iefix");
    src: url("//fonts.gstatic.com/s/playfairdisplay/v13/n7G4PqJvFP2Kubl0VBLDEIwnLPDplx5S8AKag-I5qXU.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/playfairdisplay/v13/n7G4PqJvFP2Kubl0VBLDEA9QP145tN5qB9RQEnC5ftI.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/playfairdisplay/v13/n7G4PqJvFP2Kubl0VBLDEBMHjY5M6rp_NSn2hjKJhfc.woff") format("woff"),
    url("//fonts.gstatic.com/s/playfairdisplay/v13/n7G4PqJvFP2Kubl0VBLDEEwFowWjhcb6pv3Dv1OTigc.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=n7G4PqJvFP2Kubl0VBLDEFAVE8WjwCPLYD-4C_k3wkc&skey=5aa2cfa063a6b631&v=v13#PlayfairDisplay") format("svg");
}

/** DancingScript-Regular **/

@font-face {
    font-family: "DancingScript-Regular";
    src: url("//fonts.gstatic.com/s/dancingscript/v9/DK0eTGXiZjN6yA8zAEyM2T9RCsRvjGRATIRlxBzwHdg.eot?#iefix");
    src: url("//fonts.gstatic.com/s/dancingscript/v9/DK0eTGXiZjN6yA8zAEyM2T9RCsRvjGRATIRlxBzwHdg.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/dancingscript/v9/DK0eTGXiZjN6yA8zAEyM2RN-0beyHaEC1kqeqPFpWrs.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/dancingscript/v9/DK0eTGXiZjN6yA8zAEyM2UtCETOCmz2wCdel46UOhAM.woff") format("woff"),
    url("//fonts.gstatic.com/s/dancingscript/v9/DK0eTGXiZjN6yA8zAEyM2fog-Cy6dhy5Xgu82688fSg.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=DK0eTGXiZjN6yA8zAEyM2cGf0DEE6mlqV9opp_1pRbI&skey=c89f400061e5d0a8&v=v9#DancingScript") format("svg");
}


@font-face {
    font-family: "DancingScript-Regular";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/dancingscript/v9/KGBfwabt0ZRLA5W1ywjowd1F__mTQJ--pRXs2EOmsg0.eot?#iefix");
    src: url("//fonts.gstatic.com/s/dancingscript/v9/KGBfwabt0ZRLA5W1ywjowd1F__mTQJ--pRXs2EOmsg0.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/dancingscript/v9/KGBfwabt0ZRLA5W1ywjowZR92E8gBbe58j0pHY_YhTY.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/dancingscript/v9/KGBfwabt0ZRLA5W1ywjowW_WCyVccUAWDspcx_4UXqg.woff") format("woff"),
    url("//fonts.gstatic.com/s/dancingscript/v9/KGBfwabt0ZRLA5W1ywjowWfbPar0qrg-I_8uTXkQ0Sc.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=KGBfwabt0ZRLA5W1ywjowT9GhUFziu5FA7LV6roWAHM&skey=4fd71febfd48d6c&v=v9#DancingScript") format("svg");
}


/* Raleway-SemiBold */

@font-face {
    font-family: "Raleway-SemiBold";
    src: url("//fonts.gstatic.com/s/raleway/v12/STBOO2waD2LpX45SXYjQBVQlYEbsez9cZjKsNMjLOwM.eot?#iefix");
    src: url("//fonts.gstatic.com/s/raleway/v12/STBOO2waD2LpX45SXYjQBVQlYEbsez9cZjKsNMjLOwM.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/raleway/v12/STBOO2waD2LpX45SXYjQBfk_vArhqVIZ0nv9q090hN8.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/raleway/v12/STBOO2waD2LpX45SXYjQBRsxEYwM7FgeyaSgU71cLG0.woff") format("woff"),
    url("//fonts.gstatic.com/s/raleway/v12/STBOO2waD2LpX45SXYjQBS3USBnSvpkopQaUR-2r7iU.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=STBOO2waD2LpX45SXYjQBaWUboTb-jS2tyCOQMtm97g&skey=484edb0fdce88a64&v=v12#Raleway") format("svg");
}

@font-face {
    font-family: "Raleway-SemiBold";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/raleway/v12/WmVKXVcOuffP_qmCpFuyzVQlYEbsez9cZjKsNMjLOwM.eot?#iefix");
    src: url("//fonts.gstatic.com/s/raleway/v12/WmVKXVcOuffP_qmCpFuyzVQlYEbsez9cZjKsNMjLOwM.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/raleway/v12/WmVKXVcOuffP_qmCpFuyzfk_vArhqVIZ0nv9q090hN8.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/raleway/v12/WmVKXVcOuffP_qmCpFuyzRsxEYwM7FgeyaSgU71cLG0.woff") format("woff"),
    url("//fonts.gstatic.com/s/raleway/v12/WmVKXVcOuffP_qmCpFuyzS3USBnSvpkopQaUR-2r7iU.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=WmVKXVcOuffP_qmCpFuyzaWUboTb-jS2tyCOQMtm97g&skey=e507c3e2b7915ad1&v=v12#Raleway") format("svg");
}

@font-face {
    font-family: "Raleway-SemiBold";
    font-style: italic;
    src: url("//fonts.gstatic.com/s/raleway/v12/OY22yoG8EJ3IN_muVWm29KlSqKUsDpiXlwfj-ZM2w_A.eot?#iefix");
    src: url("//fonts.gstatic.com/s/raleway/v12/OY22yoG8EJ3IN_muVWm29KlSqKUsDpiXlwfj-ZM2w_A.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/raleway/v12/OY22yoG8EJ3IN_muVWm29BUOjZSKWg4xBWp_C_qQx0o.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/raleway/v12/OY22yoG8EJ3IN_muVWm29Ba1RVmPjeKy21_GQJaLlJI.woff") format("woff"),
    url("//fonts.gstatic.com/s/raleway/v12/OY22yoG8EJ3IN_muVWm29NqQynqKV_9Plp7mupa0S4g.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=OY22yoG8EJ3IN_muVWm29N1LKoZ82bBu2f46DhHcs3c&skey=cb4eb159e5e3db1f&v=v12#Raleway") format("svg");
}

@font-face {
    font-family: "Raleway-SemiBold";
    font-weight: 700;
    font-style: italic;
    src: url("//fonts.gstatic.com/s/raleway/v12/lFxvRPuGFG5ktd7P0WRwKqlSqKUsDpiXlwfj-ZM2w_A.eot?#iefix");
    src: url("//fonts.gstatic.com/s/raleway/v12/lFxvRPuGFG5ktd7P0WRwKqlSqKUsDpiXlwfj-ZM2w_A.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/raleway/v12/lFxvRPuGFG5ktd7P0WRwKhUOjZSKWg4xBWp_C_qQx0o.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/raleway/v12/lFxvRPuGFG5ktd7P0WRwKha1RVmPjeKy21_GQJaLlJI.woff") format("woff"),
    url("//fonts.gstatic.com/s/raleway/v12/lFxvRPuGFG5ktd7P0WRwKtqQynqKV_9Plp7mupa0S4g.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=lFxvRPuGFG5ktd7P0WRwKt1LKoZ82bBu2f46DhHcs3c&skey=9ecf9384a6d643b6&v=v12#Raleway") format("svg");
}

/* Lato-Light */

@font-face {
    font-family: "Lato-Light";
    src: url("//fonts.gstatic.com/s/lato/v14/KDRyPGFdQxeFClMSxPKQ3w.eot?#iefix");
    src: url("//fonts.gstatic.com/s/lato/v14/KDRyPGFdQxeFClMSxPKQ3w.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/lato/v14/2hXzmNaFRuKTSBR9nRGO-A.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/lato/v14/kU6VHbqMAZhaN_nXCmLQsQ.woff") format("woff"),
    url("//fonts.gstatic.com/s/lato/v14/BTu4SsVveqk58cdYjlaM9g.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=I5jxx2JZduMchyTN9Dgylg&skey=91f32e07d083dd3a&v=v14#Lato") format("svg");
}

@font-face {
    font-family: "Lato-Light";
    font-weight: 700;
    src: url("//fonts.gstatic.com/s/lato/v14/6TEmgPQ_0ZdLPE7b6hhIjQ.eot?#iefix");
    src: url("//fonts.gstatic.com/s/lato/v14/6TEmgPQ_0ZdLPE7b6hhIjQ.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/lato/v14/7nLfsQCzhQW_PwpkrwroYw.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/lato/v14/I1Pn3gihk5vyP0Yw5GqKsQ.woff") format("woff"),
    url("//fonts.gstatic.com/s/lato/v14/zpv3sOKAbMf4wff105oLjw.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=adjMoXVaHbO08wMAF5yDsA&skey=3480a19627739c0d&v=v14#Lato") format("svg");
}

@font-face {
    font-family: "Lato-Light";
    font-style: italic;
    src: url("//fonts.gstatic.com/s/lato/v14/XNVd6tsqi9wmKNvnh5HNEPY6323mHUZFJMgTvxaG2iE.eot?#iefix");
    src: url("//fonts.gstatic.com/s/lato/v14/XNVd6tsqi9wmKNvnh5HNEPY6323mHUZFJMgTvxaG2iE.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/lato/v14/XNVd6tsqi9wmKNvnh5HNEFtXRa8TVwTICgirnJhmVJw.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/lato/v14/XNVd6tsqi9wmKNvnh5HNED8E0i7KZn-EPnyo3HZu7kw.woff") format("woff"),
    url("//fonts.gstatic.com/s/lato/v14/XNVd6tsqi9wmKNvnh5HNEKCWcynf_cDxXwCLxiixG1c.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=XNVd6tsqi9wmKNvnh5HNEJbd9NUM7myrQQz30yPaGQ4&skey=8107d606b7e3d38e&v=v14#Lato") format("svg");
}

@font-face {
    font-family: "Lato-Light";
    font-weight: 700;
    font-style: italic;
    src: url("//fonts.gstatic.com/s/lato/v14/AcvTq8Q0lyKKNxRlL28Rn_Y6323mHUZFJMgTvxaG2iE.eot?#iefix");
    src: url("//fonts.gstatic.com/s/lato/v14/AcvTq8Q0lyKKNxRlL28Rn_Y6323mHUZFJMgTvxaG2iE.eot?#iefix") format("eot"),
    url("//fonts.gstatic.com/s/lato/v14/AcvTq8Q0lyKKNxRlL28Rn1tXRa8TVwTICgirnJhmVJw.woff2") format("woff2"),
    url("//fonts.gstatic.com/s/lato/v14/AcvTq8Q0lyKKNxRlL28Rnz8E0i7KZn-EPnyo3HZu7kw.woff") format("woff"),
    url("//fonts.gstatic.com/s/lato/v14/AcvTq8Q0lyKKNxRlL28Rn6CWcynf_cDxXwCLxiixG1c.ttf") format("truetype"),
    url("//fonts.gstatic.com/l/font?kit=AcvTq8Q0lyKKNxRlL28Rn5bd9NUM7myrQQz30yPaGQ4&skey=5334e9c0b67702e2&v=v14#Lato") format("svg");
}

@font-face {
    font-family: "August-Bold";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustBold/v1/augustbold-webfont.eot?#iefix");
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustBold/v1/augustbold-webfont.eot?#iefix") format("eot"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustBold/v1/augustbold-webfont.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustBold/v1/augustbold-webfont.woff") format("woff"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustBold/v1/augustbold-webfont.ttf") format("truetype"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustBold/v1/augustbold-webfont.svg") format("svg");
}

@font-face {
    font-family: "August-Light";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustLight/v1/augustlight-webfont.eot?#iefix");
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustLight/v1/augustlight-webfont.eot?#iefix") format("eot"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustLight/v1/augustlight-webfont.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustLight/v1/augustlight-webfont.woff") format("woff"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustLight/v1/augustlight-webfont.ttf") format("truetype"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustLight/v1/augustlight-webfont.svg") format("svg");
}

@font-face {
    font-family: "August-Medium";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustMedium/v1/augustmedium-webfont.eot?#iefix");
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustMedium/v1/augustmedium-webfont.eot?#iefix") format("eot"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustMedium/v1/augustmedium-webfont.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustMedium/v1/augustmedium-webfont.woff") format("woff"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustMedium/v1/augustmedium-webfont.ttf") format("truetype"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/AugustMedium/v1/augustmedium-webfont.svg") format("svg");
}

@font-face {
    font-family: "Knedge-Bold";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/KnedgeBold/v1/knedgebold-webfont.eot?#iefix");
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/KnedgeBold/v1/knedgebold-webfont.eot?#iefix") format("eot"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/KnedgeBold/v1/knedgebold-webfont.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/KnedgeBold/v1/knedgebold-webfont.woff") format("woff"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/KnedgeBold/v1/knedgebold-webfont.ttf") format("truetype"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/KnedgeBold/v1/knedgebold-webfont.svg") format("svg");
}

@font-face {
    font-family: "TsukushiGothic";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/TsukushiGothic/v1/WIX-TsukuGoPr5-R.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/TsukushiGothic/v1/WIX-TsukuGoPr5-R.woff") format("woff")
}
@font-face {
    font-family: "TsukushiGothic";
    font-weight: 700;
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/TsukushiGothic/v1/WIX-TsukuGoPr5-D.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/TsukushiGothic/v1/WIX-TsukuGoPr5-D.woff") format("woff")
}

@font-face {
    font-family: "Rodin-Light";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Rodin/v1/WIX-RodinProN-L.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Rodin/v1/WIX-RodinProN-L.woff") format("woff")
}
/* mapped to rodin-medium*/
@font-face {
    font-family: "Rodin-Light";
    font-weight: 700;
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Rodin/v1/WIX-RodinProN-M.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Rodin/v1/WIX-RodinProN-M.woff") format("woff")
}

@font-face {
    font-family: "Rodin-Demi-Bold";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Rodin/v1/WIX-RodinProN-DB.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Rodin/v1/WIX-RodinProN-DB.woff") format("woff")
}

@font-face {
    font-family: "NewCezanne";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/NewCezanne/v1/WIX-NewCezanneProN-M.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/NewCezanne/v1/WIX-NewCezanneProN-M.woff") format("woff")
}

@font-face {
    font-family: "UDKakugoLarge";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/UDKakugoLarge/v1/WIX-UDKakugo_LargePr6N-M.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/UDKakugoLarge/v1/WIX-UDKakugo_LargePr6N-M.woff") format("woff")
}
@font-face {
    font-family: "UDKakugoLarge";
    font-weight: 700;
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/UDKakugoLarge/v1/WIX-UDKakugo_LargePr6N-DB.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/UDKakugoLarge/v1/WIX-UDKakugo_LargePr6N-DB.woff") format("woff")
}

@font-face {
    font-family: "TsukushiMaruGothic";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/TsukushiMaruGothic/v1/WIX-TsukuARdGothicStd-M.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/TsukushiMaruGothic/v1/WIX-TsukuARdGothicStd-M.woff") format("woff")
}
@font-face {
    font-family: "TsukushiMaruGothic";
    font-weight: 700;
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/TsukushiMaruGothic/v1/WIX-TsukuARdGothicStd-B.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/TsukushiMaruGothic/v1/WIX-TsukuARdGothicStd-B.woff") format("woff")
}

@font-face {
    font-family: "Seurat";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Seurat/v1/WIX-SeuratProN-M.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Seurat/v1/WIX-SeuratProN-M.woff") format("woff")
}
@font-face {
    font-family: "Seurat";
    font-weight: 700;
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Seurat/v1/WIX-SeuratProN-DB.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Seurat/v1/WIX-SeuratProN-DB.woff") format("woff")
}

@font-face {
    font-family: "TsukushiBMaruGothic";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/TsukushiBMaruGothic/v1/WIX-TsukuBRdGothicStd-M.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/TsukushiBMaruGothic/v1/WIX-TsukuBRdGothicStd-M.woff") format("woff")
}

@font-face {
    font-family: "UDMincho";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/UDMincho/v1/WIX-UDMinchoPr6N-M.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/UDMincho/v1/WIX-UDMinchoPr6N-M.woff") format("woff")
}
@font-face {
    font-family: "UDMincho";
    font-weight: 700;
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/UDMincho/v1/WIX-UDMinchoPr6N-DB.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/UDMincho/v1/WIX-UDMinchoPr6N-DB.woff") format("woff")
}

@font-face {
    font-family: "TsukushiOldMincho";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/TsukushiOldMincho/v1/WIX-TsukuAOldMinPr6N-M.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/TsukushiOldMincho/v1/WIX-TsukuAOldMinPr6N-M.woff") format("woff")
}

@font-face {
    font-family: "Matisse";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Matisse/v1/WIX-MatisseProN-M.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Matisse/v1/WIX-MatisseProN-M.woff") format("woff")
}
@font-face {
    font-family: "Matisse";
    font-weight: 700;
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Matisse/v1/WIX-MatisseProN-DB.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Matisse/v1/WIX-MatisseProN-DB.woff") format("woff")
}

@font-face {
    font-family: "Skip";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Skip/v1/WIX-SkipStd-M.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Skip/v1/WIX-SkipStd-M.woff") format("woff")
}

@font-face {
    font-family: "Cookhand";
    src: url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Cookhand/v1/WIX-CookHandStd-R.woff2") format("woff2"),
    url("//static.parastorage.com/services/santa-resources/resources/viewer/user-site-fonts/fonts/Japanese/Cookhand/v1/WIX-CookHandStd-R.woff") format("woff")
}

                </style>
            

            
                <style id="fonts.googleapis">
                    /* cyrillic */
@font-face {
  font-family: 'Amatic SC';
  font-style: normal;
  font-weight: 400;
  src: local('Amatic SC Regular'), local('AmaticSC-Regular'), url(https://fonts.gstatic.com/s/amaticsc/v13/TUZyzwprpvBS1izr_vOEDuSfQZQ.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* hebrew */
@font-face {
  font-family: 'Amatic SC';
  font-style: normal;
  font-weight: 400;
  src: local('Amatic SC Regular'), local('AmaticSC-Regular'), url(https://fonts.gstatic.com/s/amaticsc/v13/TUZyzwprpvBS1izr_vOECOSfQZQ.woff2) format('woff2');
  unicode-range: U+0590-05FF, U+20AA, U+25CC, U+FB1D-FB4F;
}
/* vietnamese */
@font-face {
  font-family: 'Amatic SC';
  font-style: normal;
  font-weight: 400;
  src: local('Amatic SC Regular'), local('AmaticSC-Regular'), url(https://fonts.gstatic.com/s/amaticsc/v13/TUZyzwprpvBS1izr_vOEBeSfQZQ.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Amatic SC';
  font-style: normal;
  font-weight: 400;
  src: local('Amatic SC Regular'), local('AmaticSC-Regular'), url(https://fonts.gstatic.com/s/amaticsc/v13/TUZyzwprpvBS1izr_vOEBOSfQZQ.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Amatic SC';
  font-style: normal;
  font-weight: 400;
  src: local('Amatic SC Regular'), local('AmaticSC-Regular'), url(https://fonts.gstatic.com/s/amaticsc/v13/TUZyzwprpvBS1izr_vOECuSf.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic */
@font-face {
  font-family: 'Amatic SC';
  font-style: normal;
  font-weight: 700;
  src: local('Amatic SC Bold'), local('AmaticSC-Bold'), url(https://fonts.gstatic.com/s/amaticsc/v13/TUZ3zwprpvBS1izr_vOMscGKerUC7WQ.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* hebrew */
@font-face {
  font-family: 'Amatic SC';
  font-style: normal;
  font-weight: 700;
  src: local('Amatic SC Bold'), local('AmaticSC-Bold'), url(https://fonts.gstatic.com/s/amaticsc/v13/TUZ3zwprpvBS1izr_vOMscGKfLUC7WQ.woff2) format('woff2');
  unicode-range: U+0590-05FF, U+20AA, U+25CC, U+FB1D-FB4F;
}
/* vietnamese */
@font-face {
  font-family: 'Amatic SC';
  font-style: normal;
  font-weight: 700;
  src: local('Amatic SC Bold'), local('AmaticSC-Bold'), url(https://fonts.gstatic.com/s/amaticsc/v13/TUZ3zwprpvBS1izr_vOMscGKcbUC7WQ.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Amatic SC';
  font-style: normal;
  font-weight: 700;
  src: local('Amatic SC Bold'), local('AmaticSC-Bold'), url(https://fonts.gstatic.com/s/amaticsc/v13/TUZ3zwprpvBS1izr_vOMscGKcLUC7WQ.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Amatic SC';
  font-style: normal;
  font-weight: 700;
  src: local('Amatic SC Bold'), local('AmaticSC-Bold'), url(https://fonts.gstatic.com/s/amaticsc/v13/TUZ3zwprpvBS1izr_vOMscGKfrUC.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Anton';
  font-style: normal;
  font-weight: 400;
  src: local('Anton Regular'), local('Anton-Regular'), url(https://fonts.gstatic.com/s/anton/v11/1Ptgg87LROyAm3K8-C8QSw.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Anton';
  font-style: normal;
  font-weight: 400;
  src: local('Anton Regular'), local('Anton-Regular'), url(https://fonts.gstatic.com/s/anton/v11/1Ptgg87LROyAm3K9-C8QSw.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Anton';
  font-style: normal;
  font-weight: 400;
  src: local('Anton Regular'), local('Anton-Regular'), url(https://fonts.gstatic.com/s/anton/v11/1Ptgg87LROyAm3Kz-C8.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Barlow';
  font-style: italic;
  font-weight: 400;
  src: local('Barlow Italic'), local('Barlow-Italic'), url(https://fonts.gstatic.com/s/barlow/v4/7cHrv4kjgoGqM7E_Cfs0wH8RnA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Barlow';
  font-style: italic;
  font-weight: 400;
  src: local('Barlow Italic'), local('Barlow-Italic'), url(https://fonts.gstatic.com/s/barlow/v4/7cHrv4kjgoGqM7E_Cfs1wH8RnA.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Barlow';
  font-style: italic;
  font-weight: 400;
  src: local('Barlow Italic'), local('Barlow-Italic'), url(https://fonts.gstatic.com/s/barlow/v4/7cHrv4kjgoGqM7E_Cfs7wH8.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Barlow';
  font-style: italic;
  font-weight: 700;
  src: local('Barlow Bold Italic'), local('Barlow-BoldItalic'), url(https://fonts.gstatic.com/s/barlow/v4/7cHsv4kjgoGqM7E_CfOA5WohvTobdw.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Barlow';
  font-style: italic;
  font-weight: 700;
  src: local('Barlow Bold Italic'), local('Barlow-BoldItalic'), url(https://fonts.gstatic.com/s/barlow/v4/7cHsv4kjgoGqM7E_CfOA5WogvTobdw.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Barlow';
  font-style: italic;
  font-weight: 700;
  src: local('Barlow Bold Italic'), local('Barlow-BoldItalic'), url(https://fonts.gstatic.com/s/barlow/v4/7cHsv4kjgoGqM7E_CfOA5WouvTo.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Barlow';
  font-style: normal;
  font-weight: 400;
  src: local('Barlow Regular'), local('Barlow-Regular'), url(https://fonts.gstatic.com/s/barlow/v4/7cHpv4kjgoGqM7E_A8s52Hs.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Barlow';
  font-style: normal;
  font-weight: 400;
  src: local('Barlow Regular'), local('Barlow-Regular'), url(https://fonts.gstatic.com/s/barlow/v4/7cHpv4kjgoGqM7E_Ass52Hs.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Barlow';
  font-style: normal;
  font-weight: 400;
  src: local('Barlow Regular'), local('Barlow-Regular'), url(https://fonts.gstatic.com/s/barlow/v4/7cHpv4kjgoGqM7E_DMs5.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Barlow';
  font-style: normal;
  font-weight: 700;
  src: local('Barlow Bold'), local('Barlow-Bold'), url(https://fonts.gstatic.com/s/barlow/v4/7cHqv4kjgoGqM7E3t-4s6FospT4.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Barlow';
  font-style: normal;
  font-weight: 700;
  src: local('Barlow Bold'), local('Barlow-Bold'), url(https://fonts.gstatic.com/s/barlow/v4/7cHqv4kjgoGqM7E3t-4s6VospT4.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Barlow';
  font-style: normal;
  font-weight: 700;
  src: local('Barlow Bold'), local('Barlow-Bold'), url(https://fonts.gstatic.com/s/barlow/v4/7cHqv4kjgoGqM7E3t-4s51os.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Basic';
  font-style: normal;
  font-weight: 400;
  src: local('Basic Regular'), local('Basic-Regular'), url(https://fonts.gstatic.com/s/basic/v9/xfu_0WLxV2_XKTN-6FHlyQ.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Basic';
  font-style: normal;
  font-weight: 400;
  src: local('Basic Regular'), local('Basic-Regular'), url(https://fonts.gstatic.com/s/basic/v9/xfu_0WLxV2_XKTNw6FE.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* greek-ext */
@font-face {
  font-family: 'Caudex';
  font-style: italic;
  font-weight: 400;
  src: local('Caudex Italic'), local('Caudex-Italic'), url(https://fonts.gstatic.com/s/caudex/v9/esDS311QOP6BJUr4yMKPtbo-Ew.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Caudex';
  font-style: italic;
  font-weight: 400;
  src: local('Caudex Italic'), local('Caudex-Italic'), url(https://fonts.gstatic.com/s/caudex/v9/esDS311QOP6BJUr4yMKAtbo-Ew.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* latin-ext */
@font-face {
  font-family: 'Caudex';
  font-style: italic;
  font-weight: 400;
  src: local('Caudex Italic'), local('Caudex-Italic'), url(https://fonts.gstatic.com/s/caudex/v9/esDS311QOP6BJUr4yMKNtbo-Ew.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Caudex';
  font-style: italic;
  font-weight: 400;
  src: local('Caudex Italic'), local('Caudex-Italic'), url(https://fonts.gstatic.com/s/caudex/v9/esDS311QOP6BJUr4yMKDtbo.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* greek-ext */
@font-face {
  font-family: 'Caudex';
  font-style: italic;
  font-weight: 700;
  src: local('Caudex Bold Italic'), local('Caudex-BoldItalic'), url(https://fonts.gstatic.com/s/caudex/v9/esDV311QOP6BJUr4yMo4kK8NMpWeGQ.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Caudex';
  font-style: italic;
  font-weight: 700;
  src: local('Caudex Bold Italic'), local('Caudex-BoldItalic'), url(https://fonts.gstatic.com/s/caudex/v9/esDV311QOP6BJUr4yMo4kK8CMpWeGQ.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* latin-ext */
@font-face {
  font-family: 'Caudex';
  font-style: italic;
  font-weight: 700;
  src: local('Caudex Bold Italic'), local('Caudex-BoldItalic'), url(https://fonts.gstatic.com/s/caudex/v9/esDV311QOP6BJUr4yMo4kK8PMpWeGQ.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Caudex';
  font-style: italic;
  font-weight: 700;
  src: local('Caudex Bold Italic'), local('Caudex-BoldItalic'), url(https://fonts.gstatic.com/s/caudex/v9/esDV311QOP6BJUr4yMo4kK8BMpU.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* greek-ext */
@font-face {
  font-family: 'Caudex';
  font-style: normal;
  font-weight: 400;
  src: local('Caudex'), url(https://fonts.gstatic.com/s/caudex/v9/esDQ311QOP6BJUr4wfKBrb4.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Caudex';
  font-style: normal;
  font-weight: 400;
  src: local('Caudex'), url(https://fonts.gstatic.com/s/caudex/v9/esDQ311QOP6BJUr4zvKBrb4.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* latin-ext */
@font-face {
  font-family: 'Caudex';
  font-style: normal;
  font-weight: 400;
  src: local('Caudex'), url(https://fonts.gstatic.com/s/caudex/v9/esDQ311QOP6BJUr4w_KBrb4.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Caudex';
  font-style: normal;
  font-weight: 400;
  src: local('Caudex'), url(https://fonts.gstatic.com/s/caudex/v9/esDQ311QOP6BJUr4zfKB.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* greek-ext */
@font-face {
  font-family: 'Caudex';
  font-style: normal;
  font-weight: 700;
  src: local('Caudex Bold'), local('Caudex-Bold'), url(https://fonts.gstatic.com/s/caudex/v9/esDT311QOP6BJUrwdteUnp8DKpE.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Caudex';
  font-style: normal;
  font-weight: 700;
  src: local('Caudex Bold'), local('Caudex-Bold'), url(https://fonts.gstatic.com/s/caudex/v9/esDT311QOP6BJUrwdteUkZ8DKpE.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* latin-ext */
@font-face {
  font-family: 'Caudex';
  font-style: normal;
  font-weight: 700;
  src: local('Caudex Bold'), local('Caudex-Bold'), url(https://fonts.gstatic.com/s/caudex/v9/esDT311QOP6BJUrwdteUnJ8DKpE.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Caudex';
  font-style: normal;
  font-weight: 700;
  src: local('Caudex Bold'), local('Caudex-Bold'), url(https://fonts.gstatic.com/s/caudex/v9/esDT311QOP6BJUrwdteUkp8D.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chelsea Market';
  font-style: normal;
  font-weight: 400;
  src: local('Chelsea Market'), local('ChelseaMarket-Regular'), url(https://fonts.gstatic.com/s/chelseamarket/v8/BCawqZsHqfr89WNP_IApC8tzKChsJg8eKg.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chelsea Market';
  font-style: normal;
  font-weight: 400;
  src: local('Chelsea Market'), local('ChelseaMarket-Regular'), url(https://fonts.gstatic.com/s/chelseamarket/v8/BCawqZsHqfr89WNP_IApC8tzKChiJg8.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Cinzel';
  font-style: normal;
  font-weight: 400;
  src: local('Cinzel Regular'), local('Cinzel-Regular'), url(https://fonts.gstatic.com/s/cinzel/v9/8vIJ7ww63mVu7gt7-GT7LEc.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Cinzel';
  font-style: normal;
  font-weight: 400;
  src: local('Cinzel Regular'), local('Cinzel-Regular'), url(https://fonts.gstatic.com/s/cinzel/v9/8vIJ7ww63mVu7gt79mT7.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Cinzel';
  font-style: normal;
  font-weight: 700;
  src: local('Cinzel Bold'), local('Cinzel-Bold'), url(https://fonts.gstatic.com/s/cinzel/v9/8vIK7ww63mVu7gtzTUHuHWZaC_w.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Cinzel';
  font-style: normal;
  font-weight: 700;
  src: local('Cinzel Bold'), local('Cinzel-Bold'), url(https://fonts.gstatic.com/s/cinzel/v9/8vIK7ww63mVu7gtzTUHuE2Za.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin */
@font-face {
  font-family: 'Cookie';
  font-style: normal;
  font-weight: 400;
  src: local('Cookie-Regular'), url(https://fonts.gstatic.com/s/cookie/v11/syky-y18lb0tSbf9kgqS.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Corben';
  font-style: normal;
  font-weight: 400;
  src: local('Corben Regular'), local('Corben-Regular'), url(https://fonts.gstatic.com/s/corben/v14/LYjDdGzzklQtCMpNqQNFlVs.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Corben';
  font-style: normal;
  font-weight: 400;
  src: local('Corben Regular'), local('Corben-Regular'), url(https://fonts.gstatic.com/s/corben/v14/LYjDdGzzklQtCMpNpwNF.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Corben';
  font-style: normal;
  font-weight: 700;
  src: local('Corben'), url(https://fonts.gstatic.com/s/corben/v14/LYjAdGzzklQtCMpFHCZQpHoqbN4.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Corben';
  font-style: normal;
  font-weight: 700;
  src: local('Corben'), url(https://fonts.gstatic.com/s/corben/v14/LYjAdGzzklQtCMpFHCZQqnoq.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: italic;
  font-weight: 400;
  src: local('Cormorant Garamond Italic'), local('CormorantGaramond-Italic'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3ZmX5slCNuHLi8bLeY9MK7whWMhyjYrEtFmSq17w.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: italic;
  font-weight: 400;
  src: local('Cormorant Garamond Italic'), local('CormorantGaramond-Italic'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3ZmX5slCNuHLi8bLeY9MK7whWMhyjYrEtMmSq17w.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: italic;
  font-weight: 400;
  src: local('Cormorant Garamond Italic'), local('CormorantGaramond-Italic'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3ZmX5slCNuHLi8bLeY9MK7whWMhyjYrEtHmSq17w.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: italic;
  font-weight: 400;
  src: local('Cormorant Garamond Italic'), local('CormorantGaramond-Italic'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3ZmX5slCNuHLi8bLeY9MK7whWMhyjYrEtGmSq17w.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: italic;
  font-weight: 400;
  src: local('Cormorant Garamond Italic'), local('CormorantGaramond-Italic'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3ZmX5slCNuHLi8bLeY9MK7whWMhyjYrEtImSo.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: italic;
  font-weight: 700;
  src: local('Cormorant Garamond Bold Italic'), local('CormorantGaramond-BoldItalic'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3WmX5slCNuHLi8bLeY9MK7whWMhyjYrEPzvD-HzhO7_w.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: italic;
  font-weight: 700;
  src: local('Cormorant Garamond Bold Italic'), local('CormorantGaramond-BoldItalic'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3WmX5slCNuHLi8bLeY9MK7whWMhyjYrEPzvD-OzhO7_w.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: italic;
  font-weight: 700;
  src: local('Cormorant Garamond Bold Italic'), local('CormorantGaramond-BoldItalic'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3WmX5slCNuHLi8bLeY9MK7whWMhyjYrEPzvD-FzhO7_w.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: italic;
  font-weight: 700;
  src: local('Cormorant Garamond Bold Italic'), local('CormorantGaramond-BoldItalic'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3WmX5slCNuHLi8bLeY9MK7whWMhyjYrEPzvD-EzhO7_w.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: italic;
  font-weight: 700;
  src: local('Cormorant Garamond Bold Italic'), local('CormorantGaramond-BoldItalic'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3WmX5slCNuHLi8bLeY9MK7whWMhyjYrEPzvD-KzhM.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: normal;
  font-weight: 400;
  src: local('Cormorant Garamond Regular'), local('CormorantGaramond-Regular'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3bmX5slCNuHLi8bLeY9MK7whWMhyjYpHtKgS4.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: normal;
  font-weight: 400;
  src: local('Cormorant Garamond Regular'), local('CormorantGaramond-Regular'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3bmX5slCNuHLi8bLeY9MK7whWMhyjYrXtKgS4.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: normal;
  font-weight: 400;
  src: local('Cormorant Garamond Regular'), local('CormorantGaramond-Regular'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3bmX5slCNuHLi8bLeY9MK7whWMhyjYpntKgS4.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: normal;
  font-weight: 400;
  src: local('Cormorant Garamond Regular'), local('CormorantGaramond-Regular'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3bmX5slCNuHLi8bLeY9MK7whWMhyjYp3tKgS4.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: normal;
  font-weight: 400;
  src: local('Cormorant Garamond Regular'), local('CormorantGaramond-Regular'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3bmX5slCNuHLi8bLeY9MK7whWMhyjYqXtK.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: normal;
  font-weight: 700;
  src: local('Cormorant Garamond Bold'), local('CormorantGaramond-Bold'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3YmX5slCNuHLi8bLeY9MK7whWMhyjQEl5fsw-I1hc.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: normal;
  font-weight: 700;
  src: local('Cormorant Garamond Bold'), local('CormorantGaramond-Bold'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3YmX5slCNuHLi8bLeY9MK7whWMhyjQEl5fug-I1hc.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: normal;
  font-weight: 700;
  src: local('Cormorant Garamond Bold'), local('CormorantGaramond-Bold'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3YmX5slCNuHLi8bLeY9MK7whWMhyjQEl5fsQ-I1hc.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: normal;
  font-weight: 700;
  src: local('Cormorant Garamond Bold'), local('CormorantGaramond-Bold'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3YmX5slCNuHLi8bLeY9MK7whWMhyjQEl5fsA-I1hc.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Cormorant Garamond';
  font-style: normal;
  font-weight: 700;
  src: local('Cormorant Garamond Bold'), local('CormorantGaramond-Bold'), url(https://fonts.gstatic.com/s/cormorantgaramond/v7/co3YmX5slCNuHLi8bLeY9MK7whWMhyjQEl5fvg-I.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin */
@font-face {
  font-family: 'Damion';
  font-style: normal;
  font-weight: 400;
  src: local('Damion'), url(https://fonts.gstatic.com/s/damion/v9/hv-XlzJ3KEUe_YZkamw2.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Dancing Script';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/dancingscript/v15/If2RXTr6YS-zF4S-kcSWSVi_szLviuEViw.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Dancing Script';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/dancingscript/v15/If2RXTr6YS-zF4S-kcSWSVi_szLuiuEViw.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Dancing Script';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/dancingscript/v15/If2RXTr6YS-zF4S-kcSWSVi_szLgiuE.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Dancing Script';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/dancingscript/v15/If2RXTr6YS-zF4S-kcSWSVi_szLviuEViw.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Dancing Script';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/dancingscript/v15/If2RXTr6YS-zF4S-kcSWSVi_szLuiuEViw.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Dancing Script';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/dancingscript/v15/If2RXTr6YS-zF4S-kcSWSVi_szLgiuE.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'EB Garamond';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGWmQSNjdsmc35JDF1K5GRweDY1ZzPJ.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'EB Garamond';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGWmQSNjdsmc35JDF1K5GRweD81ZzPJ.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'EB Garamond';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGWmQSNjdsmc35JDF1K5GRweDc1ZzPJ.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'EB Garamond';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGWmQSNjdsmc35JDF1K5GRweDg1ZzPJ.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'EB Garamond';


  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGWmQSNjdsmc35JDF1K5GRweDQ1ZzPJ.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'EB Garamond';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGWmQSNjdsmc35JDF1K5GRweDU1ZzPJ.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'EB Garamond';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGWmQSNjdsmc35JDF1K5GRweDs1Zw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'EB Garamond';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGWmQSNjdsmc35JDF1K5GRweDY1ZzPJ.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'EB Garamond';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGWmQSNjdsmc35JDF1K5GRweD81ZzPJ.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'EB Garamond';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGWmQSNjdsmc35JDF1K5GRweDc1ZzPJ.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'EB Garamond';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGWmQSNjdsmc35JDF1K5GRweDg1ZzPJ.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'EB Garamond';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGWmQSNjdsmc35JDF1K5GRweDQ1ZzPJ.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'EB Garamond';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGWmQSNjdsmc35JDF1K5GRweDU1ZzPJ.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'EB Garamond';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGWmQSNjdsmc35JDF1K5GRweDs1Zw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'EB Garamond';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGUmQSNjdsmc35JDF1K5GR4SDktYw.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'EB Garamond';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGUmQSNjdsmc35JDF1K5GRxSDktYw.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'EB Garamond';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGUmQSNjdsmc35JDF1K5GR5SDktYw.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'EB Garamond';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGUmQSNjdsmc35JDF1K5GR2SDktYw.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'EB Garamond';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGUmQSNjdsmc35JDF1K5GR6SDktYw.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'EB Garamond';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGUmQSNjdsmc35JDF1K5GR7SDktYw.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'EB Garamond';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGUmQSNjdsmc35JDF1K5GR1SDk.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'EB Garamond';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGUmQSNjdsmc35JDF1K5GR4SDktYw.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'EB Garamond';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGUmQSNjdsmc35JDF1K5GRxSDktYw.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'EB Garamond';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGUmQSNjdsmc35JDF1K5GR5SDktYw.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'EB Garamond';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGUmQSNjdsmc35JDF1K5GR2SDktYw.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'EB Garamond';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGUmQSNjdsmc35JDF1K5GR6SDktYw.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'EB Garamond';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGUmQSNjdsmc35JDF1K5GR7SDktYw.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'EB Garamond';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/ebgaramond/v14/SlGUmQSNjdsmc35JDF1K5GR1SDk.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Enriqueta';
  font-style: normal;
  font-weight: 400;
  src: local('Enriqueta Regular'), local('Enriqueta-Regular'), url(https://fonts.gstatic.com/s/enriqueta/v9/goksH6L7AUFrRvV44HVjQkqioP0.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Enriqueta';
  font-style: normal;
  font-weight: 400;
  src: local('Enriqueta Regular'), local('Enriqueta-Regular'), url(https://fonts.gstatic.com/s/enriqueta/v9/goksH6L7AUFrRvV44HVjTEqi.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Enriqueta';
  font-style: normal;
  font-weight: 700;
  src: local('Enriqueta Bold'), local('Enriqueta-Bold'), url(https://fonts.gstatic.com/s/enriqueta/v9/gokpH6L7AUFrRvV44HVr92-3kdxFm6Q.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Enriqueta';
  font-style: normal;
  font-weight: 700;
  src: local('Enriqueta Bold'), local('Enriqueta-Bold'), url(https://fonts.gstatic.com/s/enriqueta/v9/gokpH6L7AUFrRvV44HVr92-3n9xF.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Forum';
  font-style: normal;
  font-weight: 400;
  src: local('Forum'), url(https://fonts.gstatic.com/s/forum/v10/6aey4Ky-Vb8Ew8IcOpIq3g.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Forum';
  font-style: normal;
  font-weight: 400;
  src: local('Forum'), url(https://fonts.gstatic.com/s/forum/v10/6aey4Ky-Vb8Ew8IVOpIq3g.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* latin-ext */
@font-face {
  font-family: 'Forum';
  font-style: normal;
  font-weight: 400;
  src: local('Forum'), url(https://fonts.gstatic.com/s/forum/v10/6aey4Ky-Vb8Ew8IfOpIq3g.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Forum';
  font-style: normal;
  font-weight: 400;
  src: local('Forum'), url(https://fonts.gstatic.com/s/forum/v10/6aey4Ky-Vb8Ew8IROpI.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Fredericka the Great';
  font-style: normal;
  font-weight: 400;
  src: local('Fredericka the Great'), local('FrederickatheGreat'), url(https://fonts.gstatic.com/s/frederickathegreat/v9/9Bt33CxNwt7aOctW2xjbCstzwVKsIBVV--StxbcVcg.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Fredericka the Great';
  font-style: normal;
  font-weight: 400;
  src: local('Fredericka the Great'), local('FrederickatheGreat'), url(https://fonts.gstatic.com/s/frederickathegreat/v9/9Bt33CxNwt7aOctW2xjbCstzwVKsIBVV--Sjxbc.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Jockey One';
  font-style: normal;
  font-weight: 400;
  src: local('Jockey One'), local('JockeyOne-Regular'), url(https://fonts.gstatic.com/s/jockeyone/v9/HTxpL2g2KjCFj4x8WI6AnI_xHLOk.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Jockey One';
  font-style: normal;
  font-weight: 400;
  src: local('Jockey One'), local('JockeyOne-Regular'), url(https://fonts.gstatic.com/s/jockeyone/v9/HTxpL2g2KjCFj4x8WI6AnIHxHA.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin */
@font-face {
  font-family: 'Josefin Slab';
  font-style: italic;
  font-weight: 400;
  src: local('Josefin Slab Italic'), local('JosefinSlab-Italic'), url(https://fonts.gstatic.com/s/josefinslab/v10/lW-nwjwOK3Ps5GSJlNNkMalnrz6tDs8.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin */
@font-face {
  font-family: 'Josefin Slab';
  font-style: italic;
  font-weight: 700;
  src: local('Josefin Slab Bold Italic'), local('JosefinSlab-BoldItalic'), url(https://fonts.gstatic.com/s/josefinslab/v10/lW-kwjwOK3Ps5GSJlNNkMalnrzYWK9rnHg4.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin */
@font-face {
  font-family: 'Josefin Slab';
  font-style: normal;
  font-weight: 400;
  src: local('Josefin Slab Regular'), local('JosefinSlab-Regular'), url(https://fonts.gstatic.com/s/josefinslab/v10/lW-5wjwOK3Ps5GSJlNNkMalnqg6v.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin */
@font-face {
  font-family: 'Josefin Slab';
  font-style: normal;
  font-weight: 700;
  src: local('Josefin Slab Bold'), local('JosefinSlab-Bold'), url(https://fonts.gstatic.com/s/josefinslab/v10/lW-mwjwOK3Ps5GSJlNNkMalvESu6Kerl.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Jura';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/jura/v15/z7NbdRfiaC4VXclJURRD.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Jura';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/jura/v15/z7NbdRfiaC4VXcBJURRD.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Jura';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/jura/v15/z7NbdRfiaC4VXchJURRD.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Jura';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/jura/v15/z7NbdRfiaC4VXcdJURRD.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Jura';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/jura/v15/z7NbdRfiaC4VXctJURRD.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Jura';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/jura/v15/z7NbdRfiaC4VXcpJURRD.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Jura';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/jura/v15/z7NbdRfiaC4VXcRJUQ.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Jura';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/jura/v15/z7NbdRfiaC4VXclJURRD.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Jura';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/jura/v15/z7NbdRfiaC4VXcBJURRD.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Jura';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/jura/v15/z7NbdRfiaC4VXchJURRD.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Jura';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/jura/v15/z7NbdRfiaC4VXcdJURRD.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Jura';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/jura/v15/z7NbdRfiaC4VXctJURRD.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Jura';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/jura/v15/z7NbdRfiaC4VXcpJURRD.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Jura';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/jura/v15/z7NbdRfiaC4VXcRJUQ.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic */
@font-face {
  font-family: 'Kelly Slab';
  font-style: normal;
  font-weight: 400;
  src: local('Kelly Slab'), local('KellySlab-Regular'), url(https://fonts.gstatic.com/s/kellyslab/v11/-W_7XJX0Rz3cxUnJC5t6fkALfq0k.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* latin-ext */
@font-face {
  font-family: 'Kelly Slab';
  font-style: normal;
  font-weight: 400;
  src: local('Kelly Slab'), local('KellySlab-Regular'), url(https://fonts.gstatic.com/s/kellyslab/v11/-W_7XJX0Rz3cxUnJC5t6fkoLfq0k.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Kelly Slab';
  font-style: normal;
  font-weight: 400;
  src: local('Kelly Slab'), local('KellySlab-Regular'), url(https://fonts.gstatic.com/s/kellyslab/v11/-W_7XJX0Rz3cxUnJC5t6fkQLfg.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: italic;
  font-weight: 400;
  src: local('Lato Italic'), local('Lato-Italic'), url(https://fonts.gstatic.com/s/lato/v16/S6u8w4BMUTPHjxsAUi-qJCY.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: italic;
  font-weight: 400;
  src: local('Lato Italic'), local('Lato-Italic'), url(https://fonts.gstatic.com/s/lato/v16/S6u8w4BMUTPHjxsAXC-q.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: italic;
  font-weight: 700;
  src: local('Lato Bold Italic'), local('Lato-BoldItalic'), url(https://fonts.gstatic.com/s/lato/v16/S6u_w4BMUTPHjxsI5wq_FQft1dw.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: italic;
  font-weight: 700;
  src: local('Lato Bold Italic'), local('Lato-BoldItalic'), url(https://fonts.gstatic.com/s/lato/v16/S6u_w4BMUTPHjxsI5wq_Gwft.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 400;
  src: local('Lato Regular'), local('Lato-Regular'), url(https://fonts.gstatic.com/s/lato/v16/S6uyw4BMUTPHjxAwXjeu.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 400;
  src: local('Lato Regular'), local('Lato-Regular'), url(https://fonts.gstatic.com/s/lato/v16/S6uyw4BMUTPHjx4wXg.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 700;
  src: local('Lato Bold'), local('Lato-Bold'), url(https://fonts.gstatic.com/s/lato/v16/S6u9w4BMUTPHh6UVSwaPGR_p.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 700;
  src: local('Lato Bold'), local('Lato-Bold'), url(https://fonts.gstatic.com/s/lato/v16/S6u9w4BMUTPHh6UVSwiPGQ.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Libre Baskerville';
  font-style: italic;
  font-weight: 400;
  src: local('Libre Baskerville Italic'), local('LibreBaskerville-Italic'), url(https://fonts.gstatic.com/s/librebaskerville/v7/kmKhZrc3Hgbbcjq75U4uslyuy4kn0qNcWx8QDP2V.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Libre Baskerville';
  font-style: italic;
  font-weight: 400;
  src: local('Libre Baskerville Italic'), local('LibreBaskerville-Italic'), url(https://fonts.gstatic.com/s/librebaskerville/v7/kmKhZrc3Hgbbcjq75U4uslyuy4kn0qNcWxEQDA.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Libre Baskerville';
  font-style: normal;
  font-weight: 400;
  src: local('Libre Baskerville'), local('LibreBaskerville-Regular'), url(https://fonts.gstatic.com/s/librebaskerville/v7/kmKnZrc3Hgbbcjq75U4uslyuy4kn0qNXaxMICA.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Libre Baskerville';
  font-style: normal;
  font-weight: 400;
  src: local('Libre Baskerville'), local('LibreBaskerville-Regular'), url(https://fonts.gstatic.com/s/librebaskerville/v7/kmKnZrc3Hgbbcjq75U4uslyuy4kn0qNZaxM.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Libre Baskerville';
  font-style: normal;
  font-weight: 700;
  src: local('Libre Baskerville Bold'), local('LibreBaskerville-Bold'), url(https://fonts.gstatic.com/s/librebaskerville/v7/kmKiZrc3Hgbbcjq75U4uslyuy4kn0qviTgY5KcCsww.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Libre Baskerville';
  font-style: normal;
  font-weight: 700;
  src: local('Libre Baskerville Bold'), local('LibreBaskerville-Bold'), url(https://fonts.gstatic.com/s/librebaskerville/v7/kmKiZrc3Hgbbcjq75U4uslyuy4kn0qviTgY3KcA.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Lobster';
  font-style: normal;
  font-weight: 400;
  src: local('Lobster Regular'), local('Lobster-Regular'), url(https://fonts.gstatic.com/s/lobster/v22/neILzCirqoswsqX9zo-mM5Ez.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Lobster';
  font-style: normal;
  font-weight: 400;
  src: local('Lobster Regular'), local('Lobster-Regular'), url(https://fonts.gstatic.com/s/lobster/v22/neILzCirqoswsqX9zoamM5Ez.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Lobster';
  font-style: normal;
  font-weight: 400;
  src: local('Lobster Regular'), local('Lobster-Regular'), url(https://fonts.gstatic.com/s/lobster/v22/neILzCirqoswsqX9zo2mM5Ez.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Lobster';
  font-style: normal;
  font-weight: 400;
  src: local('Lobster Regular'), local('Lobster-Regular'), url(https://fonts.gstatic.com/s/lobster/v22/neILzCirqoswsqX9zoymM5Ez.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lobster';
  font-style: normal;
  font-weight: 400;
  src: local('Lobster Regular'), local('Lobster-Regular'), url(https://fonts.gstatic.com/s/lobster/v22/neILzCirqoswsqX9zoKmMw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic */
@font-face {
  font-family: 'Marck Script';
  font-style: normal;
  font-weight: 400;
  src: local('Marck Script'), local('MarckScript-Regular'), url(https://fonts.gstatic.com/s/marckscript/v10/nwpTtK2oNgBA3Or78gapdwuyzCg_WMM.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* latin-ext */
@font-face {
  font-family: 'Marck Script';
  font-style: normal;
  font-weight: 400;
  src: local('Marck Script'), local('MarckScript-Regular'), url(https://fonts.gstatic.com/s/marckscript/v10/nwpTtK2oNgBA3Or78gapdwuyxig_WMM.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Marck Script';
  font-style: normal;
  font-weight: 400;
  src: local('Marck Script'), local('MarckScript-Regular'), url(https://fonts.gstatic.com/s/marckscript/v10/nwpTtK2oNgBA3Or78gapdwuyyCg_.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin */
@font-face {
  font-family: 'Monoton';
  font-style: normal;
  font-weight: 400;
  src: local('Monoton'), local('Monoton-Regular'), url(https://fonts.gstatic.com/s/monoton/v9/5h1aiZUrOngCibe4TkHLQg.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Montserrat';
  font-style: italic;
  font-weight: 400;
  src: local('Montserrat Italic'), local('Montserrat-Italic'), url(https://fonts.gstatic.com/s/montserrat/v14/JTUQjIg1_i6t8kCHKm459WxRxC7mw9c.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Montserrat';
  font-style: italic;
  font-weight: 400;
  src: local('Montserrat Italic'), local('Montserrat-Italic'), url(https://fonts.gstatic.com/s/montserrat/v14/JTUQjIg1_i6t8kCHKm459WxRzS7mw9c.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Montserrat';
  font-style: italic;
  font-weight: 400;
  src: local('Montserrat Italic'), local('Montserrat-Italic'), url(https://fonts.gstatic.com/s/montserrat/v14/JTUQjIg1_i6t8kCHKm459WxRxi7mw9c.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Montserrat';
  font-style: italic;
  font-weight: 400;
  src: local('Montserrat Italic'), local('Montserrat-Italic'), url(https://fonts.gstatic.com/s/montserrat/v14/JTUQjIg1_i6t8kCHKm459WxRxy7mw9c.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Montserrat';
  font-style: italic;
  font-weight: 400;
  src: local('Montserrat Italic'), local('Montserrat-Italic'), url(https://fonts.gstatic.com/s/montserrat/v14/JTUQjIg1_i6t8kCHKm459WxRyS7m.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Montserrat';
  font-style: italic;
  font-weight: 700;
  src: local('Montserrat Bold Italic'), local('Montserrat-BoldItalic'), url(https://fonts.gstatic.com/s/montserrat/v14/JTUPjIg1_i6t8kCHKm459WxZcgvz8fZwnCo.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Montserrat';
  font-style: italic;
  font-weight: 700;
  src: local('Montserrat Bold Italic'), local('Montserrat-BoldItalic'), url(https://fonts.gstatic.com/s/montserrat/v14/JTUPjIg1_i6t8kCHKm459WxZcgvz-PZwnCo.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Montserrat';
  font-style: italic;
  font-weight: 700;
  src: local('Montserrat Bold Italic'), local('Montserrat-BoldItalic'), url(https://fonts.gstatic.com/s/montserrat/v14/JTUPjIg1_i6t8kCHKm459WxZcgvz8_ZwnCo.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Montserrat';
  font-style: italic;
  font-weight: 700;
  src: local('Montserrat Bold Italic'), local('Montserrat-BoldItalic'), url(https://fonts.gstatic.com/s/montserrat/v14/JTUPjIg1_i6t8kCHKm459WxZcgvz8vZwnCo.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Montserrat';
  font-style: italic;
  font-weight: 700;
  src: local('Montserrat Bold Italic'), local('Montserrat-BoldItalic'), url(https://fonts.gstatic.com/s/montserrat/v14/JTUPjIg1_i6t8kCHKm459WxZcgvz_PZw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  src: local('Montserrat Regular'), local('Montserrat-Regular'), url(https://fonts.gstatic.com/s/montserrat/v14/JTUSjIg1_i6t8kCHKm459WRhyzbi.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  src: local('Montserrat Regular'), local('Montserrat-Regular'), url(https://fonts.gstatic.com/s/montserrat/v14/JTUSjIg1_i6t8kCHKm459W1hyzbi.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  src: local('Montserrat Regular'), local('Montserrat-Regular'), url(https://fonts.gstatic.com/s/montserrat/v14/JTUSjIg1_i6t8kCHKm459WZhyzbi.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  src: local('Montserrat Regular'), local('Montserrat-Regular'), url(https://fonts.gstatic.com/s/montserrat/v14/JTUSjIg1_i6t8kCHKm459Wdhyzbi.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 400;
  src: local('Montserrat Regular'), local('Montserrat-Regular'), url(https://fonts.gstatic.com/s/montserrat/v14/JTUSjIg1_i6t8kCHKm459Wlhyw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 700;
  src: local('Montserrat Bold'), local('Montserrat-Bold'), url(https://fonts.gstatic.com/s/montserrat/v14/JTURjIg1_i6t8kCHKm45_dJE3gTD_u50.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 700;
  src: local('Montserrat Bold'), local('Montserrat-Bold'), url(https://fonts.gstatic.com/s/montserrat/v14/JTURjIg1_i6t8kCHKm45_dJE3g3D_u50.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 700;
  src: local('Montserrat Bold'), local('Montserrat-Bold'), url(https://fonts.gstatic.com/s/montserrat/v14/JTURjIg1_i6t8kCHKm45_dJE3gbD_u50.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 700;
  src: local('Montserrat Bold'), local('Montserrat-Bold'), url(https://fonts.gstatic.com/s/montserrat/v14/JTURjIg1_i6t8kCHKm45_dJE3gfD_u50.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 700;
  src: local('Montserrat Bold'), local('Montserrat-Bold'), url(https://fonts.gstatic.com/s/montserrat/v14/JTURjIg1_i6t8kCHKm45_dJE3gnD_g.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Mr De Haviland';
  font-style: normal;
  font-weight: 400;
  src: local('Mr De Haviland Regular'), local('MrDeHaviland-Regular'), url(https://fonts.gstatic.com/s/mrdehaviland/v9/OpNVnooIhJj96FdB73296ksbOg3L60PlNQ.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Mr De Haviland';
  font-style: normal;
  font-weight: 400;
  src: local('Mr De Haviland Regular'), local('MrDeHaviland-Regular'), url(https://fonts.gstatic.com/s/mrdehaviland/v9/OpNVnooIhJj96FdB73296ksbOg3F60M.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Niconne';
  font-style: normal;
  font-weight: 400;
  src: local('Niconne'), local('Niconne-Regular'), url(https://fonts.gstatic.com/s/niconne/v9/w8gaH2QvRug1_rTfnQKn2W4O.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Niconne';
  font-style: normal;
  font-weight: 400;
  src: local('Niconne'), local('Niconne-Regular'), url(https://fonts.gstatic.com/s/niconne/v9/w8gaH2QvRug1_rTfnQyn2Q.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Noticia Text';
  font-style: italic;
  font-weight: 400;
  src: local('Noticia Text Italic'), local('NoticiaText-Italic'), url(https://fonts.gstatic.com/s/noticiatext/v9/VuJodNDF2Yv9qppOePKYRP12YwtVn07tpQ.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Noticia Text';
  font-style: italic;
  font-weight: 400;
  src: local('Noticia Text Italic'), local('NoticiaText-Italic'), url(https://fonts.gstatic.com/s/noticiatext/v9/VuJodNDF2Yv9qppOePKYRP12YwtUn07tpQ.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Noticia Text';
  font-style: italic;
  font-weight: 400;
  src: local('Noticia Text Italic'), local('NoticiaText-Italic'), url(https://fonts.gstatic.com/s/noticiatext/v9/VuJodNDF2Yv9qppOePKYRP12Ywtan04.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Noticia Text';
  font-style: italic;
  font-weight: 700;
  src: local('Noticia Text Bold Italic'), local('NoticiaText-BoldItalic'), url(https://fonts.gstatic.com/s/noticiatext/v9/VuJrdNDF2Yv9qppOePKYRP12YwPhulvdhDXUeA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Noticia Text';
  font-style: italic;
  font-weight: 700;
  src: local('Noticia Text Bold Italic'), local('NoticiaText-BoldItalic'), url(https://fonts.gstatic.com/s/noticiatext/v9/VuJrdNDF2Yv9qppOePKYRP12YwPhulvchDXUeA.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Noticia Text';
  font-style: italic;
  font-weight: 700;
  src: local('Noticia Text Bold Italic'), local('NoticiaText-BoldItalic'), url(https://fonts.gstatic.com/s/noticiatext/v9/VuJrdNDF2Yv9qppOePKYRP12YwPhulvShDU.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Noticia Text';
  font-style: normal;
  font-weight: 400;
  src: local('Noticia Text'), local('NoticiaText-Regular'), url(https://fonts.gstatic.com/s/noticiatext/v9/VuJ2dNDF2Yv9qppOePKYRP12aTtYh0o.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Noticia Text';
  font-style: normal;
  font-weight: 400;
  src: local('Noticia Text'), local('NoticiaText-Regular'), url(https://fonts.gstatic.com/s/noticiatext/v9/VuJ2dNDF2Yv9qppOePKYRP12aDtYh0o.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Noticia Text';
  font-style: normal;
  font-weight: 400;
  src: local('Noticia Text'), local('NoticiaText-Regular'), url(https://fonts.gstatic.com/s/noticiatext/v9/VuJ2dNDF2Yv9qppOePKYRP12ZjtY.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Noticia Text';
  font-style: normal;
  font-weight: 700;
  src: local('Noticia Text Bold'), local('NoticiaText-Bold'), url(https://fonts.gstatic.com/s/noticiatext/v9/VuJpdNDF2Yv9qppOePKYRP1-3R5Nt2vQnDE.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Noticia Text';
  font-style: normal;
  font-weight: 700;
  src: local('Noticia Text Bold'), local('NoticiaText-Bold'), url(https://fonts.gstatic.com/s/noticiatext/v9/VuJpdNDF2Yv9qppOePKYRP1-3R5NtmvQnDE.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Noticia Text';
  font-style: normal;
  font-weight: 700;
  src: local('Noticia Text Bold'), local('NoticiaText-Bold'), url(https://fonts.gstatic.com/s/noticiatext/v9/VuJpdNDF2Yv9qppOePKYRP1-3R5NuGvQ.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Open Sans Condensed';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Condensed Light'), local('OpenSansCondensed-Light'), url(https://fonts.gstatic.com/s/opensanscondensed/v14/z7NFdQDnbTkabZAIOl9il_O6KJj73e7Ff1GhDujMR6WR.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Open Sans Condensed';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Condensed Light'), local('OpenSansCondensed-Light'), url(https://fonts.gstatic.com/s/opensanscondensed/v14/z7NFdQDnbTkabZAIOl9il_O6KJj73e7Ff1GhDuHMR6WR.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Open Sans Condensed';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Condensed Light'), local('OpenSansCondensed-Light'), url(https://fonts.gstatic.com/s/opensanscondensed/v14/z7NFdQDnbTkabZAIOl9il_O6KJj73e7Ff1GhDunMR6WR.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Open Sans Condensed';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Condensed Light'), local('OpenSansCondensed-Light'), url(https://fonts.gstatic.com/s/opensanscondensed/v14/z7NFdQDnbTkabZAIOl9il_O6KJj73e7Ff1GhDubMR6WR.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Open Sans Condensed';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Condensed Light'), local('OpenSansCondensed-Light'), url(https://fonts.gstatic.com/s/opensanscondensed/v14/z7NFdQDnbTkabZAIOl9il_O6KJj73e7Ff1GhDurMR6WR.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Open Sans Condensed';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Condensed Light'), local('OpenSansCondensed-Light'), url(https://fonts.gstatic.com/s/opensanscondensed/v14/z7NFdQDnbTkabZAIOl9il_O6KJj73e7Ff1GhDuvMR6WR.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Open Sans Condensed';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Condensed Light'), local('OpenSansCondensed-Light'), url(https://fonts.gstatic.com/s/opensanscondensed/v14/z7NFdQDnbTkabZAIOl9il_O6KJj73e7Ff1GhDuXMRw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Open Sans Condensed';
  font-style: normal;
  font-weight: 700;
  src: local('Open Sans Condensed Bold'), local('OpenSansCondensed-Bold'), url(https://fonts.gstatic.com/s/opensanscondensed/v14/z7NFdQDnbTkabZAIOl9il_O6KJj73e7Ff0GmDujMR6WR.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Open Sans Condensed';
  font-style: normal;
  font-weight: 700;
  src: local('Open Sans Condensed Bold'), local('OpenSansCondensed-Bold'), url(https://fonts.gstatic.com/s/opensanscondensed/v14/z7NFdQDnbTkabZAIOl9il_O6KJj73e7Ff0GmDuHMR6WR.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Open Sans Condensed';
  font-style: normal;
  font-weight: 700;
  src: local('Open Sans Condensed Bold'), local('OpenSansCondensed-Bold'), url(https://fonts.gstatic.com/s/opensanscondensed/v14/z7NFdQDnbTkabZAIOl9il_O6KJj73e7Ff0GmDunMR6WR.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Open Sans Condensed';
  font-style: normal;
  font-weight: 700;
  src: local('Open Sans Condensed Bold'), local('OpenSansCondensed-Bold'), url(https://fonts.gstatic.com/s/opensanscondensed/v14/z7NFdQDnbTkabZAIOl9il_O6KJj73e7Ff0GmDubMR6WR.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Open Sans Condensed';
  font-style: normal;
  font-weight: 700;
  src: local('Open Sans Condensed Bold'), local('OpenSansCondensed-Bold'), url(https://fonts.gstatic.com/s/opensanscondensed/v14/z7NFdQDnbTkabZAIOl9il_O6KJj73e7Ff0GmDurMR6WR.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Open Sans Condensed';
  font-style: normal;
  font-weight: 700;
  src: local('Open Sans Condensed Bold'), local('OpenSansCondensed-Bold'), url(https://fonts.gstatic.com/s/opensanscondensed/v14/z7NFdQDnbTkabZAIOl9il_O6KJj73e7Ff0GmDuvMR6WR.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Open Sans Condensed';
  font-style: normal;
  font-weight: 700;
  src: local('Open Sans Condensed Bold'), local('OpenSansCondensed-Bold'), url(https://fonts.gstatic.com/s/opensanscondensed/v14/z7NFdQDnbTkabZAIOl9il_O6KJj73e7Ff0GmDuXMRw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Oswald';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/oswald/v35/TK3iWkUHHAIjg752FD8Ghe4.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Oswald';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/oswald/v35/TK3iWkUHHAIjg752HT8Ghe4.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Oswald';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/oswald/v35/TK3iWkUHHAIjg752Fj8Ghe4.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Oswald';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/oswald/v35/TK3iWkUHHAIjg752Fz8Ghe4.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Oswald';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/oswald/v35/TK3iWkUHHAIjg752GT8G.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Oswald';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/oswald/v35/TK3iWkUHHAIjg752FD8Ghe4.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Oswald';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/oswald/v35/TK3iWkUHHAIjg752HT8Ghe4.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Oswald';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/oswald/v35/TK3iWkUHHAIjg752Fj8Ghe4.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Oswald';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/oswald/v35/TK3iWkUHHAIjg752Fz8Ghe4.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Oswald';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/oswald/v35/TK3iWkUHHAIjg752GT8G.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Overlock';
  font-style: italic;
  font-weight: 400;
  src: local('Overlock Italic'), local('Overlock-Italic'), url(https://fonts.gstatic.com/s/overlock/v9/Z9XTDmdMWRiN1_T9Z7Tc2OCsk4GC.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Overlock';
  font-style: italic;
  font-weight: 400;
  src: local('Overlock Italic'), local('Overlock-Italic'), url(https://fonts.gstatic.com/s/overlock/v9/Z9XTDmdMWRiN1_T9Z7Tc2O6skw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Overlock';
  font-style: italic;
  font-weight: 700;
  src: local('Overlock Bold Italic'), local('Overlock-BoldItalic'), url(https://fonts.gstatic.com/s/overlock/v9/Z9XQDmdMWRiN1_T9Z7Tc0FWJhrCj8RLT.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Overlock';
  font-style: italic;
  font-weight: 700;
  src: local('Overlock Bold Italic'), local('Overlock-BoldItalic'), url(https://fonts.gstatic.com/s/overlock/v9/Z9XQDmdMWRiN1_T9Z7Tc0FWJhr6j8Q.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Overlock';
  font-style: normal;
  font-weight: 400;
  src: local('Overlock Regular'), local('Overlock-Regular'), url(https://fonts.gstatic.com/s/overlock/v9/Z9XVDmdMWRiN1_T9Z7TX6Oy0lw.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Overlock';
  font-style: normal;
  font-weight: 400;
  src: local('Overlock Regular'), local('Overlock-Regular'), url(https://fonts.gstatic.com/s/overlock/v9/Z9XVDmdMWRiN1_T9Z7TZ6Ow.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Overlock';
  font-style: normal;
  font-weight: 700;
  src: local('Overlock Bold'), local('Overlock-Bold'), url(https://fonts.gstatic.com/s/overlock/v9/Z9XSDmdMWRiN1_T9Z7xizfmFtry79Q.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Overlock';
  font-style: normal;
  font-weight: 700;
  src: local('Overlock Bold'), local('Overlock-Bold'), url(https://fonts.gstatic.com/s/overlock/v9/Z9XSDmdMWRiN1_T9Z7xizfmLtrw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Patrick Hand';
  font-style: normal;
  font-weight: 400;
  src: local('Patrick Hand'), local('PatrickHand-Regular'), url(https://fonts.gstatic.com/s/patrickhand/v13/LDI1apSQOAYtSuYWp8ZhfYe8UcLLq7s.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Patrick Hand';
  font-style: normal;
  font-weight: 400;
  src: local('Patrick Hand'), local('PatrickHand-Regular'), url(https://fonts.gstatic.com/s/patrickhand/v13/LDI1apSQOAYtSuYWp8ZhfYe8UMLLq7s.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Patrick Hand';
  font-style: normal;
  font-weight: 400;
  src: local('Patrick Hand'), local('PatrickHand-Regular'), url(https://fonts.gstatic.com/s/patrickhand/v13/LDI1apSQOAYtSuYWp8ZhfYe8XsLL.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Play';
  font-style: normal;
  font-weight: 400;
  src: local('Play Regular'), local('Play-Regular'), url(https://fonts.gstatic.com/s/play/v11/6aez4K2oVqwIvtg2H68T.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Play';
  font-style: normal;
  font-weight: 400;
  src: local('Play Regular'), local('Play-Regular'), url(https://fonts.gstatic.com/s/play/v11/6aez4K2oVqwIvtE2H68T.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek */
@font-face {
  font-family: 'Play';
  font-style: normal;
  font-weight: 400;
  src: local('Play Regular'), local('Play-Regular'), url(https://fonts.gstatic.com/s/play/v11/6aez4K2oVqwIvtY2H68T.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Play';
  font-style: normal;
  font-weight: 400;
  src: local('Play Regular'), local('Play-Regular'), url(https://fonts.gstatic.com/s/play/v11/6aez4K2oVqwIvto2H68T.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Play';
  font-style: normal;
  font-weight: 400;
  src: local('Play Regular'), local('Play-Regular'), url(https://fonts.gstatic.com/s/play/v11/6aez4K2oVqwIvts2H68T.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Play';
  font-style: normal;
  font-weight: 400;
  src: local('Play Regular'), local('Play-Regular'), url(https://fonts.gstatic.com/s/play/v11/6aez4K2oVqwIvtU2Hw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Play';
  font-style: normal;
  font-weight: 700;
  src: local('Play Bold'), local('Play-Bold'), url(https://fonts.gstatic.com/s/play/v11/6ae84K2oVqwItm4TCp0y2knT.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Play';
  font-style: normal;
  font-weight: 700;
  src: local('Play Bold'), local('Play-Bold'), url(https://fonts.gstatic.com/s/play/v11/6ae84K2oVqwItm4TCpQy2knT.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek */
@font-face {
  font-family: 'Play';
  font-style: normal;
  font-weight: 700;
  src: local('Play Bold'), local('Play-Bold'), url(https://fonts.gstatic.com/s/play/v11/6ae84K2oVqwItm4TCpMy2knT.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Play';
  font-style: normal;
  font-weight: 700;
  src: local('Play Bold'), local('Play-Bold'), url(https://fonts.gstatic.com/s/play/v11/6ae84K2oVqwItm4TCp8y2knT.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Play';
  font-style: normal;
  font-weight: 700;
  src: local('Play Bold'), local('Play-Bold'), url(https://fonts.gstatic.com/s/play/v11/6ae84K2oVqwItm4TCp4y2knT.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Play';
  font-style: normal;
  font-weight: 700;
  src: local('Play Bold'), local('Play-Bold'), url(https://fonts.gstatic.com/s/play/v11/6ae84K2oVqwItm4TCpAy2g.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic */
@font-face {
  font-family: 'Playfair Display';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFkD-vYSZviVYUb_rj3ij__anPXDTnohkk72xU.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Playfair Display';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFkD-vYSZviVYUb_rj3ij__anPXDTnojUk72xU.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Playfair Display';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFkD-vYSZviVYUb_rj3ij__anPXDTnojEk72xU.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Playfair Display';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFkD-vYSZviVYUb_rj3ij__anPXDTnogkk7.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic */
@font-face {
  font-family: 'Playfair Display';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFkD-vYSZviVYUb_rj3ij__anPXDTnohkk72xU.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Playfair Display';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFkD-vYSZviVYUb_rj3ij__anPXDTnojUk72xU.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Playfair Display';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFkD-vYSZviVYUb_rj3ij__anPXDTnojEk72xU.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Playfair Display';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFkD-vYSZviVYUb_rj3ij__anPXDTnogkk7.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic */
@font-face {
  font-family: 'Playfair Display';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFiD-vYSZviVYUb_rj3ij__anPXDTjYgFE_.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Playfair Display';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFiD-vYSZviVYUb_rj3ij__anPXDTPYgFE_.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Playfair Display';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFiD-vYSZviVYUb_rj3ij__anPXDTLYgFE_.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Playfair Display';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFiD-vYSZviVYUb_rj3ij__anPXDTzYgA.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic */
@font-face {
  font-family: 'Playfair Display';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFiD-vYSZviVYUb_rj3ij__anPXDTjYgFE_.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Playfair Display';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFiD-vYSZviVYUb_rj3ij__anPXDTPYgFE_.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Playfair Display';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFiD-vYSZviVYUb_rj3ij__anPXDTLYgFE_.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Playfair Display';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/playfairdisplay/v21/nuFiD-vYSZviVYUb_rj3ij__anPXDTzYgA.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* devanagari */
@font-face {
  font-family: 'Poppins';
  font-style: italic;
  font-weight: 400;
  src: local('Poppins Italic'), local('Poppins-Italic'), url(https://fonts.gstatic.com/s/poppins/v12/pxiGyp8kv8JHgFVrJJLucXtAKPY.woff2) format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Poppins';
  font-style: italic;
  font-weight: 400;
  src: local('Poppins Italic'), local('Poppins-Italic'), url(https://fonts.gstatic.com/s/poppins/v12/pxiGyp8kv8JHgFVrJJLufntAKPY.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Poppins';
  font-style: italic;
  font-weight: 400;
  src: local('Poppins Italic'), local('Poppins-Italic'), url(https://fonts.gstatic.com/s/poppins/v12/pxiGyp8kv8JHgFVrJJLucHtA.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* devanagari */
@font-face {
  font-family: 'Poppins';
  font-style: italic;
  font-weight: 700;
  src: local('Poppins Bold Italic'), local('Poppins-BoldItalic'), url(https://fonts.gstatic.com/s/poppins/v12/pxiDyp8kv8JHgFVrJJLmy15VFteOcEg.woff2) format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Poppins';
  font-style: italic;
  font-weight: 700;
  src: local('Poppins Bold Italic'), local('Poppins-BoldItalic'), url(https://fonts.gstatic.com/s/poppins/v12/pxiDyp8kv8JHgFVrJJLmy15VGdeOcEg.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Poppins';
  font-style: italic;
  font-weight: 700;
  src: local('Poppins Bold Italic'), local('Poppins-BoldItalic'), url(https://fonts.gstatic.com/s/poppins/v12/pxiDyp8kv8JHgFVrJJLmy15VF9eO.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* devanagari */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v12/pxiEyp8kv8JHgFVrJJbecmNE.woff2) format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v12/pxiEyp8kv8JHgFVrJJnecmNE.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 400;
  src: local('Poppins Regular'), local('Poppins-Regular'), url(https://fonts.gstatic.com/s/poppins/v12/pxiEyp8kv8JHgFVrJJfecg.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* devanagari */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 700;
  src: local('Poppins Bold'), local('Poppins-Bold'), url(https://fonts.gstatic.com/s/poppins/v12/pxiByp8kv8JHgFVrLCz7Z11lFc-K.woff2) format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 700;
  src: local('Poppins Bold'), local('Poppins-Bold'), url(https://fonts.gstatic.com/s/poppins/v12/pxiByp8kv8JHgFVrLCz7Z1JlFc-K.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Poppins';
  font-style: normal;
  font-weight: 700;
  src: local('Poppins Bold'), local('Poppins-Bold'), url(https://fonts.gstatic.com/s/poppins/v12/pxiByp8kv8JHgFVrLCz7Z1xlFQ.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Questrial';
  font-style: normal;
  font-weight: 400;
  src: local('Questrial Regular'), local('Questrial-Regular'), url(https://fonts.gstatic.com/s/questrial/v10/QdVUSTchPBm7nuUeVf70sSFlq20.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Questrial';
  font-style: normal;
  font-weight: 400;
  src: local('Questrial Regular'), local('Questrial-Regular'), url(https://fonts.gstatic.com/s/questrial/v10/QdVUSTchPBm7nuUeVf70sCFlq20.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Questrial';
  font-style: normal;
  font-weight: 400;
  src: local('Questrial Regular'), local('Questrial-Regular'), url(https://fonts.gstatic.com/s/questrial/v10/QdVUSTchPBm7nuUeVf70viFl.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Raleway';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptsg8zYS_SKggPNyCg4QIFqPfE.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Raleway';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptsg8zYS_SKggPNyCg4SYFqPfE.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Raleway';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptsg8zYS_SKggPNyCg4QoFqPfE.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Raleway';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptsg8zYS_SKggPNyCg4Q4FqPfE.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Raleway';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptsg8zYS_SKggPNyCg4TYFq.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Raleway';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptsg8zYS_SKggPNyCg4QIFqPfE.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Raleway';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptsg8zYS_SKggPNyCg4SYFqPfE.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Raleway';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptsg8zYS_SKggPNyCg4QoFqPfE.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Raleway';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptsg8zYS_SKggPNyCg4Q4FqPfE.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Raleway';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptsg8zYS_SKggPNyCg4TYFq.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Raleway';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptug8zYS_SKggPNyCAIT5lu.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Raleway';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptug8zYS_SKggPNyCkIT5lu.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Raleway';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptug8zYS_SKggPNyCIIT5lu.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Raleway';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptug8zYS_SKggPNyCMIT5lu.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Raleway';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptug8zYS_SKggPNyC0ITw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Raleway';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptug8zYS_SKggPNyCAIT5lu.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Raleway';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptug8zYS_SKggPNyCkIT5lu.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Raleway';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptug8zYS_SKggPNyCIIT5lu.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Raleway';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptug8zYS_SKggPNyCMIT5lu.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Raleway';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/raleway/v17/1Ptug8zYS_SKggPNyC0ITw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  src: local('Roboto Italic'), local('Roboto-Italic'), url(https://fonts.gstatic.com/s/roboto/v20/KFOkCnqEu92Fr1Mu51xFIzIFKw.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  src: local('Roboto Italic'), local('Roboto-Italic'), url(https://fonts.gstatic.com/s/roboto/v20/KFOkCnqEu92Fr1Mu51xMIzIFKw.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  src: local('Roboto Italic'), local('Roboto-Italic'), url(https://fonts.gstatic.com/s/roboto/v20/KFOkCnqEu92Fr1Mu51xEIzIFKw.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  src: local('Roboto Italic'), local('Roboto-Italic'), url(https://fonts.gstatic.com/s/roboto/v20/KFOkCnqEu92Fr1Mu51xLIzIFKw.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  src: local('Roboto Italic'), local('Roboto-Italic'), url(https://fonts.gstatic.com/s/roboto/v20/KFOkCnqEu92Fr1Mu51xHIzIFKw.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  src: local('Roboto Italic'), local('Roboto-Italic'), url(https://fonts.gstatic.com/s/roboto/v20/KFOkCnqEu92Fr1Mu51xGIzIFKw.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  src: local('Roboto Italic'), local('Roboto-Italic'), url(https://fonts.gstatic.com/s/roboto/v20/KFOkCnqEu92Fr1Mu51xIIzI.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  src: local('Roboto Bold Italic'), local('Roboto-BoldItalic'), url(https://fonts.gstatic.com/s/roboto/v20/KFOjCnqEu92Fr1Mu51TzBic3CsTKlA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  src: local('Roboto Bold Italic'), local('Roboto-BoldItalic'), url(https://fonts.gstatic.com/s/roboto/v20/KFOjCnqEu92Fr1Mu51TzBic-CsTKlA.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  src: local('Roboto Bold Italic'), local('Roboto-BoldItalic'), url(https://fonts.gstatic.com/s/roboto/v20/KFOjCnqEu92Fr1Mu51TzBic2CsTKlA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  src: local('Roboto Bold Italic'), local('Roboto-BoldItalic'), url(https://fonts.gstatic.com/s/roboto/v20/KFOjCnqEu92Fr1Mu51TzBic5CsTKlA.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  src: local('Roboto Bold Italic'), local('Roboto-BoldItalic'), url(https://fonts.gstatic.com/s/roboto/v20/KFOjCnqEu92Fr1Mu51TzBic1CsTKlA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  src: local('Roboto Bold Italic'), local('Roboto-BoldItalic'), url(https://fonts.gstatic.com/s/roboto/v20/KFOjCnqEu92Fr1Mu51TzBic0CsTKlA.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  src: local('Roboto Bold Italic'), local('Roboto-BoldItalic'), url(https://fonts.gstatic.com/s/roboto/v20/KFOjCnqEu92Fr1Mu51TzBic6CsQ.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: local('Roboto'), local('Roboto-Regular'), url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu72xKOzY.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: local('Roboto'), local('Roboto-Regular'), url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu5mxKOzY.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: local('Roboto'), local('Roboto-Regular'), url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu7mxKOzY.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: local('Roboto'), local('Roboto-Regular'), url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu4WxKOzY.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: local('Roboto'), local('Roboto-Regular'), url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu7WxKOzY.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: local('Roboto'), local('Roboto-Regular'), url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu7GxKOzY.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  src: local('Roboto'), local('Roboto-Regular'), url(https://fonts.gstatic.com/s/roboto/v20/KFOmCnqEu92Fr1Mu4mxK.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: local('Roboto Bold'), local('Roboto-Bold'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfCRc4EsA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: local('Roboto Bold'), local('Roboto-Bold'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfABc4EsA.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: local('Roboto Bold'), local('Roboto-Bold'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfCBc4EsA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: local('Roboto Bold'), local('Roboto-Bold'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfBxc4EsA.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: local('Roboto Bold'), local('Roboto-Bold'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfCxc4EsA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: local('Roboto Bold'), local('Roboto-Bold'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfChc4EsA.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  src: local('Roboto Bold'), local('Roboto-Bold'), url(https://fonts.gstatic.com/s/roboto/v20/KFOlCnqEu92Fr1MmWUlfBBc4.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* devanagari */
@font-face {
  font-family: 'Rozha One';
  font-style: normal;
  font-weight: 400;
  src: local('Rozha One Regular'), local('RozhaOne-Regular'), url(https://fonts.gstatic.com/s/rozhaone/v7/AlZy_zVFtYP12Zncg2kRc335bB0.woff2) format('woff2');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Rozha One';
  font-style: normal;
  font-weight: 400;
  src: local('Rozha One Regular'), local('RozhaOne-Regular'), url(https://fonts.gstatic.com/s/rozhaone/v7/AlZy_zVFtYP12Zncg2kRfH35bB0.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Rozha One';
  font-style: normal;
  font-weight: 400;
  src: local('Rozha One Regular'), local('RozhaOne-Regular'), url(https://fonts.gstatic.com/s/rozhaone/v7/AlZy_zVFtYP12Zncg2kRcn35.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Sacramento';
  font-style: normal;
  font-weight: 400;
  src: local('Sacramento'), local('Sacramento-Regular'), url(https://fonts.gstatic.com/s/sacramento/v7/buEzpo6gcdjy0EiZMBUG4CMf_exL.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Sacramento';
  font-style: normal;
  font-weight: 400;
  src: local('Sacramento'), local('Sacramento-Regular'), url(https://fonts.gstatic.com/s/sacramento/v7/buEzpo6gcdjy0EiZMBUG4C0f_Q.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Sail';
  font-style: normal;
  font-weight: 400;
  src: local('Sail'), local('Sail-Regular'), url(https://fonts.gstatic.com/s/sail/v11/DPEjYwiBxwYJJB3JAQYA.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Sail';
  font-style: normal;
  font-weight: 400;
  src: local('Sail'), local('Sail-Regular'), url(https://fonts.gstatic.com/s/sail/v11/DPEjYwiBxwYJJBPJAQ.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Sarina';
  font-style: normal;
  font-weight: 400;
  src: local('Sarina'), local('Sarina-Regular'), url(https://fonts.gstatic.com/s/sarina/v9/-F6wfjF3ITQwasLRJ0rVniA.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Sarina';
  font-style: normal;
  font-weight: 400;
  src: local('Sarina'), local('Sarina-Regular'), url(https://fonts.gstatic.com/s/sarina/v9/-F6wfjF3ITQwasLRKUrV.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Signika';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/signika/v11/vEFR2_JTCgwQ5ejvG14mBkho.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Signika';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/signika/v11/vEFR2_JTCgwQ5ejvG18mBkho.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Signika';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/signika/v11/vEFR2_JTCgwQ5ejvG1EmBg.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Signika';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/signika/v11/vEFR2_JTCgwQ5ejvG14mBkho.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Signika';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/signika/v11/vEFR2_JTCgwQ5ejvG18mBkho.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Signika';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/signika/v11/vEFR2_JTCgwQ5ejvG1EmBg.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Spinnaker';
  font-style: normal;
  font-weight: 400;
  src: local('Spinnaker'), local('Spinnaker-Regular'), url(https://fonts.gstatic.com/s/spinnaker/v11/w8gYH2oyX-I0_rvR6HmX1XYKmOo.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Spinnaker';
  font-style: normal;
  font-weight: 400;
  src: local('Spinnaker'), local('Spinnaker-Regular'), url(https://fonts.gstatic.com/s/spinnaker/v11/w8gYH2oyX-I0_rvR6HmX23YK.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* hebrew */
@font-face {
  font-family: 'Suez One';
  font-style: normal;
  font-weight: 400;
  src: local('Suez One'), local('SuezOne-Regular'), url(https://fonts.gstatic.com/s/suezone/v4/taiJGmd_EZ6rqscQgOFMmouQ-A.woff2) format('woff2');
  unicode-range: U+0590-05FF, U+20AA, U+25CC, U+FB1D-FB4F;
}
/* latin-ext */
@font-face {
  font-family: 'Suez One';
  font-style: normal;
  font-weight: 400;
  src: local('Suez One'), local('SuezOne-Regular'), url(https://fonts.gstatic.com/s/suezone/v4/taiJGmd_EZ6rqscQgOFAmouQ-A.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Suez One';
  font-style: normal;
  font-weight: 400;
  src: local('Suez One'), local('SuezOne-Regular'), url(https://fonts.gstatic.com/s/suezone/v4/taiJGmd_EZ6rqscQgOFOmos.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Work Sans';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/worksans/v8/QGYqz_wNahGAdqQ43Rh_eZDkv_1w4A.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Work Sans';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/worksans/v8/QGYqz_wNahGAdqQ43Rh_eZDlv_1w4A.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Work Sans';
  font-style: italic;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/worksans/v8/QGYqz_wNahGAdqQ43Rh_eZDrv_0.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Work Sans';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/worksans/v8/QGYqz_wNahGAdqQ43Rh_eZDkv_1w4A.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Work Sans';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/worksans/v8/QGYqz_wNahGAdqQ43Rh_eZDlv_1w4A.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Work Sans';
  font-style: italic;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/worksans/v8/QGYqz_wNahGAdqQ43Rh_eZDrv_0.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Work Sans';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/worksans/v8/QGYsz_wNahGAdqQ43Rh_c6Dpp_k.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Work Sans';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/worksans/v8/QGYsz_wNahGAdqQ43Rh_cqDpp_k.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Work Sans';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/worksans/v8/QGYsz_wNahGAdqQ43Rh_fKDp.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Work Sans';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/worksans/v8/QGYsz_wNahGAdqQ43Rh_c6Dpp_k.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Work Sans';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/worksans/v8/QGYsz_wNahGAdqQ43Rh_cqDpp_k.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Work Sans';
  font-style: normal;
  font-weight: 700;
  src: url(https://fonts.gstatic.com/s/worksans/v8/QGYsz_wNahGAdqQ43Rh_fKDp.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}

                </style>
            
    

    

    
        
            
            
                <script>
                    try {
                        window.precreatedBoltWorker = new Worker("/_partials/wix-bolt/1.6455.0/node_modules/viewer-platform-worker/dist/bolt-worker.js");
                    } catch (e) {}
                </script>
            
        
        <link rel="preconnect" href="https://siteassets.parastorage.com/pages/singlePage/viewerViewModeJson" crossorigin>
    

    
        <script async id="wix-perf-measure" onload="typeof requirejs === 'function' && requirejs(['wix-perf-measure'], function() {})"
            src="https://static.parastorage.com/services/wix-perf-measure/1.178.0/wix-perf-measure.bundle.min.js"></script>
    

    

    


    


        
                


    
        
            <title>Início | Todo Negócio AKI Pertinho</title>
        
            <meta name="description" content="Um portal que se destina a prestação de serviços de divulgação, anúncios exclusivos para empresas que querem anunciar seus produtos e serviços."/>
        
            <link rel="canonical" href="https://igrejaevredencao74.wixsite.com/akipertinho"/>
        
            <meta property="og:title" content="Início | Todo Negócio AKI Pertinho"/>
        
            <meta property="og:description" content="Um portal que se destina a prestação de serviços de divulgação, anúncios exclusivos para empresas que querem anunciar seus produtos e serviços."/>
        
            <meta property="og:url" content="https://igrejaevredencao74.wixsite.com/akipertinho"/>
        
            <meta property="og:site_name" content="Todo Negócio AKI Per"/>
        
            <meta property="og:type" content="website"/>
        
            <meta name="keywords" content="Aqui perto, pertinho, perto, produtos, regi&amp;atilde;o, todo neg&amp;oacute;cio"/>
        
    

    



        

        </head>

            
                <body class="prewarmup">
            

    


    

    <script type="text/javascript">
          
              var htmlClassList = document.documentElement.classList;
              
          

      
      var bodyCacheable = true;
      wixBiSession.setCaching(bodyCacheable);

      var clientSideRender = false;
      
      
      
    </script>

    
    
    
    <!--body start html embeds start-->
    
    <!--body start html embeds end-->
    
    

    
    <script id="wix-first-paint">
        if (window.ResizeObserver &&
            (!window.PerformanceObserver || !PerformanceObserver.supportedEntryTypes || PerformanceObserver.supportedEntryTypes.indexOf('paint') === -1)) {
            new ResizeObserver(function (entries, observer) {
                entries.some(function (entry) {
                    var contentRect = entry.contentRect;
                    if (contentRect.width > 0 && contentRect.height > 0) {
                        requestAnimationFrame(function (now) {
                            window.wixFirstPaint = now;
                            dispatchEvent(new CustomEvent('wixFirstPaint'));
                        });
                        observer.disconnect();
                        return true;
                    }
                });
            }).observe(document.body);
        }
    </script>
    


    <div id="SITE_CONTAINER"><style type="text/css" data-styleid="uploadedFonts"></style><div><style type="text/css" data-styleid="theme_fonts">.font_0 {font: normal normal normal 22px/1.41em raleway,sans-serif ;color:#181818;} 
.font_1 {font: normal normal normal 14px/1.79em raleway,sans-serif ;color:#181818;} 
.font_2 {font: normal normal normal 28px/1.375em avenir-lt-w01_85-heavy1475544,sans-serif ;color:#181818;} 
.font_3 {font: normal normal normal 88px/1.2em avenir-lt-w01_85-heavy1475544,sans-serif ;color:#181818;} 
.font_4 {font: normal normal normal 72px/1.25em avenir-lt-w01_85-heavy1475544,sans-serif ;color:#181818;} 
.font_5 {font: normal normal normal 50px/1.34em avenir-lt-w01_85-heavy1475544,sans-serif ;color:#181818;} 
.font_6 {font: normal normal normal 40px/1.35em avenir-lt-w01_85-heavy1475544,sans-serif ;color:#181818;} 
.font_7 {font: normal normal normal 20px/1.67em raleway,sans-serif ;color:#181818;} 
.font_8 {font: normal normal normal 18px/1.75em raleway,sans-serif ;color:#181818;} 
.font_9 {font: normal normal normal 15px/1.875em raleway,sans-serif ;color:#181818;} 
.font_10 {font: normal normal normal 14px/1.79em raleway,sans-serif ;color:#181818;} 
</style><style type="text/css" data-styleid="theme_colors">.color_0 {color: #ffffff;}
.backcolor_0 {background-color: #ffffff;}
.color_1 {color: #181818;}
.backcolor_1 {background-color: #181818;}
.color_2 {color: #4855B1;}
.backcolor_2 {background-color: #4855B1;}
.color_3 {color: #222222;}
.backcolor_3 {background-color: #222222;}
.color_4 {color: #f5f5f3;}
.backcolor_4 {background-color: #f5f5f3;}
.color_5 {color: #E3D83E;}
.backcolor_5 {background-color: #E3D83E;}
.color_6 {color: #FFFFFF;}
.backcolor_6 {background-color: #FFFFFF;}
.color_7 {color: #c5c5c5;}
.backcolor_7 {background-color: #c5c5c5;}
.color_8 {color: #8c8c8c;}
.backcolor_8 {background-color: #8c8c8c;}
.color_9 {color: #525252;}
.backcolor_9 {background-color: #525252;}
.color_10 {color: #181818;}
.backcolor_10 {background-color: #181818;}
.color_11 {color: #FFFFFF;}
.backcolor_11 {background-color: #FFFFFF;}
.color_12 {color: #c5c5c5;}
.backcolor_12 {background-color: #c5c5c5;}
.color_13 {color: #8c8c8c;}
.backcolor_13 {background-color: #8c8c8c;}
.color_14 {color: #525252;}
.backcolor_14 {background-color: #525252;}
.color_15 {color: #181818;}
.backcolor_15 {background-color: #181818;}
.color_16 {color: #c1c6e6;}
.backcolor_16 {background-color: #c1c6e6;}
.color_17 {color: #838ccd;}
.backcolor_17 {background-color: #838ccd;}
.color_18 {color: #4855B1;}
.backcolor_18 {background-color: #4855B1;}
.color_19 {color: #303976;}
.backcolor_19 {background-color: #303976;}
.color_20 {color: #181c3b;}
.backcolor_20 {background-color: #181c3b;}
.color_21 {color: #d3d3d3;}
.backcolor_21 {background-color: #d3d3d3;}
.color_22 {color: #a7a7a7;}
.backcolor_22 {background-color: #a7a7a7;}
.color_23 {color: #7a7a7a;}
.backcolor_23 {background-color: #7a7a7a;}
.color_24 {color: #4e4e4e;}
.backcolor_24 {background-color: #4e4e4e;}
.color_25 {color: #222222;}
.backcolor_25 {background-color: #222222;}
.color_26 {color: #fafaf9;}
.backcolor_26 {background-color: #fafaf9;}
.color_27 {color: #f5f5f3;}
.backcolor_27 {background-color: #f5f5f3;}
.color_28 {color: #bebeb0;}
.backcolor_28 {background-color: #bebeb0;}
.color_29 {color: #85856f;}
.backcolor_29 {background-color: #85856f;}
.color_30 {color: #434337;}
.backcolor_30 {background-color: #434337;}
.color_31 {color: #f1ec9f;}
.backcolor_31 {background-color: #f1ec9f;}
.color_32 {color: #E3D83E;}
.backcolor_32 {background-color: #E3D83E;}
.color_33 {color: #bdb31b;}
.backcolor_33 {background-color: #bdb31b;}
.color_34 {color: #7e7712;}
.backcolor_34 {background-color: #7e7712;}
.color_35 {color: #3f3c09;}
.backcolor_35 {background-color: #3f3c09;}
</style></div><div id="CSS_CONTAINER"></div><div data-aid="stylesContainer"><style type="text/css" data-styleid="style-kdhjonrb">.style-kdhjonrb {display:none;}</style><style type="text/css" data-styleid="pc1">.pc1screenWidthBackground {position:absolute;top:0;right:0;bottom:0;left:0;}
.pc1[data-state~="fixedPosition"] {position:fixed !important;left:auto !important;z-index:50;}
.pc1[data-state~="fixedPosition"].pc1_footer {top:auto;bottom:0;}
.pc1bg {position:absolute;top:0;right:0;bottom:0;left:0;}
.pc1[data-is-absolute-layout="true"] > .pc1centeredContent {position:absolute;top:0;right:0;bottom:0;left:0;}
.pc1[data-is-absolute-layout="true"] > .pc1centeredContent > .pc1inlineContent {position:absolute;top:0;right:0;bottom:0;left:0;}</style><style type="text/css" data-styleid="siteBackground">.siteBackground {width:100%;position:absolute;}
.siteBackgroundbgBeforeTransition {position:absolute;top:0;}
.siteBackgroundbgAfterTransition {position:absolute;top:0;}</style><style type="text/css" data-styleid="fc1">.fc1screenWidthBackground {position:absolute;top:0;right:0;bottom:0;left:0;}
.fc1[data-state~="fixedPosition"] {position:fixed !important;left:auto !important;z-index:50;}
.fc1[data-state~="fixedPosition"].fc1_footer {top:auto;bottom:0;}
.fc1_bg {position:absolute;top:0;right:0;bottom:0;left:0;background-color:rgba(255, 255, 255, 1);  border-top:1px solid rgba(255, 255, 255, 0.15);border-bottom:0px solid rgba(255, 255, 255, 0.15);}
.fc1bg {position:absolute;top:0;right:0;bottom:0;left:0;}
.fc1[data-state~="mobileView"] .fc1bg {left:10px;right:10px;}
.fc1_bg-center {position:absolute;top:1px;right:0;bottom:0px;left:0;background-color:rgba(255, 255, 255, 1);border-radius:0;}
.fc1[data-is-absolute-layout="true"] > .fc1centeredContent {position:absolute;top:0;right:0;bottom:0;left:0;}
.fc1[data-is-absolute-layout="true"] > .fc1centeredContent > .fc1inlineContent {position:absolute;top:0;right:0;bottom:0;left:0;}</style><style type="text/css" data-styleid="hc1">.hc1screenWidthBackground {position:absolute;top:0;right:0;bottom:0;left:0;}
.hc1[data-state~="fixedPosition"] {position:fixed !important;left:auto !important;z-index:50;}
.hc1[data-state~="fixedPosition"].hc1_footer {top:auto;bottom:0;}
.hc1_bg {position:absolute;top:0;right:0;bottom:0;left:0;background-color:rgba(227, 216, 62, 1);  border-top:0px solid transparent;border-bottom:0px solid transparent;}
.hc1bg {position:absolute;top:0;right:0;bottom:0;left:0;}
.hc1[data-state~="mobileView"] .hc1bg {left:10px;right:10px;}
.hc1_bg-center {position:absolute;top:0px;right:0;bottom:0px;left:0;background-color:rgba(227, 216, 62, 1);border-radius:0;}
.hc1[data-is-absolute-layout="true"] > .hc1centeredContent {position:absolute;top:0;right:0;bottom:0;left:0;}
.hc1[data-is-absolute-layout="true"] > .hc1centeredContent > .hc1inlineContent {position:absolute;top:0;right:0;bottom:0;left:0;}</style><style type="text/css" data-styleid="style-kdhjoof7">.style-kdhjoof7bg {border:0px solid rgba(24, 24, 24, 1);background-color:transparent;border-radius:0;  position:absolute;top:0;right:0;bottom:0;left:0;}
.style-kdhjoof7[data-is-absolute-layout="true"] > .style-kdhjoof7inlineContent {position:absolute;top:0;right:0;bottom:0;left:0;}</style><style type="text/css" data-styleid="style-kdgake21">.style-kdgake21 {box-sizing:border-box;border-top:1px solid rgba(24, 24, 24, 0.85);height:0;}</style><style type="text/css" data-styleid="txtNew">.txtNew {word-wrap:break-word;text-align:start;}
.txtNew_override-left * {text-align:left !important;}
.txtNew_override-right * {text-align:right !important;}
.txtNew_override-center * {text-align:center !important;}
.txtNew_override-justify * {text-align:justify !important;}
.txtNew > * {pointer-events:auto;}
.txtNew li {font-style:inherit;font-weight:inherit;line-height:inherit;letter-spacing:normal;}
.txtNew ol,.txtNew ul {padding-left:1.3em;padding-right:0;margin-left:0.5em;margin-right:0;line-height:normal;letter-spacing:normal;}
.txtNew ul {list-style-type:disc;}
.txtNew ol {list-style-type:decimal;}
.txtNew ul ul,.txtNew ol ul {list-style-type:circle;}
.txtNew ul ul ul,.txtNew ol ul ul {list-style-type:square;}
.txtNew ul ol ul,.txtNew ol ol ul {list-style-type:square;}
.txtNew ul[dir="rtl"],.txtNew ol[dir="rtl"] {padding-left:0;padding-right:1.3em;margin-left:0;margin-right:0.5em;}
.txtNew ul[dir="rtl"] ul,.txtNew ul[dir="rtl"] ol,.txtNew ol[dir="rtl"] ul,.txtNew ol[dir="rtl"] ol {padding-left:0;padding-right:1.3em;margin-left:0;margin-right:0.5em;}
.txtNew p {margin:0;line-height:normal;letter-spacing:normal;}
.txtNew h1 {margin:0;line-height:normal;letter-spacing:normal;}
.txtNew h2 {margin:0;line-height:normal;letter-spacing:normal;}
.txtNew h3 {margin:0;line-height:normal;letter-spacing:normal;}
.txtNew h4 {margin:0;line-height:normal;letter-spacing:normal;}
.txtNew h5 {margin:0;line-height:normal;letter-spacing:normal;}
.txtNew h6 {margin:0;line-height:normal;letter-spacing:normal;}
.txtNew a {color:inherit;}</style><style type="text/css" data-styleid="tpagw0">.tpagw0 {overflow:hidden;}
.tpagw0 iframe {position:absolute;width:100%;height:100%;overflow:hidden;}
.tpagw0 iframe:-webkit-full-screen {min-height:auto !important;}
.tpagw0preloaderOverlay {position:absolute;top:0;left:0;color:#373737;width:100%;height:100%;}
.tpagw0preloaderOverlaycontent {width:100%;height:100%;}
.tpagw0unavailableMessageOverlay {position:absolute;top:0;left:0;color:#373737;width:100%;height:100%;}
.tpagw0unavailableMessageOverlaycontent {width:100%;height:100%;background:rgba(255, 255, 255, 0.9);font-size:0;margin-top:5px;}
.tpagw0unavailableMessageOverlaytextContainer {color:#373737;font-family:"Helvetica Neue", "HelveticaNeueW01-55Roma", "HelveticaNeueW02-55Roma", "HelveticaNeueW10-55Roma", Helvetica, Arial, sans-serif;font-size:14px;display:inline-block;vertical-align:middle;width:100%;margin-top:10px;text-align:center;}
.tpagw0unavailableMessageOverlayreloadButton {display:inline-block;}
.tpagw0unavailableMessageOverlay a {color:#0099FF;text-decoration:underline;cursor:pointer;}
.tpagw0unavailableMessageOverlayiconContainer {display:none;}
.tpagw0unavailableMessageOverlaydismissButton {display:none;}
.tpagw0unavailableMessageOverlaytextTitle {font-family:"Helvetica Neue", "HelveticaNeueW01-55Roma", "HelveticaNeueW02-55Roma", "HelveticaNeueW10-55Roma", Helvetica, Arial, sans-serif;display:none;}
.tpagw0unavailableMessageOverlay[data-state~="hideIframe"] .tpagw0unavailableMessageOverlay_buttons {opacity:1;}
.tpagw0unavailableMessageOverlay[data-state~="hideOverlay"] {display:none;}</style><style type="text/css" data-styleid="style-kdhglxy7">
.style-kdhglxy7TPAWidgetNativeDeadcompcontent {font-size:14px;margin-top:5px;font-family:"Helvetica Neue", "HelveticaNeueW01-55Roma", "HelveticaNeueW02-55Roma", "HelveticaNeueW10-55Roma", Helvetica, Arial, sans-serif;line-height:1.43;}
.style-kdhglxy7TPAWidgetNativeDeadcompcontent > div {padding-left:17px;}
.style-kdhglxy7TPAWidgetNativeDeadcomptextContainer {word-wrap:break-word;max-width:206px;color:#174165;}
.style-kdhglxy7TPAWidgetNativeDeadcomptextTitle {font-weight:500;}
.style-kdhglxy7TPAWidgetNativeDeadcomptext {font-weight:300;}</style><style type="text/css" data-styleid="style-kdhglyer">.style-kdhglyer {overflow:hidden;}
.style-kdhglyer iframe {position:absolute;width:100%;height:100%;overflow:hidden;}
.style-kdhglyer iframe:-webkit-full-screen {min-height:auto !important;}
.style-kdhglyerpreloaderOverlay {position:absolute;top:0;left:0;color:#373737;width:100%;height:100%;}
.style-kdhglyerpreloaderOverlaycontent {width:100%;height:100%;}
.style-kdhglyerunavailableMessageOverlay {position:absolute;top:0;left:0;color:#373737;width:100%;height:100%;}
.style-kdhglyerunavailableMessageOverlaycontent {width:100%;height:100%;background:rgba(255, 255, 255, 0.9);font-size:0;margin-top:5px;}
.style-kdhglyerunavailableMessageOverlaytextContainer {color:#373737;font-family:"Helvetica Neue", "HelveticaNeueW01-55Roma", "HelveticaNeueW02-55Roma", "HelveticaNeueW10-55Roma", Helvetica, Arial, sans-serif;font-size:14px;display:inline-block;vertical-align:middle;width:100%;margin-top:10px;text-align:center;}
.style-kdhglyerunavailableMessageOverlayreloadButton {display:inline-block;}
.style-kdhglyerunavailableMessageOverlay a {color:#0099FF;text-decoration:underline;cursor:pointer;}
.style-kdhglyerunavailableMessageOverlayiconContainer {display:none;}
.style-kdhglyerunavailableMessageOverlaydismissButton {display:none;}
.style-kdhglyerunavailableMessageOverlaytextTitle {font-family:"Helvetica Neue", "HelveticaNeueW01-55Roma", "HelveticaNeueW02-55Roma", "HelveticaNeueW10-55Roma", Helvetica, Arial, sans-serif;display:none;}
.style-kdhglyerunavailableMessageOverlay[data-state~="hideIframe"] .style-kdhglyerunavailableMessageOverlay_buttons {opacity:1;}
.style-kdhglyerunavailableMessageOverlay[data-state~="hideOverlay"] {display:none;}</style><style type="text/css" data-styleid="strc1">.strc1:not([data-mobile-responsive]) > .strc1inlineContent {position:absolute;top:0;right:0;bottom:0;left:0;}
.strc1[data-mobile-responsive] > .strc1inlineContent {position:relative;}
.strc1[data-responsive] {display:-ms-grid;display:grid;justify-content:center;grid-template-columns:100%;grid-template-rows:1fr;-ms-grid-columns:100%;-ms-grid-rows:1fr;}
.strc1[data-responsive] > .strc1inlineContent {display:flex;}
.strc1[data-responsive] > * {position:relative;grid-row-start:1;grid-column-start:1;grid-row-end:2;grid-column-end:2;-ms-grid-row-span:1;-ms-grid-column-span:1;margin:0 auto;}</style><style type="text/css" data-styleid="mc1">.mc1:not([data-mobile-responsive]) .mc1inlineContent {position:absolute;top:0;right:0;bottom:0;left:0;}
.mc1:not([data-mobile-responsive]) .mc1container {position:relative;height:100%;top:0;}</style><style type="text/css" data-styleid="style-kdhgmj6m">
.style-kdhgmj6mTPAWidgetNativeDeadcompcontent {font-size:14px;margin-top:5px;font-family:"Helvetica Neue", "HelveticaNeueW01-55Roma", "HelveticaNeueW02-55Roma", "HelveticaNeueW10-55Roma", Helvetica, Arial, sans-serif;line-height:1.43;}
.style-kdhgmj6mTPAWidgetNativeDeadcompcontent > div {padding-left:17px;}
.style-kdhgmj6mTPAWidgetNativeDeadcomptextContainer {word-wrap:break-word;max-width:206px;color:#174165;}
.style-kdhgmj6mTPAWidgetNativeDeadcomptextTitle {font-weight:500;}
.style-kdhgmj6mTPAWidgetNativeDeadcomptext {font-weight:300;}</style><style type="text/css" data-styleid="style-kdhjoozt">.style-kdhjoozt {display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center;box-sizing:border-box;pointer-events:none;}
.style-kdhjoozt[data-state~="loggedIn"] {background-color:transparent;border:0px solid rgba(24, 24, 24, 1);border-radius:0;  }
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztlogin {display:none;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztdropdownMenuMobile {pointer-events:all;position:absolute;opacity:0;cursor:pointer;width:100%;height:100%;left:0;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztdropdownMenu {z-index:99999;background-color:rgba(255, 255, 255, 1);border:0px solid transparent;box-sizing:border-box;border-radius:0;    font:normal normal normal 14px/1.79em raleway,sans-serif ;  font-size:15px;position:absolute;min-width:100px;max-width:300px;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztdropdownMenu a {color:#181818;padding-left:20px;padding-right:20px;display:-webkit-box;display:-webkit-flex;display:flex;line-height:260%;border-radius:0;    pointer-events:all;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztdropdownMenu a[data-state~="selected"],.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztdropdownMenu a[data-preview~="selected"] {color:#4855B1;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztdropdownMenu a:hover,.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztdropdownMenu a[data-preview~="hover"] {color:#525252;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztdropdownMenu a > div:first-child {overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztdropdownMenu a > div:nth-child(2) {opacity:0.6;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztdropdownMenu hr {margin:5px 20px 5px 20px;opacity:0.4;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztuser {cursor:pointer;pointer-events:all;white-space:nowrap;padding-top:6px;padding-bottom:6px;position:relative;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztuser:hover .style-kdhjoozttext,.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztuser[data-preview~="hover"] .style-kdhjoozttext {color:#838CCD;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztuser:hover .style-kdhjooztarrow path,.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztuser[data-preview~="hover"] .style-kdhjooztarrow path {fill:#838CCD;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjoozticon {display:inline-block;vertical-align:middle;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjoozticon img {border-radius:50%;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjoozttext {color:#181818;font:normal normal normal 14px/1.79em raleway,sans-serif ;  display:inline-block;vertical-align:middle;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;min-width:60px;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztarrow {display:inline-block;vertical-align:middle;padding-left:14px;padding-right:14px;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztarrow path {fill:#181818;}
.style-kdhjoozt[data-state~="loggedIn"] .style-kdhjooztbuttons {padding-top:6px;padding-bottom:6px;white-space:nowrap;}
.style-kdhjoozt[data-state~="ltr"] .style-kdhjoozticon {padding-right:14px;padding-left:initial;}
.style-kdhjoozt[data-state~="ltr"] .style-kdhjooztbuttons {padding-left:14px;padding-right:initial;}
.style-kdhjoozt[data-state~="ltr"] .style-kdhjooztlogin {padding-right:14px;padding-left:initial;}
.style-kdhjoozt[data-state~="ltr"][data-state~="avatarOnly"] .style-kdhjooztarrow {padding-right:14px;padding-left:initial;}
.style-kdhjoozt[data-state~="ltr"][data-state~="noButtons"] .style-kdhjoozticon {padding-left:14px;}
.style-kdhjoozt[data-state~="ltr"][data-state~="noButtons"][data-state~="textOnly"] .style-kdhjoozttext {padding-left:14px;padding-right:initial;}
.style-kdhjoozt[data-state~="ltr"][data-state~="textOnly"] .style-kdhjooztlogin {padding-left:14px;}
.style-kdhjoozt[data-state~="rtl"] .style-kdhjoozticon {padding-right:initial;padding-left:14px;}
.style-kdhjoozt[data-state~="rtl"] .style-kdhjooztbuttons {padding-left:initial;padding-right:14px;}
.style-kdhjoozt[data-state~="rtl"] .style-kdhjooztlogin {padding-right:initial;padding-left:14px;}
.style-kdhjoozt[data-state~="rtl"][data-state~="avatarOnly"] .style-kdhjooztarrow {padding-right:initial;padding-left:14px;}
.style-kdhjoozt[data-state~="rtl"][data-state~="noButtons"] .style-kdhjoozticon {padding-right:14px;}
.style-kdhjoozt[data-state~="rtl"][data-state~="noButtons"][data-state~="textOnly"] .style-kdhjoozttext {padding-right:14px;padding-left:initial;}
.style-kdhjoozt[data-state~="rtl"][data-state~="textOnly"] .style-kdhjooztlogin {padding-right:14px;}
.style-kdhjoozt[data-state~="left"] .style-kdhjooztdropdownMenu a > div:nth-child(2) {padding-left:12px;padding-right:initial;}
.style-kdhjoozt[data-state~="right"] .style-kdhjooztdropdownMenu a > div:nth-child(2) {padding-left:initial;padding-right:12px;}
.style-kdhjoozt[data-state~="loggedOut"] {background-color:transparent;border:0px solid rgba(24, 24, 24, 1);border-radius:0;  }
.style-kdhjoozt[data-state~="loggedOut"] .style-kdhjooztuser,.style-kdhjoozt[data-state~="loggedOut"] .style-kdhjooztdropdownMenu,.style-kdhjoozt[data-state~="loggedOut"] .style-kdhjooztbuttons,.style-kdhjoozt[data-state~="loggedOut"] .style-kdhjooztdropdownMenuMobile {display:none;}
.style-kdhjoozt[data-state~="loggedOut"] .style-kdhjooztlogin {white-space:nowrap;padding-top:6px;padding-bottom:6px;color:#181818;font:normal normal normal 14px/1.79em raleway,sans-serif ;  border-radius:0;  cursor:pointer;pointer-events:all;}
.style-kdhjoozt[data-state~="loggedOut"] .style-kdhjooztlogin:hover,.style-kdhjoozt[data-state~="loggedOut"] .style-kdhjooztlogin[data-preview~="hover"] {color:#838CCD;}
.style-kdhjoozt[data-state~="loggedOut"] .style-kdhjooztlogin span {vertical-align:middle;}
.style-kdhjoozt[data-state~="loggedOut"] .style-kdhjooztlogin .style-kdhjooztavatar {display:inline-block;vertical-align:middle;padding-right:14px;padding-left:14px;}
.style-kdhjooztbutton {position:relative;display:inline-block;}
.style-kdhjooztbuttonicon {border-radius:50%;}
.style-kdhjooztbuttonbadge {background-color:#E21C21;color:#FFFFFF;border-radius:10px;position:absolute;top:0;text-align:center;height:18px;line-height:18px;letter-spacing:1px;}
.style-kdhjooztbuttonbadge span {padding-left:6px;padding-right:6px;}
.style-kdhjooztbutton a {display:block;pointer-events:all;}
.style-kdhjooztbuttonicon {overflow:hidden;}
.style-kdhjooztbuttoniconimage {position:static;box-shadow:#000 0 0 0;}
.style-kdhjooztbuttoniconsvg {position:static;box-shadow:#000 0 0 0;}
.style-kdhjooztbuttonicon[data-state~="image"] .style-kdhjooztbuttoniconsvg {display:none;}
.style-kdhjooztbuttonicon[data-state~="svg"] .style-kdhjooztbuttoniconimage {display:none;}
.style-kdhjooztbuttonicon[data-state~="svg"] .style-kdhjooztbuttoniconsvg {width:100%;height:100%;}
.style-kdhjooztbuttoniconimage {overflow:hidden;}
.style-kdhjooztbuttoniconimageimage {position:static;box-shadow:#000 0 0 0;}
.style-kdhjooztbuttoniconsvg svg {width:100%;height:100%;fill:rgba(72, 85, 177, 1);}
.style-kdhjooztbuttoniconsvg svg * {vector-effect:non-scaling-stroke;}
.style-kdhjooztbuttoniconsvg_with-shadow svg {overflow:visible !important;}
.style-kdhjooztavatar {overflow:hidden;}
.style-kdhjooztavatarimage {position:static;box-shadow:#000 0 0 0;}
.style-kdhjooztavatarsvg {position:static;box-shadow:#000 0 0 0;}
.style-kdhjooztavatar[data-state~="image"] .style-kdhjooztavatarsvg {display:none;}
.style-kdhjooztavatar[data-state~="svg"] .style-kdhjooztavatarimage {display:none;}
.style-kdhjooztavatar[data-state~="svg"] .style-kdhjooztavatarsvg {width:100%;height:100%;}
.style-kdhjooztavatarimage {overflow:hidden;}
.style-kdhjooztavatarimageimage {position:static;box-shadow:#000 0 0 0;}
.style-kdhjooztavatarsvg svg {width:100%;height:100%;fill:rgba(72, 85, 177, 1);}
.style-kdhjooztavatarsvg svg * {vector-effect:non-scaling-stroke;}
.style-kdhjooztavatarsvg_with-shadow svg {overflow:visible !important;}</style><style type="text/css" data-styleid="style-kdhjop0c">.style-kdhjop0c > ul {display:table;width:100%;box-sizing:border-box;}
.style-kdhjop0c li {display:table;width:100%;}
.style-kdhjop0c a span {pointer-events:none;}
.style-kdhjop0c_noLink {cursor:default !important;}
.style-kdhjop0c_counter {margin:0 10px;opacity:0.6;}
.style-kdhjop0cmenuContainer {padding:0;margin:0;border:solid 1px rgba(24, 24, 24, 0.2);position:relative;  border-radius:0;}
.style-kdhjop0cmenuContainer .style-kdhjop0c_emptySubMenu {display:none !important;}
.style-kdhjop0c_itemHoverArea {box-sizing:content-box;border-bottom:solid 0px rgba(24, 24, 24, 1);}
.style-kdhjop0c_itemHoverArea:first-child > .style-kdhjop0c_item {border-radius:0;    border-bottom-left-radius:0;border-bottom-right-radius:0;}
.style-kdhjop0c_itemHoverArea:last-child {border-bottom:0 solid transparent;}
.style-kdhjop0c_itemHoverArea:last-child > .style-kdhjop0c_item {border-radius:0;      border-top-left-radius:0;border-top-right-radius:0;border-bottom:0 solid transparent;}
.style-kdhjop0c_itemHoverArea.style-kdhjop0c_hover > .style-kdhjop0c_item,.style-kdhjop0c_itemHoverArea.style-kdhjop0c_selected > .style-kdhjop0c_item,.style-kdhjop0c_itemHoverArea.style-kdhjop0c_selectedContainer > .style-kdhjop0c_item {transition:background-color 0.4s ease 0s;}
.style-kdhjop0c_itemHoverArea.style-kdhjop0c_hover .style-kdhjop0c_subMenu {opacity:1;display:block;}
.style-kdhjop0c_itemHoverArea.style-kdhjop0c_hover:not(.style-kdhjop0c_noLink) > .style-kdhjop0c_item {background-color:rgba(255, 255, 255, 1);}
.style-kdhjop0c_itemHoverArea.style-kdhjop0c_hover:not(.style-kdhjop0c_noLink) > .style-kdhjop0c_item > .style-kdhjop0c_label {color:#525252;}
.style-kdhjop0c_itemHoverArea.style-kdhjop0c_selected > .style-kdhjop0c_item,.style-kdhjop0c_itemHoverArea.style-kdhjop0c_selectedContainer > .style-kdhjop0c_item {background-color:rgba(255, 255, 255, 1);}
.style-kdhjop0c_itemHoverArea.style-kdhjop0c_selected > .style-kdhjop0c_item > .style-kdhjop0c_label,.style-kdhjop0c_itemHoverArea.style-kdhjop0c_selectedContainer > .style-kdhjop0c_item > .style-kdhjop0c_label {color:#4855B1;}
.style-kdhjop0c_item {height:100%;padding-left:30px;padding-right:30px;transition:background-color 0.4s ease 0s;  margin:0;position:relative;cursor:pointer;list-style:none;background-color:rgba(255, 255, 255, 1);}
.style-kdhjop0c_label {font:normal normal normal 18px/1.75em raleway,sans-serif ;  color:#181818;display:inline;white-space:nowrap;overflow:hidden;}
.style-kdhjop0c_subMenu {z-index:999;min-width:100%;display:none;opacity:0;transition:all 0.4s ease 0s;  position:absolute;border:solid 1px rgba(24, 24, 24, 0.2);border-radius:0;  }
.style-kdhjop0c_subMenu .style-kdhjop0c_item {background-color:rgba(255, 255, 255, 1);}
.style-kdhjop0c_subMenu .style-kdhjop0c_label {font:normal normal normal 18px/1.75em raleway,sans-serif ;}
.style-kdhjop0c_subMenu > .style-kdhjop0c_itemHoverArea:first-child > .style-kdhjop0c_item,.style-kdhjop0c_subMenu > .style-kdhjop0c_itemHoverArea:first-child:last-child > .style-kdhjop0c_item {border-radius:0;}
.style-kdhjop0c_subMenu > .style-kdhjop0c_itemHoverArea:first-child > .style-kdhjop0c_item {border-bottom-left-radius:0;border-bottom-right-radius:0;}
.style-kdhjop0c_subMenu > .style-kdhjop0c_itemHoverArea:last-child {border-bottom:0 solid transparent;}
.style-kdhjop0c_subMenu > .style-kdhjop0c_itemHoverArea:last-child > .style-kdhjop0c_item {border-radius:0;      border-top-left-radius:0;border-top-right-radius:0;border-bottom:0 solid transparent;}
.style-kdhjop0c_subMenu:before {background-color:#fff;opacity:0;z-index:999;content:" ";display:block;width:calc(0px + 1px);height:100%;position:absolute;top:0;}
.style-kdhjop0c[data-state~="items-align-left"] .style-kdhjop0c_item {text-align:left;}
.style-kdhjop0c[data-state~="items-align-center"] .style-kdhjop0c_item {text-align:center;}
.style-kdhjop0c[data-state~="items-align-right"] .style-kdhjop0c_item {text-align:right;}
.style-kdhjop0c[data-state~="subItems-align-left"] .style-kdhjop0c_subMenu > .style-kdhjop0c_item {text-align:left;padding-left:30px;padding-right:30px;}
.style-kdhjop0c[data-state~="subItems-align-center"] .style-kdhjop0c_subMenu > .style-kdhjop0c_item {text-align:center;padding-left:30px;padding-right:30px;}
.style-kdhjop0c[data-state~="subItems-align-right"] .style-kdhjop0c_subMenu > .style-kdhjop0c_item {text-align:right;padding-left:30px;padding-right:30px;}
.style-kdhjop0c[data-state~="subMenuOpenSide-right"] .style-kdhjop0c_subMenu {left:100%;float:left;margin-left:0px;}
.style-kdhjop0c[data-state~="subMenuOpenSide-right"] .style-kdhjop0c_subMenu:before {right:100%;}
.style-kdhjop0c[data-state~="subMenuOpenSide-left"] .style-kdhjop0c_subMenu {right:100%;float:right;margin-right:0px;}
.style-kdhjop0c[data-state~="subMenuOpenSide-left"] .style-kdhjop0c_subMenu:before {left:100%;}
.style-kdhjop0c[data-open-direction~="subMenuOpenDir-down"] .style-kdhjop0c_subMenu {top:calc(-1 * 1px);}
.style-kdhjop0c[data-open-direction~="subMenuOpenDir-up"] .style-kdhjop0c_subMenu {bottom:calc(-1 * 1px);}
.style-kdhjop0cmenuContainer_with-validation-indication select:not([data-preview~="focus"]):invalid {border-width:2px;  border-style:solid;border-color:rgba(249, 249, 249, 1);background-color:rgba(140, 140, 140, 1);}
.style-kdhjop0cmenuContainer {display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column;}
.style-kdhjop0cmenuContainer select {border-radius:0;  -webkit-appearance:none;-moz-appearance:none;  font:normal normal normal 18px/1.75em raleway,sans-serif ;  background-color:rgba(255, 255, 255, 1);color:#181818;border-width:1px;  border-style:solid;border-color:rgba(24, 24, 24, 0.2);margin:0;padding:0 45px;cursor:pointer;position:relative;max-width:100%;min-width:100%;min-height:10px;height:100%;text-overflow:ellipsis;white-space:nowrap;display:block;}
.style-kdhjop0cmenuContainer select option {text-overflow:ellipsis;white-space:nowrap;overflow:hidden;color:#44474D;background-color:#FFFFFF;}
.style-kdhjop0cmenuContainer select.style-kdhjop0cmenuContainer_placeholder-style {color:#181818;}
.style-kdhjop0cmenuContainer select.style-kdhjop0cmenuContainer_extended-placeholder-style {color:#888888;}
.style-kdhjop0cmenuContainer select:-moz-focusring {color:transparent;text-shadow:0 0 0 #000;}
.style-kdhjop0cmenuContainer select::-ms-expand {display:none;}
.style-kdhjop0cmenuContainer select:focus::-ms-value {background:transparent;}
.style-kdhjop0cmenuContainer select:not(.style-kdhjop0cmenuContainer_mobileCollection):hover,.style-kdhjop0cmenuContainer select:not(.style-kdhjop0cmenuContainer_mobileCollection)[data-preview~="hover"] {border-width:2px;  border-style:solid;border-color:rgba(249, 249, 249, 1);background-color:rgba(255, 255, 255, 1);}
.style-kdhjop0cmenuContainer select:not(.style-kdhjop0cmenuContainer_mobileCollection):focus,.style-kdhjop0cmenuContainer select:not(.style-kdhjop0cmenuContainer_mobileCollection)[data-preview~="focus"] {border-width:2px;  border-style:solid;border-color:rgba(249, 249, 249, 1);background-color:rgba(140, 140, 140, 1);}
.style-kdhjop0cmenuContainer select:not(.style-kdhjop0cmenuContainer_mobileCollection)[data-error="true"],.style-kdhjop0cmenuContainer select:not(.style-kdhjop0cmenuContainer_mobileCollection)[data-preview~="error"] {border-width:2px;  border-style:solid;border-color:rgba(249, 249, 249, 1);background-color:rgba(140, 140, 140, 1);}
.style-kdhjop0cmenuContainer select:not(.style-kdhjop0cmenuContainer_mobileCollection):disabled,.style-kdhjop0cmenuContainer select:not(.style-kdhjop0cmenuContainer_mobileCollection)[data-disabled="true"],.style-kdhjop0cmenuContainer select:not(.style-kdhjop0cmenuContainer_mobileCollection)[data-preview~="disabled"] {border-width:2px;border-color:rgba(204, 204, 204, 1);color:#FFFFFF;background-color:rgba(204, 204, 204, 1);}
.style-kdhjop0cmenuContainer select:not(.style-kdhjop0cmenuContainer_mobileCollection):disabled + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer select:not(.style-kdhjop0cmenuContainer_mobileCollection)[data-disabled="true"] + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer select:not(.style-kdhjop0cmenuContainer_mobileCollection)[data-preview~="disabled"] + .style-kdhjop0cmenuContainerarrow {border-width:2px;border-color:rgba(204, 204, 204, 1);color:#FFFFFF;border:none;}
.style-kdhjop0cmenuContainerarrow {position:absolute;pointer-events:none;top:0;bottom:0;box-sizing:border-box;padding-left:20px;padding-right:20px;height:inherit;display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center;}
.style-kdhjop0cmenuContainerarrow .style-kdhjop0cmenuContainer_svg_container {width:12px;}
.style-kdhjop0cmenuContainerarrow .style-kdhjop0cmenuContainer_svg_container svg {height:100%;fill:rgba(197, 197, 197, 1);}
.style-kdhjop0cmenuContainer_left-direction {text-align-last:left;}
.style-kdhjop0cmenuContainer_left-direction .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_left-direction select:hover + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_left-direction select[data-preview~="hover"] + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_left-direction select:focus + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_left-direction select[data-preview~="focus"] + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_left-direction[data-preview~="focus"] .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_left-direction select[data-error="true"] + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_left-direction select[data-preview~="error"] + .style-kdhjop0cmenuContainerarrow {border-left:0;}
.style-kdhjop0cmenuContainer_left-direction .style-kdhjop0cmenuContainerarrow {right:0;}
.style-kdhjop0cmenuContainer_right-direction {text-align-last:right;direction:rtl;}
.style-kdhjop0cmenuContainer_right-direction .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_right-direction select:hover + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_right-direction select[data-preview~="hover"] + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_right-direction select:focus + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_right-direction select[data-preview~="focus"] + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_right-direction[data-preview~="focus"] .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_right-direction select[data-error="true"] + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_right-direction select[data-preview~="error"] + .style-kdhjop0cmenuContainerarrow {border-right:0;}
.style-kdhjop0cmenuContainer_right-direction .style-kdhjop0cmenuContainerarrow {left:0;}
.style-kdhjop0cmenuContainer_center-direction {text-align-last:left;text-align-last:center;}
.style-kdhjop0cmenuContainer_center-direction .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_center-direction select:hover + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_center-direction select[data-preview~="hover"] + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_center-direction select:focus + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_center-direction select[data-preview~="focus"] + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_center-direction[data-preview~="focus"] .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_center-direction select[data-error="true"] + .style-kdhjop0cmenuContainerarrow,.style-kdhjop0cmenuContainer_center-direction select[data-preview~="error"] + .style-kdhjop0cmenuContainerarrow {border-left:0;}
.style-kdhjop0cmenuContainer_center-direction .style-kdhjop0cmenuContainerarrow {right:0;}
.style-kdhjop0cmenuContainer_mobileMenuContainer {border:0;}
.style-kdhjop0cmenuContainer_mobileMenuContainer .style-kdhjop0cmenuContainerarrow .style-kdhjop0cmenuContainer_svg_container .style-kdhjop0cmenuContainericon {fill:#181818;}
.style-kdhjop0cmenuContainerlabel {font:normal normal normal 18px/1.75em raleway,sans-serif ;  color:#181818;word-break:break-word;display:inline-block;line-height:1;}
.style-kdhjop0cmenuContainer_required .style-kdhjop0cmenuContainerlabel::after {content:" *";color:transparent;}
.style-kdhjop0cmenuContainer_selector-wrapper {-webkit-box-flex:1;-webkit-flex:1;flex:1;position:relative;}</style><style type="text/css" data-styleid="tpaw0">.tpaw0 {overflow:hidden;}
.tpaw0 iframe {position:absolute;width:100%;height:100%;overflow:hidden;}
.tpaw0 iframe:-webkit-full-screen {min-height:auto !important;}
.tpaw0preloaderOverlay {position:absolute;top:0;left:0;color:#373737;width:100%;height:100%;}
.tpaw0preloaderOverlaycontent {width:100%;height:100%;}
.tpaw0unavailableMessageOverlay {position:absolute;top:0;left:0;color:#373737;width:100%;height:100%;}
.tpaw0unavailableMessageOverlaycontent {width:100%;height:100%;background:rgba(255, 255, 255, 0.9);font-size:0;margin-top:5px;}
.tpaw0unavailableMessageOverlaytextContainer {color:#373737;font-family:"Helvetica Neue", "HelveticaNeueW01-55Roma", "HelveticaNeueW02-55Roma", "HelveticaNeueW10-55Roma", Helvetica, Arial, sans-serif;font-size:14px;display:inline-block;vertical-align:middle;width:100%;margin-top:10px;text-align:center;}
.tpaw0unavailableMessageOverlayreloadButton {display:inline-block;}
.tpaw0unavailableMessageOverlay a {color:#0099FF;text-decoration:underline;cursor:pointer;}
.tpaw0unavailableMessageOverlayiconContainer {display:none;}
.tpaw0unavailableMessageOverlaydismissButton {display:none;}
.tpaw0unavailableMessageOverlaytextTitle {font-family:"Helvetica Neue", "HelveticaNeueW01-55Roma", "HelveticaNeueW02-55Roma", "HelveticaNeueW10-55Roma", Helvetica, Arial, sans-serif;display:none;}
.tpaw0unavailableMessageOverlay[data-state~="hideIframe"] .tpaw0unavailableMessageOverlay_buttons {opacity:1;}
.tpaw0unavailableMessageOverlay[data-state~="hideOverlay"] {display:none;}</style><style type="text/css" data-styleid="style-kdhlz5op">.style-kdhlz5opiframe {overflow:hidden;position:absolute;width:100%;height:100%;display:block;}
.style-kdhlz5op[data-state~="iframeNotShown"] .style-kdhlz5opiframe {display:none;}
.style-kdhlz5op[data-state~="iframeRenderedInvisible"] .style-kdhlz5opiframe {visibility:hidden;}</style><style type="text/css" data-styleid="wp1">.wp1_zoomedin {cursor:url(https://static.parastorage.com/services/skins/2.1229.80/images/wysiwyg/core/themes/base/cursor_zoom_out.png), url(https://static.parastorage.com/services/skins/2.1229.80/images/wysiwyg/core/themes/base/cursor_zoom_out.cur), auto;overflow:hidden;display:block;}
.wp1_zoomedout {cursor:url(https://static.parastorage.com/services/skins/2.1229.80/images/wysiwyg/core/themes/base/cursor_zoom_in.png), url(https://static.parastorage.com/services/skins/2.1229.80/images/wysiwyg/core/themes/base/cursor_zoom_in.cur), auto;}
.wp1link {display:block;overflow:hidden;}
.wp1img {overflow:hidden;}
.wp1[data-is-responsive=true] .wp1link,.wp1[data-is-responsive=true] .wp1img,.wp1[data-is-responsive=true] wix-image {position:absolute;top:0;right:0;bottom:0;left:0;}
.wp1imgimage {position:static;box-shadow:#000 0 0 0;user-select:none;}</style><style type="text/css" data-styleid="lb1">.lb1[data-is-responsive~="false"] .lb1itemsContainer {position:absolute;width:100%;height:100%;white-space:nowrap;}
.lb1[data-is-responsive~="false"][data-state~="mobileView"] .lb1itemsContainer {position:absolute;width:100%;height:100%;white-space:normal;}
.lb1[data-is-responsive~="true"] {display:table;}
.lb1[data-is-responsive~="true"] .lb1itemsContainer {display:-webkit-box;display:-webkit-flex;display:flex;}
.lb1itemsContainer > li:last-child {margin:0 !important;}
.lb1 a {display:block;height:100%;}
.lb1imageItemlink {cursor:pointer;}
.lb1imageItemimageimage {position:static;box-shadow:#000 0 0 0;user-select:none;}</style><style type="text/css" data-styleid="style-kdhmau1d">.style-kdhmau1ditemsContainer {width:calc(100% - 0px);height:calc(100% - 0px);white-space:nowrap;display:inline-block;overflow:visible;position:absolute;}
.style-kdhmau1dmoreContainer {overflow:visible;display:inherit;white-space:nowrap;width:auto;background-color:rgba(227, 216, 62, 1);border-radius:0;  }
.style-kdhmau1ddropWrapper {z-index:99999;display:block;opacity:1;visibility:hidden;position:absolute;margin-top:7px;}
.style-kdhmau1d > nav {position:absolute;top:0;right:0;bottom:0;left:0;}
.style-kdhmau1ddropWrapper[data-dropMode="dropUp"] {margin-top:0;margin-bottom:7px;}
.style-kdhmau1dnavContainer_with-validation-indication select:not([data-preview~="focus"]):invalid {border-width:2px;  border-style:solid;border-color:rgba(249, 249, 249, 1);background-color:rgba(140, 140, 140, 1);}
.style-kdhmau1dnavContainer {display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;flex-direction:column;}
.style-kdhmau1dnavContainer select {border-radius:0;  -webkit-appearance:none;-moz-appearance:none;  font:normal normal normal 20px/1.67em raleway,sans-serif ;  background-color:rgba(140, 140, 140, 1);color:#181818;border-style:solid;border-color:rgba(0, 0, 0, 0.2);border-width:1px;border-left-width:0px;border-right-width:0px;margin:0;padding:0 45px;cursor:pointer;position:relative;max-width:100%;min-width:100%;min-height:10px;height:100%;text-overflow:ellipsis;white-space:nowrap;display:block;}
.style-kdhmau1dnavContainer select option {text-overflow:ellipsis;white-space:nowrap;overflow:hidden;color:#44474D;background-color:#FFFFFF;}
.style-kdhmau1dnavContainer select.style-kdhmau1dnavContainer_placeholder-style {color:#181818;}
.style-kdhmau1dnavContainer select.style-kdhmau1dnavContainer_extended-placeholder-style {color:#888888;}
.style-kdhmau1dnavContainer select:-moz-focusring {color:transparent;text-shadow:0 0 0 #000;}
.style-kdhmau1dnavContainer select::-ms-expand {display:none;}
.style-kdhmau1dnavContainer select:focus::-ms-value {background:transparent;}
.style-kdhmau1dnavContainer select:not(.style-kdhmau1dnavContainer_mobileCollection):hover,.style-kdhmau1dnavContainer select:not(.style-kdhmau1dnavContainer_mobileCollection)[data-preview~="hover"] {border-width:2px;  border-style:solid;border-color:rgba(249, 249, 249, 1);background-color:rgba(140, 140, 140, 1);}
.style-kdhmau1dnavContainer select:not(.style-kdhmau1dnavContainer_mobileCollection):focus,.style-kdhmau1dnavContainer select:not(.style-kdhmau1dnavContainer_mobileCollection)[data-preview~="focus"] {border-width:2px;  border-style:solid;border-color:rgba(249, 249, 249, 1);background-color:rgba(140, 140, 140, 1);}
.style-kdhmau1dnavContainer select:not(.style-kdhmau1dnavContainer_mobileCollection)[data-error="true"],.style-kdhmau1dnavContainer select:not(.style-kdhmau1dnavContainer_mobileCollection)[data-preview~="error"] {border-width:2px;  border-style:solid;border-color:rgba(249, 249, 249, 1);background-color:rgba(140, 140, 140, 1);}
.style-kdhmau1dnavContainer select:not(.style-kdhmau1dnavContainer_mobileCollection):disabled,.style-kdhmau1dnavContainer select:not(.style-kdhmau1dnavContainer_mobileCollection)[data-disabled="true"],.style-kdhmau1dnavContainer select:not(.style-kdhmau1dnavContainer_mobileCollection)[data-preview~="disabled"] {border-width:2px;border-color:rgba(204, 204, 204, 1);color:#FFFFFF;background-color:rgba(204, 204, 204, 1);}
.style-kdhmau1dnavContainer select:not(.style-kdhmau1dnavContainer_mobileCollection):disabled + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer select:not(.style-kdhmau1dnavContainer_mobileCollection)[data-disabled="true"] + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer select:not(.style-kdhmau1dnavContainer_mobileCollection)[data-preview~="disabled"] + .style-kdhmau1dnavContainerarrow {border-width:2px;border-color:rgba(204, 204, 204, 1);color:#FFFFFF;border:none;}
.style-kdhmau1dnavContainerarrow {position:absolute;pointer-events:none;top:0;bottom:0;box-sizing:border-box;padding-left:20px;padding-right:20px;height:inherit;display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center;border-style:solid;border-color:rgba(0, 0, 0, 0.2);border-left-width:1px;}
.style-kdhmau1dnavContainerarrow .style-kdhmau1dnavContainer_svg_container {width:12px;}
.style-kdhmau1dnavContainerarrow .style-kdhmau1dnavContainer_svg_container svg {height:100%;fill:rgba(197, 197, 197, 1);}
.style-kdhmau1dnavContainer_left-direction {text-align-last:left;}
.style-kdhmau1dnavContainer_left-direction .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_left-direction select:hover + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_left-direction select[data-preview~="hover"] + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_left-direction select:focus + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_left-direction select[data-preview~="focus"] + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_left-direction[data-preview~="focus"] .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_left-direction select[data-error="true"] + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_left-direction select[data-preview~="error"] + .style-kdhmau1dnavContainerarrow {border-right:0;}
.style-kdhmau1dnavContainer_left-direction .style-kdhmau1dnavContainerarrow {right:0;border-left-width:1px;}
.style-kdhmau1dnavContainer_right-direction {text-align-last:right;direction:rtl;}
.style-kdhmau1dnavContainer_right-direction .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_right-direction select:hover + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_right-direction select[data-preview~="hover"] + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_right-direction select:focus + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_right-direction select[data-preview~="focus"] + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_right-direction[data-preview~="focus"] .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_right-direction select[data-error="true"] + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_right-direction select[data-preview~="error"] + .style-kdhmau1dnavContainerarrow {border-left:0;}
.style-kdhmau1dnavContainer_right-direction .style-kdhmau1dnavContainerarrow {left:0;border-right-width:1px;}
.style-kdhmau1dnavContainer_center-direction {text-align-last:left;text-align-last:center;}
.style-kdhmau1dnavContainer_center-direction .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_center-direction select:hover + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_center-direction select[data-preview~="hover"] + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_center-direction select:focus + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_center-direction select[data-preview~="focus"] + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_center-direction[data-preview~="focus"] .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_center-direction select[data-error="true"] + .style-kdhmau1dnavContainerarrow,.style-kdhmau1dnavContainer_center-direction select[data-preview~="error"] + .style-kdhmau1dnavContainerarrow {border-right:0;}
.style-kdhmau1dnavContainer_center-direction .style-kdhmau1dnavContainerarrow {right:0;border-left-width:1px;}
.style-kdhmau1dnavContainer_mobileMenuContainer {border:0;}
.style-kdhmau1dnavContainer_mobileMenuContainer .style-kdhmau1dnavContainerarrow .style-kdhmau1dnavContainer_svg_container .style-kdhmau1dnavContainericon {fill:#181818;}
.style-kdhmau1dnavContainerlabel {font:normal normal normal 18px/1.75em raleway,sans-serif ;  color:#181818;word-break:break-word;display:inline-block;line-height:1;}
.style-kdhmau1dnavContainer_required .style-kdhmau1dnavContainerlabel::after {content:" *";color:transparent;}
.style-kdhmau1dnavContainer_selector-wrapper {-webkit-box-flex:1;-webkit-flex:1;flex:1;position:relative;}
.style-kdhmau1drepeaterButton {height:100%;position:relative;box-sizing:border-box;display:inline-block;cursor:pointer;font:normal normal normal 14px/1.79em raleway,sans-serif ;}
.style-kdhmau1drepeaterButton[data-state~="header"] a,.style-kdhmau1drepeaterButton[data-state~="header"] div {cursor:default !important;}
.style-kdhmau1drepeaterButtonlinkElement {display:inline-block;height:100%;width:100%;}
.style-kdhmau1drepeaterButton_gapper {padding:0 0px;}
.style-kdhmau1drepeaterButtonlabel {display:inline-block;padding:0 10px;color:#181818;transition:color 0.4s ease 0s;}
.style-kdhmau1drepeaterButton[data-state~="drop"] {width:100%;display:block;}
.style-kdhmau1drepeaterButton[data-state~="drop"] .style-kdhmau1drepeaterButtonlabel {padding:0 .5em;}
.style-kdhmau1drepeaterButton[data-state~="over"] .style-kdhmau1drepeaterButtonlabel,.style-kdhmau1drepeaterButton[data-preview~="hover"] .style-kdhmau1drepeaterButtonlabel {color:#222222;transition:color 0.4s ease 0s;}
.style-kdhmau1drepeaterButton[data-state~="selected"] .style-kdhmau1drepeaterButtonlabel,.style-kdhmau1drepeaterButton[data-preview~="active"] .style-kdhmau1drepeaterButtonlabel {color:#222222;transition:color 0.4s ease 0s;}</style><style type="text/css" data-styleid="p1">.p1bg {position:absolute;top:0;right:0;bottom:0;left:0;}
.p1[data-state~="mobileView"] .p1bg {left:10px;right:10px;}
.p1inlineContent {position:absolute;top:0;right:0;bottom:0;left:0;}</style><style type="text/css" data-styleid="s_DtaksTPAWidgetSkin">.s_DtaksTPAWidgetSkin {overflow:hidden;}
.s_DtaksTPAWidgetSkin iframe {position:absolute;width:100%;height:100%;overflow:hidden;}
.s_DtaksTPAWidgetSkin iframe:-webkit-full-screen {min-height:auto !important;}
.s_DtaksTPAWidgetSkinpreloaderOverlay {position:absolute;top:0;left:0;color:#373737;width:100%;height:100%;}
.s_DtaksTPAWidgetSkinpreloaderOverlaycontent {width:100%;height:100%;}
.s_DtaksTPAWidgetSkinunavailableMessageOverlay {position:absolute;top:0;left:0;color:#373737;width:100%;height:100%;}
.s_DtaksTPAWidgetSkinunavailableMessageOverlaycontent {width:100%;height:100%;background:rgba(255, 255, 255, 0.9);font-size:0;margin-top:5px;}
.s_DtaksTPAWidgetSkinunavailableMessageOverlaytextContainer {color:#373737;font-family:"Helvetica Neue", "HelveticaNeueW01-55Roma", "HelveticaNeueW02-55Roma", "HelveticaNeueW10-55Roma", Helvetica, Arial, sans-serif;font-size:14px;display:inline-block;vertical-align:middle;width:100%;margin-top:10px;text-align:center;}
.s_DtaksTPAWidgetSkinunavailableMessageOverlayreloadButton {display:inline-block;}
.s_DtaksTPAWidgetSkinunavailableMessageOverlay a {color:#0099FF;text-decoration:underline;cursor:pointer;}
.s_DtaksTPAWidgetSkinunavailableMessageOverlayiconContainer {display:none;}
.s_DtaksTPAWidgetSkinunavailableMessageOverlaydismissButton {display:none;}
.s_DtaksTPAWidgetSkinunavailableMessageOverlaytextTitle {font-family:"Helvetica Neue", "HelveticaNeueW01-55Roma", "HelveticaNeueW02-55Roma", "HelveticaNeueW10-55Roma", Helvetica, Arial, sans-serif;display:none;}
.s_DtaksTPAWidgetSkinunavailableMessageOverlay[data-state~="hideIframe"] .s_DtaksTPAWidgetSkinunavailableMessageOverlay_buttons {opacity:1;}
.s_DtaksTPAWidgetSkinunavailableMessageOverlay[data-state~="hideOverlay"] {display:none;}</style></div><div class="noop visual-focus-on" style="position:relative"><div id="SCROLL_TO_TOP" tabindex="-1" aria-label="top of page" role="region" style="height:0"></div><div id="FONTS_CONTAINER"></div><div id="SITE_BACKGROUND" style="height:100%;top:50px;min-height:calc(100vh - 50px);bottom:;left:;right:;position:" class="siteBackground"><div id="SITE_BACKGROUND_previous_noPrev" data-position="absolute" data-align="" data-fitting="" class="siteBackgroundprevious"><div id="SITE_BACKGROUNDpreviousImage" class="siteBackgroundpreviousImage"></div><div id="SITE_BACKGROUNDpreviousVideo" class="siteBackgroundpreviousVideo"></div><div id="SITE_BACKGROUND_previousOverlay_noPrev" class="siteBackgroundpreviousOverlay"></div></div><div id="SITE_BACKGROUND_current_o0j6r_desktop_bg" style="top:0;height:100%;width:100%;background-color:rgba(255, 255, 255, 1);display:;position:absolute" data-position="absolute" data-align="top" data-fitting="fill" class="siteBackgroundcurrent"><div id="SITE_BACKGROUND_currentImage_o0j6r_desktop_bg" style="position:absolute;top:0;height:100%;width:100%" data-type="bgimage" data-height="100%" class="siteBackgroundcurrentImage"></div><div id="SITE_BACKGROUNDcurrentVideo" class="siteBackgroundcurrentVideo"></div><div id="SITE_BACKGROUND_currentOverlay_o0j6r_desktop_bg" style="position:absolute;top:0;width:100%;height:100%" class="siteBackgroundcurrentOverlay"></div></div></div><div id="SITE_ROOT" class="SITE_ROOT" style="width:100%;min-width:980px;padding-bottom:0;top:50px" aria-hidden="false"><div id="masterPage" class="mesh-layout" data-mesh-layout="grid"><header data-is-absolute-layout="false" data-is-mobile="false" data-state="transition-allowed" data-site-width="980" data-header-top="0" style="position:relative;margin-top:0;z-index:50;left:0;margin-left:0;width:100%;min-width:980px;top:;bottom:;right:" class="hc1" id="SITE_HEADER"><div style="left:0;width:100%" id="SITE_HEADERscreenWidthBackground" class="hc1screenWidthBackground"><div class="hc1_bg"></div></div><div id="SITE_HEADERcenteredContent" class="hc1centeredContent"><div style="margin-left:calc((100% - 980px) / 2);width:980px" id="SITE_HEADERbg" class="hc1bg"><div class="hc1_bg-center"></div></div><div id="SITE_HEADERinlineContent" class="hc1inlineContent"><style id="SITE_HEADER-mesh-styles">
    
#SITE_HEADERinlineContent {
    height: auto;
    width: 100%;
    position: relative;
}

#SITE_HEADERinlineContent-gridWrapper {
    pointer-events: none;
}

#SITE_HEADERinlineContent-gridContainer {
    position: static;
    display: grid;
    height: auto;
    width: 100%;
    min-height: auto;
    grid-template-rows: min-content 1fr;
    grid-template-columns: 100%;
}

#comp-kdhjqs1y {
    position: relative;
    margin: 30px 0px 3px calc((100% - 980px) * 0.5);
    left: 0px;
    grid-area: 1 / 1 / 2 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdgakdu1 {
    position: relative;
    margin: 0px 80px 10px 80px;
    left: 0;
    grid-area: 2 / 1 / 3 / 2;
    justify-self: stretch;
    align-self: start;
}

#comp-kdhmasr3 {
    position: relative;
    margin: 1px 0px 30px calc((100% - 980px) * 0.5);
    left: 0px;
    grid-area: 2 / 1 / 3 / 2;
    justify-self: start;
    align-self: start;
}

#SITE_HEADERcenteredContent {
    position: relative;
}

#SITE_HEADERinlineContent-gridContainer > * {
    pointer-events: auto;
}

#SITE_HEADERinlineContent-gridContainer > [id$="-rotated-wrapper"] {
    pointer-events: none;
}

#SITE_HEADERinlineContent-gridContainer > [id$="-rotated-wrapper"] > * {
    pointer-events: auto;
}</style><div id="SITE_HEADERinlineContent-gridWrapper" data-mesh-internal="true"><div id="SITE_HEADERinlineContent-gridContainer" data-mesh-internal="true"><section style="left:0;width:100%;min-width:860px;height:auto;top:;bottom:;right:;position:;margin-left:0" data-responsive="true" data-is-screen-width="true" data-col-margin="0" data-row-margin="0" class="strc1" id="comp-kdhjqs1y"><div style="position:absolute;top:0;width:calc(100% - 120px);height:100%;overflow:hidden;pointer-events:auto;min-width:980px;left:0;right:0;bottom:0" data-page-id="masterPage" data-enable-video="true" data-bg-effect-name="" data-full-screen-height="" data-media-type="" data-use-clip-path="" data-needs-clipping="" data-wix-video-layout="true" class="strc1balata" id="comp-kdhjqs1ybalata"><div style="position:absolute;width:100%;height:100%;top:0;background-color:transparent" class="bgColor" id="comp-kdhjqs1ybalatabgcolor"><div style="width:100%;height:100%;position:absolute;top:0;background-image:;opacity:1" id="comp-kdhjqs1ybalatabgcoloroverlay" class="bgColoroverlay"></div></div></div><div style="position:relative;width:calc(100% - 120px);min-width:980px" id="comp-kdhjqs1yinlineContent" class="strc1inlineContent"><div style="position:relative;width:100%;left:0;flex:20;margin-left:0;min-width:20px;top:0;margin-top:0;margin-bottom:0;height:;display:flex;bottom:;right:" data-content-width="20" data-is-mesh="true" class="mc1" id="comp-kdhjqs1y1"><div class="mc1container" style="position:relative;height:100%;width:100%" id="comp-kdhjqs1y1container"><div style="position:absolute;top:0;width:100%;height:100%;overflow:hidden;pointer-events:auto;left:0;right:0;bottom:0" data-page-id="masterPage" data-enable-video="true" data-bg-effect-name="" data-full-screen-height="" data-media-type="" data-use-clip-path="" data-needs-clipping="" data-wix-video-layout="true" class="mc1balata" id="comp-kdhjqs1y1balata"><div style="position:absolute;width:100%;height:100%;top:0" class="bgColor" id="comp-kdhjqs1y1balatabgcolor"><div style="width:100%;height:100%;position:absolute;top:0;background-image:;opacity:1" id="comp-kdhjqs1y1balatabgcoloroverlay" class="bgColoroverlay"></div></div></div><div class="mc1inlineContentParent" style="position:relative;left:0;right:0;top:0;bottom:0" id="comp-kdhjqs1y1inlineContentParent"><div style="width:100%;position:relative;top:0;bottom:0" class="mc1inlineContent" id="comp-kdhjqs1y1inlineContent"><style id="comp-kdhjqs1y1-mesh-styles">
    
#comp-kdhjqs1y1inlineContent {
    height: auto;
    width: 100%;
    position: relative;
}

#comp-kdhjqs1y1inlineContent-gridContainer {
    position: static;
    height: auto;
    width: 100%;
    min-height: 36px;
}

#comp-kdhjqs1y1centeredContent {
    position: relative;
}

#comp-kdhjqs1y1inlineContent-gridWrapper {
    pointer-events: none;
}

#comp-kdhjqs1y1inlineContent-gridContainer > * {
    pointer-events: auto;
}

#comp-kdhjqs1y1inlineContent-gridContainer > [id$="-rotated-wrapper"] {
    pointer-events: none;
}

#comp-kdhjqs1y1inlineContent-gridContainer > [id$="-rotated-wrapper"] > * {
    pointer-events: auto;
}</style><div id="comp-kdhjqs1y1inlineContent-gridContainer" data-mesh-internal="true"></div></div></div></div></div><div style="position:relative;width:100%;left:0;flex:960;margin-left:0px;min-width:960px;top:0;margin-top:0;margin-bottom:0;height:;display:flex;bottom:;right:" data-content-width="960" data-is-mesh="true" class="mc1" id="comp-kdhjqs1z"><div class="mc1container" style="position:relative;height:100%;width:100%" id="comp-kdhjqs1zcontainer"><div style="position:absolute;top:0;width:100%;height:100%;overflow:hidden;pointer-events:auto;left:0;right:0;bottom:0" data-page-id="masterPage" data-enable-video="true" data-bg-effect-name="" data-full-screen-height="" data-media-type="" data-use-clip-path="" data-needs-clipping="" data-wix-video-layout="true" class="mc1balata" id="comp-kdhjqs1zbalata"><div style="position:absolute;width:100%;height:100%;top:0" class="bgColor" id="comp-kdhjqs1zbalatabgcolor"><div style="width:100%;height:100%;position:absolute;top:0;background-image:;opacity:1" id="comp-kdhjqs1zbalatabgcoloroverlay" class="bgColoroverlay"></div></div></div><div class="mc1inlineContentParent" style="position:relative;left:0;right:0;top:0;bottom:0" id="comp-kdhjqs1zinlineContentParent"><div style="width:100%;position:relative;top:0;bottom:0" class="mc1inlineContent" id="comp-kdhjqs1zinlineContent"><style id="comp-kdhjqs1z-mesh-styles">
    
#comp-kdhjqs1zinlineContent {
    height: auto;
    width: 100%;
    position: relative;
}

#comp-kdhjqs1zinlineContent-gridWrapper {
    display: flex;
    pointer-events: none;
}

#comp-kdhjqs1zinlineContent-gridContainer {
    position: static;
    display: grid;
    height: auto;
    width: 100%;
    min-height: auto;
    margin-top: -4px;
    grid-template-rows: 1fr;
    grid-template-columns: 100%;
}

#comp-kdhjooyy {
    position: relative;
    margin: 0px 0px 0px calc((100% - 960px) * 1);
    left: 689px;
    grid-area: 1 / 1 / 2 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdgakvfd {
    position: relative;
    margin: 9px 0px 11px calc((100% - 960px) * 1);
    left: 916px;
    grid-area: 1 / 1 / 2 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdhjqs1zcenteredContent {
    position: relative;
}

#comp-kdhjqs1zinlineContent-gridContainer > * {
    pointer-events: auto;
}

#comp-kdhjqs1zinlineContent-gridContainer > [id$="-rotated-wrapper"] {
    pointer-events: none;
}

#comp-kdhjqs1zinlineContent-gridContainer > [id$="-rotated-wrapper"] > * {
    pointer-events: auto;
}</style><div id="comp-kdhjqs1zinlineContent-gridWrapper" data-mesh-internal="true"><div id="comp-kdhjqs1zinlineContent-gridContainer" data-mesh-internal="true"><div style="direction:ltr;justify-content:flex-end;top:;bottom:;left:;right:;width:220px;height:40px;position:" aria-label="Login or Sign up" data-icon-size="22" data-is-logged-in="false" class="style-kdhjoozt" data-state="loggedOut ltr left textOnly noButtons" id="comp-kdhjooyy"><button id="comp-kdhjooyylogin" class="style-kdhjooztlogin"><span>Log In</span></button><nav id="comp-kdhjooyybuttons" class="style-kdhjooztbuttons"></nav><div id="comp-kdhjooyyuserWrapper" class="style-kdhjooztuserWrapper"><button id="comp-kdhjooyyuser" class="style-kdhjooztuser"><div id="comp-kdhjooyyicon" class="style-kdhjoozticon"></div><div id="comp-kdhjooyytext" class="style-kdhjoozttext"></div><div id="comp-kdhjooyyarrow" class="style-kdhjooztarrow"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="8" viewBox="0 0 14 8"><path fill-rule="nonzero" d="M1.707.293L.293 1.707l6 6a1 1 0 0 0 1.397.016l6-5.726L12.31.55 7.016 5.602 1.707.292z"></path></svg></div></button><select id="comp-kdhjooyydropdownMenuMobile" class="style-kdhjooztdropdownMenuMobile"></select></div><nav id="comp-kdhjooyydropdownMenu" class="style-kdhjooztdropdownMenu"></nav></div><div style="height:;overflow:initial;top:;bottom:;left:;right:;width:24px;position:" class="style-kdhglxy7" id="comp-kdgakvfd"><div class="comp-kdgakvfd"><style> .kOc8C{padding:0;position:relative} .kOc8C>svg{position:absolute !important;top:0;bottom:0;left:0;right:0} ._1mnzP{opacity:0} ._3tSTQ{text-decoration:none;width:100%;display:block;overflow:hidden;outline:none} .js-focus-visible ._3tSTQ:focus{position:relative;box-shadow:none} .js-focus-visible ._3tSTQ:focus:after{content:'';position:absolute;width:100%;height:100%;left:0;top:0;outline:none;box-shadow:inset 0 0 1px 1px #3899EC,inset 0 0 0 2px rgba(255,255,255,0.9)} .TVS20 text._1INsc{font-size:50px !important} .TVS20._1XXzv ._1INsc{font-size:45px !important} .TVS20.EUvEj ._1INsc{font-size:37px !important} .NBa0J._1XXzv ._1INsc{font-size:80px !important} .NBa0J.EUvEj ._1INsc{font-size:58px !important} ._3UFsv._1XXzv ._1INsc{font-size:60px !important} ._3UFsv.EUvEj ._1INsc{font-size:45px !important} ._1no4L._1XXzv ._1INsc{font-size:60px !important} ._1no4L.EUvEj ._1INsc{font-size:40px !important} ._1vU46._1XXzv ._1INsc{font-size:70px !important} ._1vU46.EUvEj ._1INsc{font-size:60px !important} ._3G5Za._1XXzv ._1INsc{font-size:80px !important} ._3G5Za.EUvEj ._1INsc{font-size:60px !important} ._1ORBK._1XXzv ._1INsc{font-size:75px !important} ._1ORBK.EUvEj ._1INsc{font-size:55px !important} ._2_phW._1XXzv ._1INsc{font-size:75px !important} ._2_phW.EUvEj ._1INsc{font-size:59px !important} ._2cqrE._1XXzv ._1INsc{font-size:80px !important} ._2cqrE.EUvEj ._1INsc{font-size:65px !important} ._1NhFN._1XXzv ._1INsc{font-size:75px !important} ._1NhFN.EUvEj ._1INsc{font-size:60px !important} ._3UChe._1XXzv ._1INsc{font-size:80px !important} ._3UChe.EUvEj ._1INsc{font-size:60px !important}

</style><style>

.comp-kdgakvfd ._1gJ4T{--cartWidget_cartIcon: #4855B1;--cartWidget_cartIconText: #4855B1;--cartWidget_cartIconTextFont: normal normal normal 18px/1.75em raleway,sans-serif;--cartWidget_cartIconNumberFont: normal normal normal 18px/1.75em raleway,sans-serif;--cartWidget_cartIconBubble: #4855B1}.comp-kdgakvfd ._3tSTQ rect,.comp-kdgakvfd ._3tSTQ polygon,.comp-kdgakvfd ._3tSTQ polyline,.comp-kdgakvfd ._3tSTQ circle,.comp-kdgakvfd ._3tSTQ path{fill:#181818}.comp-kdgakvfd ._3tSTQ text{fill:#4855B1;font:normal normal normal 18px/1.75em raleway,sans-serif;text-decoration: ;font-size:90px}.comp-kdgakvfd ._3tSTQ ._1INsc{fill:#181818;font:normal normal normal 18px/1.75em raleway,sans-serif;text-decoration: ;font-size:90px}.comp-kdgakvfd ._3tSTQ ._1INsc._3KKRv{fill:#181818}.comp-kdgakvfd ._3tSTQ .m8g_G{fill:#4855B1}</style>
		
		
	
		<div data-border-width="1px" style="transform-origin:center 0.5px;left:0;margin-left:80px;width:calc(100% - 160px);min-width:initial;top:;bottom:;right:;height:5px;position:" class="style-kdgake21" id="comp-kdgakdu1"></div><section style="left:0;width:100%;min-width:860px;height:auto;top:;bottom:;right:;position:;margin-left:0" data-responsive="true" data-is-screen-width="true" data-col-margin="0" data-row-margin="0" class="strc1" id="comp-kdhmasr3"><div style="position:absolute;top:0;width:calc(100% - 120px);height:100%;overflow:hidden;pointer-events:auto;min-width:980px;left:0;right:0;bottom:0" data-page-id="masterPage" data-enable-video="true" data-bg-effect-name="" data-full-screen-height="" data-media-type="" data-use-clip-path="" data-needs-clipping="" data-wix-video-layout="true" class="strc1balata" id="comp-kdhmasr3balata"><div style="position:absolute;width:100%;height:100%;top:0;background-color:transparent" class="bgColor" id="comp-kdhmasr3balatabgcolor"><div style="width:100%;height:100%;position:absolute;top:0;background-image:;opacity:1" id="comp-kdhmasr3balatabgcoloroverlay" class="bgColoroverlay"></div></div></div><div style="position:relative;width:calc(100% - 120px);min-width:980px" id="comp-kdhmasr3inlineContent" class="strc1inlineContent"><div style="position:relative;width:100%;left:0;flex:592;margin-left:0;min-width:592px;top:0;margin-top:0;margin-bottom:0;height:;display:flex;bottom:;right:" data-content-width="592" data-is-mesh="true" class="mc1" id="comp-kdhmasr31"><div class="mc1container" style="position:relative;height:100%;width:100%" id="comp-kdhmasr31container"><div style="position:absolute;top:0;width:100%;height:100%;overflow:hidden;pointer-events:auto;left:0;right:0;bottom:0" data-page-id="masterPage" data-enable-video="true" data-bg-effect-name="" data-full-screen-height="" data-media-type="" data-use-clip-path="" data-needs-clipping="" data-wix-video-layout="true" class="mc1balata" id="comp-kdhmasr31balata"><div style="position:absolute;width:100%;height:100%;top:0" class="bgColor" id="comp-kdhmasr31balatabgcolor"><div style="width:100%;height:100%;position:absolute;top:0;background-image:;opacity:1" id="comp-kdhmasr31balatabgcoloroverlay" class="bgColoroverlay"></div></div></div><div class="mc1inlineContentParent" style="position:relative;left:0;right:0;top:0;bottom:0" id="comp-kdhmasr31inlineContentParent"><div style="width:100%;position:relative;top:0;bottom:0" class="mc1inlineContent" id="comp-kdhmasr31inlineContent"><style id="comp-kdhmasr31-mesh-styles">
    
#comp-kdhmasr31inlineContent {
    height: auto;
    width: 100%;
    position: relative;
}

#comp-kdhmasr31inlineContent-gridWrapper {
    pointer-events: none;
}

#comp-kdhmasr31inlineContent-gridContainer {
    position: static;
    display: grid;
    height: auto;
    width: 100%;
    min-height: auto;
    grid-template-rows: 1fr;
    grid-template-columns: 100%;
}

#comp-kdhmasr32 {
    position: relative;
    margin: 20px 0px 0px calc((100% - 592px) * 0);
    left: 20px;
    grid-area: 1 / 1 / 2 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdhmasr33 {
    position: relative;
    margin: 81px 0px 10px calc((100% - 592px) * 0);
    left: 262px;
    grid-area: 1 / 1 / 2 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdhmasr31centeredContent {
    position: relative;
}

#comp-kdhmasr31inlineContent-gridContainer > * {
    pointer-events: auto;
}

#comp-kdhmasr31inlineContent-gridContainer > [id$="-rotated-wrapper"] {
    pointer-events: none;
}

#comp-kdhmasr31inlineContent-gridContainer > [id$="-rotated-wrapper"] > * {
    pointer-events: auto;
}</style><div id="comp-kdhmasr31inlineContent-gridWrapper" data-mesh-internal="true"><div id="comp-kdhmasr31inlineContent-gridContainer" data-mesh-internal="true"><div style="top:;bottom:;left:;right:;width:227px;height:160px;position:" title="" data-is-responsive="false" data-display-mode="fit" data-content-padding-horizontal="0" data-content-padding-vertical="0" data-exact-height="160" class="wp1" id="comp-kdhmasr32"><a style="cursor:pointer;width:227px;height:160px" href="https://igrejaevredencao74.wixsite.com/akipertinho" target="_self" id="comp-kdhmasr32link" class="wp1link"><wix-image style="width:227px;height:160px;top:0;left:0" data-has-bg-scroll-effect="" data-image-info="{&quot;imageData&quot;:{&quot;type&quot;:&quot;Image&quot;,&quot;id&quot;:&quot;dataItem-kdhmassf&quot;,&quot;metaData&quot;:{&quot;pageId&quot;:&quot;masterPage&quot;,&quot;isPreset&quot;:false,&quot;schemaVersion&quot;:&quot;1.0&quot;,&quot;isHidden&quot;:false},&quot;title&quot;:&quot;&quot;,&quot;uri&quot;:&quot;b75703_43677f9c7e074ee19ae3822f2908427f~mv2.png&quot;,&quot;description&quot;:&quot;&quot;,&quot;width&quot;:2048,&quot;height&quot;:1442,&quot;alt&quot;:&quot;5.png&quot;,&quot;name&quot;:&quot;5.png&quot;,&quot;link&quot;:{&quot;type&quot;:&quot;PageLink&quot;,&quot;id&quot;:&quot;dataItem-kdhmassf1&quot;,&quot;metaData&quot;:{&quot;pageId&quot;:&quot;masterPage&quot;,&quot;isPreset&quot;:false,&quot;schemaVersion&quot;:&quot;1.0&quot;,&quot;isHidden&quot;:false},&quot;pageId&quot;:{&quot;type&quot;:&quot;Page&quot;,&quot;id&quot;:&quot;o0j6r&quot;,&quot;metaData&quot;:{&quot;pageId&quot;:&quot;masterPage&quot;,&quot;isPreset&quot;:false,&quot;schemaVersion&quot;:&quot;2.0&quot;,&quot;isHidden&quot;:false},&quot;title&quot;:&quot;Início&quot;,&quot;hideTitle&quot;:true,&quot;icon&quot;:&quot;&quot;,&quot;descriptionSEO&quot;:&quot;Um portal que se destina a prestação de serviços de divulgação, anúncios exclusivos para empresas que querem anunciar seus produtos e serviços.&quot;,&quot;metaKeywordsSEO&quot;:&quot;Aqui perto, produtos, região, pertinho, perto, todo negócio&quot;,&quot;pageTitleSEO&quot;:&quot;Início | Todo Negócio AKI Pertinho&quot;,&quot;pageUriSEO&quot;:&quot;início&quot;,&quot;hidePage&quot;:false,&quot;isMobileLandingPage&quot;:false,&quot;underConstruction&quot;:false,&quot;tpaApplicationId&quot;:0,&quot;pageSecurity&quot;:{&quot;requireLogin&quot;:false,&quot;passwordDigest&quot;:&quot;&quot;,&quot;dialogLanguage&quot;:&quot;&quot;},&quot;isPopup&quot;:false,&quot;indexable&quot;:true,&quot;isLandingPage&quot;:false,&quot;pageBackgrounds&quot;:{&quot;desktop&quot;:{&quot;custom&quot;:true,&quot;ref&quot;:{&quot;type&quot;:&quot;BackgroundMedia&quot;,&quot;id&quot;:&quot;o0j6r_desktop_bg&quot;,&quot;metaData&quot;:{&quot;pageId&quot;:&quot;o0j6r&quot;,&quot;isPreset&quot;:false,&quot;schemaVersion&quot;:&quot;2.0&quot;,&quot;isHidden&quot;:false},&quot;color&quot;:&quot;{color_11}&quot;,&quot;alignType&quot;:&quot;top&quot;,&quot;fittingType&quot;:&quot;fill&quot;,&quot;scrollType&quot;:&quot;fixed&quot;},&quot;isPreset&quot;:true},&quot;mobile&quot;:{&quot;custom&quot;:true,&quot;ref&quot;:{&quot;type&quot;:&quot;BackgroundMedia&quot;,&quot;id&quot;:&quot;o0j6r_mobile_bg&quot;,&quot;metaData&quot;:{&quot;pageId&quot;:&quot;o0j6r&quot;,&quot;isPreset&quot;:false,&quot;schemaVersion&quot;:&quot;2.0&quot;,&quot;isHidden&quot;:false},&quot;color&quot;:&quot;{color_11}&quot;,&quot;alignType&quot;:&quot;top&quot;,&quot;fittingType&quot;:&quot;fill&quot;,&quot;scrollType&quot;:&quot;fixed&quot;},&quot;isPreset&quot;:true,&quot;mediaSizing&quot;:&quot;viewport&quot;}},&quot;translationData&quot;:{&quot;uriSEOTranslated&quot;:false}},&quot;target&quot;:&quot;_self&quot;},&quot;displayMode&quot;:&quot;fit&quot;},&quot;containerId&quot;:&quot;comp-kdhmasr32&quot;,&quot;displayMode&quot;:&quot;fit&quot;}" data-has-ssr-src="true" data-is-svg="false" data-is-svg-mask="false" id="comp-kdhmasr32img" class="wp1img"><img id="comp-kdhmasr32imgimage" style="object-position:50% 50%;width:227px;height:160px;object-fit:contain" alt="5.png" data-type="image" itemProp="image" src="https://static.wixstatic.com/media/b75703_43677f9c7e074ee19ae3822f2908427f~mv2.png/v1/fill/w_136,h_96,al_c,usm_0.66_1.00_0.01,blur_2/5.png"/></wix-image></a></div><div data-packed="true" data-vertical-text="false" style="top:;bottom:;left:;right:;width:330px;height:auto;position:;pointer-events:none" class="txtNew" id="comp-kdhmasr33"><p class="font_9" style="text-align:left; line-height:1.875em;"><span class="color_15">A sua vitrine de produtos online&nbsp;em todo Brasil</span></p></div></div></div></div></div></div></div><div style="position:relative;width:100%;left:0;flex:388;margin-left:0px;min-width:388px;top:0;margin-top:0;margin-bottom:0;height:;display:flex;bottom:;right:" data-content-width="388" data-is-mesh="true" class="mc1" id="comp-kdhmasr4"><div class="mc1container" style="position:relative;height:100%;width:100%" id="comp-kdhmasr4container"><div style="position:absolute;top:0;width:100%;height:100%;overflow:hidden;pointer-events:auto;left:0;right:0;bottom:0" data-page-id="masterPage" data-enable-video="true" data-bg-effect-name="" data-full-screen-height="" data-media-type="" data-use-clip-path="" data-needs-clipping="" data-wix-video-layout="true" class="mc1balata" id="comp-kdhmasr4balata"><div style="position:absolute;width:100%;height:100%;top:0" class="bgColor" id="comp-kdhmasr4balatabgcolor"><div style="width:100%;height:100%;position:absolute;top:0;background-image:;opacity:1" id="comp-kdhmasr4balatabgcoloroverlay" class="bgColoroverlay"></div></div></div><div class="mc1inlineContentParent" style="position:relative;left:0;right:0;top:0;bottom:0" id="comp-kdhmasr4inlineContentParent"><div style="width:100%;position:relative;top:0;bottom:0" class="mc1inlineContent" id="comp-kdhmasr4inlineContent"><style id="comp-kdhmasr4-mesh-styles">
    
#comp-kdhmasr4inlineContent {
    height: auto;
    width: 100%;
    position: relative;
}

#comp-kdhmasr4inlineContent-gridWrapper {
    pointer-events: none;
}

#comp-kdhmasr4inlineContent-gridContainer {
    position: static;
    display: grid;
    height: auto;
    width: 100%;
    min-height: auto;
    grid-template-rows: 1fr;
    grid-template-columns: 100%;
}

#comp-kdhmau0v {
    position: relative;
    margin: 85px 0px 65px calc((100% - 388px) * 1);
    left: 92px;
    grid-area: 1 / 1 / 2 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdhmasr41 {
    position: relative;
    margin: 90px 0px 70px calc((100% - 388px) * 1);
    left: 318px;
    grid-area: 1 / 1 / 2 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdhmasr4centeredContent {
    position: relative;
}

#comp-kdhmasr4inlineContent-gridContainer > * {
    pointer-events: auto;
}

#comp-kdhmasr4inlineContent-gridContainer > [id$="-rotated-wrapper"] {
    pointer-events: none;
}

#comp-kdhmasr4inlineContent-gridContainer > [id$="-rotated-wrapper"] > * {
    pointer-events: auto;
}</style><div id="comp-kdhmasr4inlineContent-gridWrapper" data-mesh-internal="true"><div id="comp-kdhmasr4inlineContent-gridContainer" data-mesh-internal="true"><div id="comp-kdhmau0v" class="hidden-during-prewarmup style-kdhmau1d" style="overflow-x:hidden;top:;bottom:;left:;right:;width:216px;height:30px;position:" data-stretch-buttons-to-menu-width="false" data-same-width-buttons="false" data-num-items="3" data-menuborder-y="0" data-menubtn-border="0" data-ribbon-els="0" data-label-pad="0" data-ribbon-extra="0" data-drophposition="" data-dropalign="right" dir="ltr" data-state="right notMobile"><nav aria-label="Site" id="comp-kdhmau0vnavContainer" class="style-kdhmau1dnavContainer"><ul style="text-align:right" id="comp-kdhmau0vitemsContainer" class="style-kdhmau1ditemsContainer"><li data-direction="ltr" data-listposition="center" data-data-id="dataItem-kdga3imz" class="style-kdhmau1drepeaterButton" data-state="menu selected idle link notMobile" id="comp-kdhmau0v0"><a data-listposition="center" aria-haspopup="false" href="https://igrejaevredencao74.wixsite.com/akipertinho" target="_self" id="comp-kdhmau0v0linkElement" class="style-kdhmau1drepeaterButtonlinkElement"><div class="style-kdhmau1drepeaterButton_gapper"><div style="text-align:right" id="comp-kdhmau0v0bg" class="style-kdhmau1drepeaterButtonbg"><p style="text-align:right" id="comp-kdhmau0v0label" class="style-kdhmau1drepeaterButtonlabel">Início</p></div></div></a></li><li data-direction="ltr" data-listposition="center" data-data-id="dataItem-kdgakvc6" class="style-kdhmau1drepeaterButton" data-state="menu  idle link notMobile" id="comp-kdhmau0v1"><a data-listposition="center" aria-haspopup="false" href="https://igrejaevredencao74.wixsite.com/akipertinho/shop" target="_self" id="comp-kdhmau0v1linkElement" class="style-kdhmau1drepeaterButtonlinkElement"><div class="style-kdhmau1drepeaterButton_gapper"><div style="text-align:right" id="comp-kdhmau0v1bg" class="style-kdhmau1drepeaterButtonbg"><p style="text-align:right" id="comp-kdhmau0v1label" class="style-kdhmau1drepeaterButtonlabel">Loja</p></div></div></a></li><li data-direction="ltr" data-listposition="right" data-data-id="dataItem-kdgal4wo" class="style-kdhmau1drepeaterButton" data-state="menu  idle link notMobile" id="comp-kdhmau0v2"><a data-listposition="right" aria-haspopup="false" href="https://igrejaevredencao74.wixsite.com/akipertinho/plans-pricing" target="_self" id="comp-kdhmau0v2linkElement" class="style-kdhmau1drepeaterButtonlinkElement"><div class="style-kdhmau1drepeaterButton_gapper"><div style="text-align:right" id="comp-kdhmau0v2bg" class="style-kdhmau1drepeaterButtonbg"><p style="text-align:right" id="comp-kdhmau0v2label" class="style-kdhmau1drepeaterButtonlabel">Planos e Preços</p></div></div></a></li><li data-listposition="right" class="style-kdhmau1drepeaterButton" data-state="menu  idle header notMobile" id="comp-kdhmau0v__more__"><a data-listposition="right" tabindex="0" aria-haspopup="true" id="comp-kdhmau0v__more__linkElement" class="style-kdhmau1drepeaterButtonlinkElement"><div class="style-kdhmau1drepeaterButton_gapper"><div style="text-align:right" id="comp-kdhmau0v__more__bg" class="style-kdhmau1drepeaterButtonbg"><p style="text-align:right" id="comp-kdhmau0v__more__label" class="style-kdhmau1drepeaterButtonlabel">Mais</p></div></div></a></li></ul><div id="comp-kdhmau0vmoreButton" class="style-kdhmau1dmoreButton"></div><div style="visibility:hidden" data-drophposition="" data-dropalign="right" id="comp-kdhmau0vdropWrapper" class="style-kdhmau1ddropWrapper"><ul style="visibility:hidden" id="comp-kdhmau0vmoreContainer" class="style-kdhmau1dmoreContainer"></ul></div></nav></div><div data-is-responsive="false" style="width:50px;height:20px;top:;bottom:;left:;right:;position:" data-hide-prejs="true" class="lb1" id="comp-kdhmasr41"><ul aria-label="Social bar" id="comp-kdhmasr41itemsContainer" class="lb1itemsContainer"><li style="width:20px;height:20px;margin-bottom:0;margin-right:10px;display:inline-block" class="lb1imageItem" id="comp-kdhmasr410image"><a href="https://www.facebook.com/todonegocio.online/" target="_blank" data-content="https://www.facebook.com/todonegocio.online/" data-type="external" rel="nofollow noopener" id="comp-kdhmasr410imagelink" class="lb1imageItemlink"><wix-image style="width:20px;height:20px;position:absolute" data-has-bg-scroll-effect="" data-image-info="{&quot;imageData&quot;:{&quot;type&quot;:&quot;Image&quot;,&quot;id&quot;:&quot;dataItem-kdhmassz&quot;,&quot;metaData&quot;:{&quot;pageId&quot;:&quot;masterPage&quot;,&quot;isPreset&quot;:false,&quot;schemaVersion&quot;:&quot;1.0&quot;,&quot;isHidden&quot;:false},&quot;title&quot;:&quot;Facebook&quot;,&quot;uri&quot;:&quot;0fdef751204647a3bbd7eaa2827ed4f9.png&quot;,&quot;description&quot;:&quot;&quot;,&quot;width&quot;:200,&quot;height&quot;:200,&quot;alt&quot;:&quot;Facebook&quot;,&quot;name&quot;:&quot;Facebook&quot;,&quot;link&quot;:{&quot;type&quot;:&quot;ExternalLink&quot;,&quot;id&quot;:&quot;dataItem-kdhmassz1&quot;,&quot;metaData&quot;:{&quot;pageId&quot;:&quot;masterPage&quot;,&quot;isPreset&quot;:false,&quot;schemaVersion&quot;:&quot;1.0&quot;,&quot;isHidden&quot;:false},&quot;url&quot;:&quot;https://www.facebook.com/todonegocio.online/&quot;,&quot;target&quot;:&quot;_blank&quot;},&quot;displayMode&quot;:&quot;fill&quot;},&quot;containerId&quot;:&quot;comp-kdhmasr41&quot;,&quot;displayMode&quot;:&quot;fill&quot;}" data-has-ssr-src="" data-is-svg="false" data-is-svg-mask="false" id="comp-kdhmasr410imageimage" class="lb1imageItemimage"><img id="comp-kdhmasr410imageimageimage" alt="Facebook" data-type="image" itemProp="image"/></wix-image></a></li><li style="width:20px;height:20px;margin-bottom:0;margin-right:10px;display:inline-block" class="lb1imageItem" id="comp-kdhmasr411image"><a href="https://www.instagram.com/todonegocio.online/" target="_blank" data-content="https://www.instagram.com/todonegocio.online/" data-type="external" rel="nofollow noopener" id="comp-kdhmasr411imagelink" class="lb1imageItemlink"><wix-image style="width:20px;height:20px;position:absolute" data-has-bg-scroll-effect="" data-image-info="{&quot;imageData&quot;:{&quot;type&quot;:&quot;Image&quot;,&quot;id&quot;:&quot;dataItem-kdhmassz2&quot;,&quot;metaData&quot;:{&quot;pageId&quot;:&quot;masterPage&quot;,&quot;isPreset&quot;:false,&quot;schemaVersion&quot;:&quot;1.0&quot;,&quot;isHidden&quot;:false},&quot;title&quot;:&quot;Instagram&quot;,&quot;uri&quot;:&quot;01c3aff52f2a4dffa526d7a9843d46ea.png&quot;,&quot;description&quot;:&quot;&quot;,&quot;width&quot;:200,&quot;height&quot;:200,&quot;alt&quot;:&quot;Instagram&quot;,&quot;name&quot;:&quot;Instagram&quot;,&quot;link&quot;:{&quot;type&quot;:&quot;ExternalLink&quot;,&quot;id&quot;:&quot;dataItem-kdhmassz3&quot;,&quot;metaData&quot;:{&quot;pageId&quot;:&quot;masterPage&quot;,&quot;isPreset&quot;:false,&quot;schemaVersion&quot;:&quot;1.0&quot;,&quot;isHidden&quot;:false},&quot;url&quot;:&quot;https://www.instagram.com/todonegocio.online/&quot;,&quot;target&quot;:&quot;_blank&quot;},&quot;displayMode&quot;:&quot;fill&quot;},&quot;containerId&quot;:&quot;comp-kdhmasr41&quot;,&quot;displayMode&quot;:&quot;fill&quot;}" data-has-ssr-src="" data-is-svg="false" data-is-svg-mask="false" id="comp-kdhmasr411imageimage" class="lb1imageItemimage"><img id="comp-kdhmasr411imageimageimage" alt="Instagram" data-type="image" itemProp="image"/></wix-image></a></li></ul></div></div></div></div></div></div></div></div></section></div></div></div></div></header><main tabindex="-1" data-is-mobile="false" data-is-mesh="true" data-site-width="980" style="left:0;margin-left:0;width:100%;min-width:980px;top:0;bottom:;right:;position:" class="pc1" data-state="" id="PAGES_CONTAINER"><div style="left:0" id="PAGES_CONTAINERscreenWidthBackground" class="pc1screenWidthBackground"></div><div style="position:relative" id="PAGES_CONTAINERcenteredContent" class="pc1centeredContent"><div style="display:none" id="PAGES_CONTAINERbg" class="pc1bg"></div><div style="position:relative" id="PAGES_CONTAINERinlineContent" class="pc1inlineContent"><div style="width:100%"><div data-ismobile="false" data-is-mesh-layout="true" style="height:100%;left:0;position:relative;top:;bottom:;right:" class="p1" id="o0j6r"><div style="margin-left:calc((100% - 980px) / 2);width:980px" id="o0j6rbg" class="p1bg"></div><div class="p1inlineContent" id="o0j6rinlineContent"><style id="o0j6r-mesh-styles">
    
#o0j6rinlineContent {
    height: auto;
    width: 100%;
    position: relative;
}

#o0j6rinlineContent-gridWrapper {
    pointer-events: none;
}

#o0j6rinlineContent-gridContainer {
    position: static;
    display: grid;
    height: auto;
    width: 100%;
    min-height: 500px;
    grid-template-rows: min-content min-content 1fr;
    grid-template-columns: 100%;
    padding-bottom: 0px;
    box-sizing: border-box;
}

#comp-kdhlz5o0 {
    position: relative;
    margin: 0px 0px 0 calc((100% - 980px) * 0.5);
    left: 0px;
    grid-area: 1 / 1 / 2 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdhgmi4e2 {
    position: relative;
    margin: 0px 0px 0 calc((100% - 980px) * 0.5);
    left: 0px;
    grid-area: 2 / 1 / 3 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdhgmjf4 {
    position: relative;
    margin: 0px 0px 0 calc((100% - 980px) * 0.5);
    left: 0px;
    grid-area: 3 / 1 / 4 / 2;
    justify-self: start;
    align-self: start;
}

#o0j6rcenteredContent {
    position: relative;
}

#o0j6rinlineContent-gridContainer > * {
    pointer-events: auto;
}

#o0j6rinlineContent-gridContainer > [id$="-rotated-wrapper"] {
    pointer-events: none;
}

#o0j6rinlineContent-gridContainer > [id$="-rotated-wrapper"] > * {
    pointer-events: auto;
}</style><div id="o0j6rinlineContent-gridWrapper" data-mesh-internal="true"><div id="o0j6rinlineContent-gridContainer" data-mesh-internal="true"><section style="left:0;width:100%;min-width:980px;height:auto;top:;bottom:;right:;position:;margin-left:0" data-responsive="true" data-is-screen-width="true" data-col-margin="0" data-row-margin="0" class="strc1" id="comp-kdhlz5o0"><div style="position:absolute;top:0;width:calc(100% - 0px);height:100%;overflow:hidden;pointer-events:auto;min-width:980px;left:0;right:0;bottom:0" data-page-id="o0j6r" data-enable-video="true" data-bg-effect-name="" data-full-screen-height="" data-media-type="" data-use-clip-path="" data-needs-clipping="" data-wix-video-layout="true" class="strc1balata" id="comp-kdhlz5o0balata"><div style="position:absolute;width:100%;height:100%;top:0;background-color:transparent" class="bgColor" id="comp-kdhlz5o0balatabgcolor"><div style="width:100%;height:100%;position:absolute;top:0;background-image:;opacity:1" id="comp-kdhlz5o0balatabgcoloroverlay" class="bgColoroverlay"></div></div></div><div style="position:relative;width:calc(100% - 0px);min-width:980px" id="comp-kdhlz5o0inlineContent" class="strc1inlineContent"><div style="position:relative;width:100%;left:0;flex:980;margin-left:0;min-width:980px;top:0;margin-top:0;margin-bottom:0;height:;display:flex;bottom:;right:" data-content-width="980" data-is-mesh="true" class="mc1" id="comp-kdhlz5o1"><div class="mc1container" style="position:relative;height:100%;width:100%" id="comp-kdhlz5o1container"><div style="position:absolute;top:0;width:100%;height:100%;overflow:hidden;pointer-events:auto;left:0;right:0;bottom:0" data-page-id="o0j6r" data-enable-video="true" data-bg-effect-name="" data-full-screen-height="" data-media-type="" data-use-clip-path="" data-needs-clipping="" data-wix-video-layout="true" class="mc1balata" id="comp-kdhlz5o1balata"><div style="position:absolute;width:100%;height:100%;top:0;background-color:rgba(255, 255, 255, 1)" class="bgColor" id="comp-kdhlz5o1balatabgcolor"><div style="width:100%;height:100%;position:absolute;top:0;background-image:;opacity:1" id="comp-kdhlz5o1balatabgcoloroverlay" class="bgColoroverlay"></div></div></div><div class="mc1inlineContentParent" style="position:relative;left:0;right:0;top:0;bottom:0" id="comp-kdhlz5o1inlineContentParent"><div style="width:100%;position:relative;top:0;bottom:0" class="mc1inlineContent" id="comp-kdhlz5o1inlineContent"><style id="comp-kdhlz5o1-mesh-styles">
    
#comp-kdhlz5o1inlineContent {
    height: auto;
    width: 100%;
    position: relative;
}

#comp-kdhlz5o1inlineContent-gridWrapper {
    pointer-events: none;
}

#comp-kdhlz5o1inlineContent-gridContainer {
    position: static;
    display: grid;
    height: auto;
    width: 100%;
    min-height: auto;
    grid-template-rows: 1fr;
    grid-template-columns: 100%;
}

#comp-kdhlz5o12 {
    position: relative;
    margin: 0px 0px 0px calc((100% - 980px) * 0.5);
    left: -222px;
    grid-area: 1 / 1 / 2 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdhlz5o1centeredContent {
    position: relative;
}

#comp-kdhlz5o1inlineContent-gridContainer > * {
    pointer-events: auto;
}

#comp-kdhlz5o1inlineContent-gridContainer > [id$="-rotated-wrapper"] {
    pointer-events: none;
}

#comp-kdhlz5o1inlineContent-gridContainer > [id$="-rotated-wrapper"] > * {
    pointer-events: auto;
}</style><div id="comp-kdhlz5o1inlineContent-gridWrapper" data-mesh-internal="true"><div id="comp-kdhlz5o1inlineContent-gridContainer" data-mesh-internal="true"><wix-iframe style="height:520px;display:table;min-width:10px;min-height:10px;left:0;margin-left:0;width:100%;top:;bottom:;right:;position:" data-src="https://static.parastorage.com/services/wix-bolt/1.6455.0/node_modules/wix-santa/node_modules/santa-galleries/target/StripSlideshow/StripSlideshow.html?compId=comp-kdhlz5o12&amp;consent-policy=%7B%7BconsentPolicy%7D%7D&amp;currency=BRL&amp;deviceType=desktop&amp;locale=pt&amp;siteRevision=57&amp;tz=America%2FSao_Paulo&amp;viewMode=site" data-is-screen-width="true" id="comp-kdhlz5o12" class="style-kdhlz5op"><iframe allowfullscreen="" frameBorder="0" scrolling="no" allowtransparency="true" style="height:520px;width:100%;position:relative;min-height:10px;min-width:10px" class="tpa-gallery-StripSlideshow style-kdhlz5opiframe" data-src="https://static.parastorage.com/services/wix-bolt/1.6455.0/node_modules/wix-santa/node_modules/santa-galleries/target/StripSlideshow/StripSlideshow.html?compId=comp-kdhlz5o12&amp;consent-policy=%7B%7BconsentPolicy%7D%7D&amp;currency=BRL&amp;deviceType=desktop&amp;locale=pt&amp;siteRevision=57&amp;tz=America%2FSao_Paulo&amp;viewMode=site" id="comp-kdhlz5o12iframe"></iframe></wix-iframe></div></div></div></div></div></div></div></section><section style="left:0;width:100%;min-width:980px;height:auto;top:;bottom:;right:;position:;margin-left:0" data-responsive="true" data-is-screen-width="true" data-col-margin="0" data-row-margin="0" class="strc1" id="comp-kdhgmi4e2"><div style="position:absolute;top:0;width:calc(100% - 0px);height:100%;overflow:hidden;pointer-events:auto;min-width:980px;left:0;right:0;bottom:0" data-page-id="o0j6r" data-enable-video="true" data-bg-effect-name="" data-full-screen-height="" data-media-type="" data-use-clip-path="" data-needs-clipping="" data-wix-video-layout="true" class="strc1balata" id="comp-kdhgmi4e2balata"><div style="position:absolute;width:100%;height:100%;top:0;background-color:transparent" class="bgColor" id="comp-kdhgmi4e2balatabgcolor"><div style="width:100%;height:100%;position:absolute;top:0;background-image:;opacity:1" id="comp-kdhgmi4e2balatabgcoloroverlay" class="bgColoroverlay"></div></div></div><div style="position:relative;width:calc(100% - 0px);min-width:980px" id="comp-kdhgmi4e2inlineContent" class="strc1inlineContent"><div style="position:relative;width:100%;left:0;flex:980;margin-left:0;min-width:980px;top:0;margin-top:0;margin-bottom:0;height:;display:flex;bottom:;right:" data-content-width="980" data-is-mesh="true" class="mc1" id="comp-kdhgmi4e3"><div class="mc1container" style="position:relative;height:100%;width:100%" id="comp-kdhgmi4e3container"><div style="position:absolute;top:0;width:100%;height:100%;overflow:hidden;pointer-events:auto;left:0;right:0;bottom:0" data-page-id="o0j6r" data-enable-video="true" data-bg-effect-name="" data-full-screen-height="" data-media-type="" data-use-clip-path="" data-needs-clipping="" data-wix-video-layout="true" class="mc1balata" id="comp-kdhgmi4e3balata"><div style="position:absolute;width:100%;height:100%;top:0;background-color:rgba(255, 255, 255, 1)" class="bgColor" id="comp-kdhgmi4e3balatabgcolor"><div style="width:100%;height:100%;position:absolute;top:0;background-image:;opacity:1" id="comp-kdhgmi4e3balatabgcoloroverlay" class="bgColoroverlay"></div></div></div><div class="mc1inlineContentParent" style="position:relative;left:0;right:0;top:0;bottom:0" id="comp-kdhgmi4e3inlineContentParent"><div style="width:100%;position:relative;top:0;bottom:0" class="mc1inlineContent" id="comp-kdhgmi4e3inlineContent"><style id="comp-kdhgmi4e3-mesh-styles">
    
#comp-kdhgmi4e3inlineContent {
    height: auto;
    width: 100%;
    position: relative;
}

#comp-kdhgmi4e3inlineContent-gridWrapper {
    pointer-events: none;
}

#comp-kdhgmi4e3inlineContent-gridContainer {
    position: static;
    display: grid;
    height: auto;
    width: 100%;
    min-height: auto;
    grid-template-rows: 1fr;
    grid-template-columns: 100%;
}

#comp-kdhgmi4f {
    position: relative;
    margin: 0px 0 7px 0;
    left: 0;
    grid-area: 1 / 1 / 2 / 2;
    justify-self: stretch;
    align-self: start;
}

#comp-kdhgmi4e3centeredContent {
    position: relative;
}

#comp-kdhgmi4e3inlineContent-gridContainer > * {
    pointer-events: auto;
}

#comp-kdhgmi4e3inlineContent-gridContainer > [id$="-rotated-wrapper"] {
    pointer-events: none;
}

#comp-kdhgmi4e3inlineContent-gridContainer > [id$="-rotated-wrapper"] > * {
    pointer-events: auto;
}</style><div id="comp-kdhgmi4e3inlineContent-gridWrapper" data-mesh-internal="true"><div id="comp-kdhgmi4e3inlineContent-gridContainer" data-mesh-internal="true"><div style="height:;overflow:initial;left:0;margin-left:0;width:100%;min-width:initial;top:;bottom:;right:;position:" class="style-kdhgmj6m" id="comp-kdhgmi4f"><div class="comp-kdhgmi4f"><style> .kpb5P{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0, 0, 0, 0);border:0}

 ._34sIs{text-decoration:none;flex:1} ._3koxZ ._34sIs{flex-grow:0} ._34sIs _:-ms-fullscreen, ._34sIs{flex:none;display:block} ._2zTHN{display:flex;flex-direction:column;width:100%;border-style:solid;box-sizing:border-box} ._2zTHN._2AHc6 ._3sC7k:not(:only-of-type) ._3dS0Z{transition:opacity 300ms} ._2zTHN._2AHc6 ._3sC7k:not(:only-of-type):first-of-type ._3dS0Z{opacity:1;transition-delay:0ms} ._2zTHN._2AHc6 ._3sC7k:not(:only-of-type):last-of-type ._3dS0Z{opacity:0;transition-delay:300ms} ._2zTHN._124MD ._3sC7k ._3dS0Z{transition:transform 300ms} ._2zTHN:hover._18SzJ, ._2zTHN._1eCts._18SzJ{outline:1px solid black} ._2zTHN:hover._2AHc6 ._3sC7k:not(:only-of-type):first-of-type ._3dS0Z, ._2zTHN._1eCts._2AHc6 ._3sC7k:not(:only-of-type):first-of-type ._3dS0Z{opacity:0;transition-delay:300ms} ._2zTHN:hover._2AHc6 ._3sC7k:not(:only-of-type):last-of-type ._3dS0Z, ._2zTHN._1eCts._2AHc6 ._3sC7k:not(:only-of-type):last-of-type ._3dS0Z{opacity:1;transition-delay:0ms} ._2zTHN:hover._124MD ._3dS0Z, ._2zTHN._1eCts._124MD ._3dS0Z{transform:scale(1.3)} ._2zTHN:hover ._3ezRD, ._2zTHN._1eCts ._3ezRD{transform:translateY(-100%);transition-duration:300ms} ._2zTHN:hover ._3qVQI, ._2zTHN._1eCts ._3qVQI{opacity:1;transition:200ms linear} ._2zTHN .mxMP4{box-sizing:content-box;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:center;position:absolute;top:0;text-rendering:optimizeSpeed;-webkit-font-smoothing:subpixel-antialiased;color:white;padding:5px 10px;min-width:20%;max-width:80%} ._2zTHN ._3ezRD{padding:0;border:none;font:inherit;color:inherit;background-color:transparent;position:absolute;top:100%;transition-property:transform;transition-duration:399ms;height:50px;width:100%;cursor:pointer;line-height:50px !important;text-align:center} ._2zTHN ._3RqKm{flex:1 0 auto;display:flex;flex-direction:column;word-wrap:break-word;text-decoration:none} ._2zTHN ._3RqKm ._2BULo{flex:1 0 auto;margin:0} ._2zTHN ._3RqKm ._11uJt{border:0 solid;display:inline-block;vertical-align:middle;max-width:100%;margin:0.5em 0} ._2zTHN ._3qVQI{opacity:0;transition:200ms linear}

 ._1M-R0{position:relative;display:inline-block} ._1WPzN{position:absolute;border-radius:50%;display:inline-block;pointer-events:none;top:10px;width:30px;height:30px;background:rgba(255,255,255,0.75);color:#000000}@media (min-width: 768px){ ._1WPzN{width:40px;height:40px}} ._1WPzN ._3S5u4, ._1WPzN svg{width:100%;height:100%} .dImJ9{position:relative;display:inline-flex;justify-content:center;align-items:center;background-color:#000000;color:#ffffff;width:100%;height:100%}

 ._3-5SE{position:relative;overflow:hidden;background-position:center;background-repeat:no-repeat} ._3-5SE .t-Mk1{position:absolute;top:0;right:0;bottom:0;left:0;width:100% !important;height:100% !important;display:flex;justify-content:center;align-items:center} ._3-5SE .t-Mk1._25C4T ._17TsC{visibility:hidden} ._3-5SE .t-Mk1 ._17TsC._2lsYE{position:absolute;top:0;left:0;width:100%;height:100%} ._3-5SE .t-Mk1 ._17TsC._2PNEb{max-width:100%;max-height:100%}

 ._3uack, ._3DJ-f{margin-top:5px} .deviceMobile ._3uack, .deviceMobile ._3DJ-f{margin-top:3px} .isRTL ._3uack, .isRTL ._3DJ-f{direction:rtl} ._3uack ._23IPr{text-decoration:line-through;opacity:0.5} ._3uack ._23IPr, ._3uack ._23ArP{display:inline-flex}

 ._1mj7g{margin-bottom:20px} ._3Sftb{margin:12px 0} ._3Sftb:first-child:last-child{margin-top:12px} ._3Sftb:last-child{margin:0}

 .fdDtX{background:#fff;text-align:center;padding:30px 0;color:#ddd} ._3etjW{padding:0 15px;margin-top:15px;margin-bottom:0;font-size:15px;font-weight:400}

 ._2DDgw{padding:calc(16px - 3px) 0} ._2DDgw .slick-slider{position:relative;display:block;box-sizing:border-box;-webkit-touch-callout:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;touch-action:pan-y;-webkit-tap-highlight-color:transparent} ._2DDgw .slick-list{position:relative;overflow:hidden;display:block;margin:0;padding:0} ._2DDgw .slick-list:focus{outline:none} ._2DDgw .slick-list.dragging{cursor:pointer;cursor:hand} ._2DDgw .slick-slider .slick-track, ._2DDgw .slick-slider .slick-list{transform:translate3d(0, 0, 0)} ._2DDgw .slick-track{position:relative;left:0;top:0;display:block;margin-left:auto;margin-right:auto} ._2DDgw .slick-track:before, ._2DDgw .slick-track:after{content:"";display:table} ._2DDgw .slick-track:after{clear:both} ._1nvsz ._2DDgw .slick-track{visibility:hidden} ._2DDgw .slick-slide{float:left;height:100%;min-height:1px;display:none} [dir="rtl"] ._2DDgw .slick-slide{float:right} ._2DDgw .slick-slide img{display:block} ._2DDgw .slick-slide.slick-loading img{display:none} ._2DDgw .slick-slide.dragging img{pointer-events:none} ._17aDR ._2DDgw .slick-slide{display:block} ._1nvsz ._2DDgw .slick-slide{visibility:hidden} ._39GaH ._2DDgw .slick-slide{display:block;height:auto;border:1px solid transparent} ._2DDgw .slick-arrow.slick-hidden{display:none} ._1nvsz ._2DDgw .slick-list{background:#fff url(data:image/gif;base64,R0lGODlhIAAgAPUAAP///wAAAPr6+sTExOjo6PDw8NDQ0H5+fpqamvb29ubm5vz8/JKSkoaGhuLi4ri4uKCgoOzs7K6urtzc3D4+PlZWVmBgYHx8fKioqO7u7kpKSmxsbAwMDAAAAM7OzsjIyNjY2CwsLF5eXh4eHkxMTLCwsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH+GkNyZWF0ZWQgd2l0aCBhamF4bG9hZC5pbmZvACH5BAAKAAAAIf8LTkVUU0NBUEUyLjADAQAAACwAAAAAIAAgAAAG/0CAcEgkFjgcR3HJJE4SxEGnMygKmkwJxRKdVocFBRRLfFAoj6GUOhQoFAVysULRjNdfQFghLxrODEJ4Qm5ifUUXZwQAgwBvEXIGBkUEZxuMXgAJb1dECWMABAcHDEpDEGcTBQMDBQtvcW0RbwuECKMHELEJF5NFCxm1AAt7cH4NuAOdcsURy0QCD7gYfcWgTQUQB6Zkr66HoeDCSwIF5ucFz3IC7O0CC6zx8YuHhW/3CvLyfPX4+OXozKnDssBdu3G/xIHTpGAgOUPrZimAJCfDPYfDin2TQ+xeBnWbHi37SC4YIYkQhdy7FvLdpwWvjA0JyU/ISyIx4xS6sgfkNS4me2rtVKkgw0JCb8YMZdjwqMQ2nIY8BbcUQNVCP7G4MQq1KRivR7tiDEuEFrggACH5BAAKAAEALAAAAAAgACAAAAb/QIBwSCQmNBpCcckkEgREA4ViKA6azM8BEZ1Wh6LOBls0HA5fgJQ6HHQ6InKRcWhA1d5hqMMpyIkOZw9Ca18Qbwd/RRhnfoUABRwdI3IESkQFZxB4bAdvV0YJQwkDAx9+bWcECQYGCQ5vFEQCEQoKC0ILHqUDBncCGA5LBiHCAAsFtgqoQwS8Aw64f8m2EXdFCxO8INPKomQCBgPMWAvL0n/ff+jYAu7vAuxy8O/myvfX8/f7/Arq+v0W0HMnr9zAeE0KJlQkJIGCfE0E+PtDq9qfDMogDkGmrIBCbNQUZIDosNq1kUsEZJBW0dY/b0ZsLViQIMFMW+RKKgjFzp4fNokPIdki+Y8JNVxA79jKwHAI0G9JGw5tCqDWTiFRhVhtmhVA16cMJTJ1OnVIMo1cy1KVI5NhEAAh+QQACgACACwAAAAAIAAgAAAG/0CAcEgkChqNQnHJJCYWRMfh4CgamkzFwBOdVocNCgNbJAwGhKGUOjRQKA1y8XOGAtZfgIWiSciJBWcTQnhCD28Qf0UgZwJ3XgAJGhQVcgKORmdXhRBvV0QMY0ILCgoRmIRnCQIODgIEbxtEJSMdHZ8AGaUKBXYLIEpFExZpAG62HRRFArsKfn8FIsgjiUwJu8FkJLYcB9lMCwUKqFgGHSJ5cnZ/uEULl/CX63/x8KTNu+RkzPj9zc/0/Cl4V0/APDIE6x0csrBJwybX9DFhBhCLgAilIvzRVUriKHGlev0JtyuDvmsZUZlcIiCDnYu7KsZ0UmrBggRP7n1DqcDJEzciOgHwcwTyZEUmIKEMFVIqgyIjpZ4tjdTxqRCMPYVMBYDV6tavUZ8yczpkKwBxHsVWtaqo5tMgACH5BAAKAAMALAAAAAAgACAAAAb/QIBwSCQuBgNBcck0FgvIQtHRZCYUGSJ0IB2WDo9qUaBQKIXbLsBxOJTExUh5mB4iDo0zXEhWJNBRQgZtA3tPZQsAdQINBwxwAnpCC2VSdQNtVEQSEkOUChGSVwoLCwUFpm0QRAMVFBQTQxllCqh0kkIECF0TG68UG2O0foYJDb8VYVa0alUXrxoQf1WmZnsTFA0EhgCJhrFMC5Hjkd57W0jpDsPDuFUDHfHyHRzstNN78PPxHOLk5dwcpBuoaYk5OAfhXHG3hAy+KgLkgNozqwzDbgWYJQyXsUwGXKNA6fnYMIO3iPeIpBwyqlSCBKUqEQk5E6YRmX2UdAT5kEnHKkQ5hXjkNqTPtKAARl1sIrGoxSFNuSEFMNWoVCxEpiqyRlQY165wEHELAgAh+QQACgAEACwAAAAAIAAgAAAG/0CAcEgsKhSLonJJTBIFR0GxwFwmFJlnlAgaTKpFqEIqFJMBhcEABC5GjkPz0KN2tsvHBH4sJKgdd1NHSXILah9tAmdCC0dUcg5qVEQfiIxHEYtXSACKnWoGXAwHBwRDGUcKBXYFi0IJHmQEEKQHEGGpCnp3AiW1DKFWqZNgGKQNA65FCwV8bQQHJcRtds9MC4rZitVgCQbf4AYEubnKTAYU6eoUGuSpu3fo6+ka2NrbgQAE4eCmS9xVAOW7Yq7IgA4Hpi0R8EZBhDshOnTgcOtfM0cAlTigILFDiAFFNjk8k0GZgAxOBozouIHIOyKbFixIkECmIyIHOEiEWbPJTTQ5FxcVOMCgzUVCWwAcyZJvzy45ADYVZNIwTlIAVfNB7XRVDLxEWLQ4E9JsKq+rTdsMyhcEACH5BAAKAAUALAAAAAAgACAAAAb/QIBwSCwqFIuicklMEgVHQVHKVCYUmWeUWFAkqtOtEKqgAsgFcDFyHJLNmbZa6x2Lyd8595h8C48RagJmQgtHaX5XZUYKQ4YKEYSKfVKPaUMZHwMDeQBxh04ABYSFGU4JBpsDBmFHdXMLIKofBEyKCpdgspsOoUsLXaRLCQMgwky+YJ1FC4POg8lVAg7U1Q5drtnHSw4H3t8HDdnZy2Dd4N4Nzc/QeqLW1bnM7rXuV9tEBhQQ5UoCbJDmWKBAQcMDZNhwRVNCYANBChZYEbkVCZOwASEcCDFQ4SEDIq6WTVqQIMECBx06iCACQQPBiSabHDqzRUTKARMhSFCDrc+WNQIcOoRw5+ZIHj8ADqSEQBQAwKKLhIzowEEeGKQ0owIYkPKjHihZoBKi0KFE01b4zg7h4y4IACH5BAAKAAYALAAAAAAgACAAAAb/QIBwSCwqFIuicklMEgVHQVHKVCYUmWeUWFAkqtOtEKqgAsgFcDFyHJLNmbZa6x2Lyd8595h8C48RagJmQgtHaX5XZUUJeQCGChGEin1SkGlubEhDcYdOAAWEhRlOC12HYUd1eqeRokOKCphgrY5MpotqhgWfunqPt4PCg71gpgXIyWSqqq9MBQPR0tHMzM5L0NPSC8PCxVUCyeLX38+/AFfXRA4HA+pjmoFqCAcHDQa3rbxzBRD1BwgcMFIlidMrAxYICHHA4N8DIqpsUWJ3wAEBChQaEBnQoB6RRr0uARjQocMAAA0w4nMz4IOaU0lImkSngYKFc3ZWyTwJAALGK4fnNA3ZOaQCBQ22wPgRQlSIAYwSfkHJMrQkTyEbKFzFydQq15ccOAjUEwQAIfkEAAoABwAsAAAAACAAIAAABv9AgHBILCoUi6JySUwSBUdBUcpUJhSZZ5RYUCSq060QqqACyAVwMXIcks2ZtlrrHYvJ3zn3mHwLjxFqAmZCC0dpfldlRQl5AIYKEYSKfVKQaW5sSENxh04ABYSFGU4LXYdhR3V6p5GiQ4oKmGCtjkymi2qGBZ+6eo+3g8KDvYLDxKrJuXNkys6qr0zNygvHxL/V1sVD29K/AFfRRQUDDt1PmoFqHgPtBLetvMwG7QMes0KxkkIFIQNKDhBgKvCh3gQiqmxt6NDBAAEIEAgUOHCgBBEH9Yg06uWAIQUABihQMACgBEUHTRwoUEOBIcqQI880OIDgm5ABDA8IgUkSwAAyij1/jejAARPPIQwONBCnBAJDCEOOCnFA8cOvEh1CEJEqBMIBEDaLcA3LJIEGDe/0BAEAIfkEAAoACAAsAAAAACAAIAAABv9AgHBILCoUi6JySUwSBUdBUcpUJhSZZ5RYUCSq060QqqACyAVwMXIcks2ZtlrrHYvJ3zn3mHwLjxFqAmZCC0dpfldlRQl5AIYKEYSKfVKQaW5sSENxh04ABYSFGU4LXYdhR3V6p5GiQ4oKmGCtjkymi2qGBZ+6eo+3g8KDvYLDxKrJuXNkys6qr0zNygvHxL/V1sVDDti/BQccA8yrYBAjHR0jc53LRQYU6R0UBnO4RxmiG/IjJUIJFuoVKeCBigBN5QCk43BgFgMKFCYUGDAgFEUQRGIRYbCh2xACEDcAcHDgQDcQFGf9s7VkA0QCI0t2W0DRw68h8ChAEELSJE8xijBvVqCgIU9PjwA+UNzG5AHEB9xkDpk4QMGvARQsEDlKxMCALDeLcA0rqEEDlWCCAAAh+QQACgAJACwAAAAAIAAgAAAG/0CAcEgsKhSLonJJTBIFR0FRylQmFJlnlFhQJKrTrRCqoALIBXAxchySzZm2Wusdi8nfOfeYfAuPEWoCZkILR2l+V2VFCXkAhgoRhIp9UpBpbmxIQ3GHTgAFhIUZTgtdh2FHdXqnkaJDigqYYK2OTKaLaoYFn7p6j0wOA8PEAw6/Z4PKUhwdzs8dEL9kqqrN0M7SetTVCsLFw8d6C8vKvUQEv+dVCRAaBnNQtkwPFRQUFXOduUoTG/cUNkyYg+tIBlEMAFYYMAaBuCekxmhaJeSeBgiOHhw4QECAAwcCLhGJRUQCg3RDCmyUVmBYmlOiGqmBsPGlyz9YkAlxsJEhqCubABS9AsPgQAMqLQfM0oTMwEZ4QpLOwvMLxAEEXIBG5aczqtaut4YNXRIEACH5BAAKAAoALAAAAAAgACAAAAb/QIBwSCwqFIuicklMEgVHQVHKVCYUmWeUWFAkqtOtEKqgAsgFcDFyHJLNmbZa6x2Lyd8595h8C48RahAQRQtHaX5XZUUJeQAGHR0jA0SKfVKGCmlubEhCBSGRHSQOQwVmQwsZTgtdh0UQHKIHm2quChGophuiJHO3jkwOFB2UaoYFTnMGegDKRQQG0tMGBM1nAtnaABoU3t8UD81kR+UK3eDe4nrk5grR1NLWegva9s9czfhVAgMNpWqgBGNigMGBAwzmxBGjhACEgwcgzAPTqlwGXQ8gMgAhZIGHWm5WjelUZ8jBBgPMTBgwIMGCRgsygVSkgMiHByD7DWDmx5WuMkZqDLCU4gfAq2sACrAEWFSRLjUfWDopCqDTNQIsJ1LF0yzDAA90UHV5eo0qUjB8mgUBACH5BAAKAAsALAAAAAAgACAAAAb/QIBwSCwqFIuickk0FIiCo6A4ZSoZnRBUSiwoEtYipNOBDKOKKgD9DBNHHU4brc4c3cUBeSOk949geEQUZA5rXABHEW4PD0UOZBSHaQAJiEMJgQATFBQVBkQHZKACUwtHbX0RR0mVFp0UFwRCBSQDSgsZrQteqEUPGrAQmmG9ChFqRAkMsBd4xsRLBBsUoG6nBa14E4IA2kUFDuLjDql4peilAA0H7e4H1udH8/Ps7+3xbmj0qOTj5mEWpEP3DUq3glYWOBgAcEmUaNI+DBjwAY+dS0USGJg4wABEXMYyJNvE8UOGISKVCNClah4xjg60WUKyINOCUwrMzVRARMGENWQ4n/jpNTKTm15J/CTK2e0MoD+UKmHEs4onVDVVmyqdpAbNR4cKTjqNSots07EjzzJh1S0IADsAAAAAAAAAAAA=) center center no-repeat}@font-face{ ._2DDgw{font-family:"slick";src:url(data:application/vnd.ms-fontobject;base64,AAgAAGQHAAABAAIAAAAAAAIABQkAAAAAAAABAJABAAAAAExQAQAAgCAAAAAAAAAAAAAAAAEAAAAAAAAATxDE8AAAAAAAAAAAAAAAAAAAAAAAAAoAcwBsAGkAYwBrAAAADgBSAGUAZwB1AGwAYQByAAAAFgBWAGUAcgBzAGkAbwBuACAAMQAuADAAAAAKAHMAbABpAGMAawAAAAAAAAEAAAANAIAAAwBQRkZUTW3RyK8AAAdIAAAAHEdERUYANAAGAAAHKAAAACBPUy8yT/b9sgAAAVgAAABWY21hcCIPRb0AAAHIAAABYmdhc3D//wADAAAHIAAAAAhnbHlmP5u2YAAAAzwAAAIsaGVhZAABMfsAAADcAAAANmhoZWED5QIFAAABFAAAACRobXR4BkoASgAAAbAAAAAWbG9jYQD2AaIAAAMsAAAAEG1heHAASwBHAAABOAAAACBuYW1lBSeBwgAABWgAAAFucG9zdC+zMgMAAAbYAAAARQABAAAAAQAA8MQQT18PPPUACwIAAAAAAM9xeH8AAAAAz3F4fwAlACUB2wHbAAAACAACAAAAAAAAAAEAAAHbAAAALgIAAAAAAAHbAAEAAAAAAAAAAAAAAAAAAAAEAAEAAAAHAEQAAgAAAAAAAgAAAAEAAQAAAEAAAAAAAAAAAQIAAZAABQAIAUwBZgAAAEcBTAFmAAAA9QAZAIQAAAIABQkAAAAAAACAAAABAAAAIAAAAAAAAAAAUGZFZABAAGEhkgHg/+AALgHb/9sAAAABAAAAAAAAAgAAAAAAAAACAAAAAgAAJQAlACUAJQAAAAAAAwAAAAMAAAAcAAEAAAAAAFwAAwABAAAAHAAEAEAAAAAMAAgAAgAEAAAAYSAiIZAhkv//AAAAAABhICIhkCGS//8AAP+l3+PedN5xAAEAAAAAAAAAAAAAAAAAAAEGAAABAAAAAAAAAAECAAAAAgAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGAIwAsAEWAAIAJQAlAdsB2wAYACwAAD8BNjQvASYjIg8BBhUUHwEHBhUUHwEWMzI2FAcGBwYiJyYnJjQ3Njc2MhcWF/GCBgaCBQcIBR0GBldXBgYdBQgH7x0eMjB8MDIeHR0eMjB8MDIecYIGDgaCBQUeBQcJBFhYBAkHBR4F0nwwMh4dHR4yMHwwMh4dHR4yAAAAAgAlACUB2wHbABgALAAAJTc2NTQvATc2NTQvASYjIg8BBhQfARYzMjYUBwYHBiInJicmNDc2NzYyFxYXASgdBgZXVwYGHQUIBwWCBgaCBQcIuB0eMjB8MDIeHR0eMjB8MDIecR4FBwkEWFgECQcFHgUFggYOBoIF0nwwMh4dHR4yMHwwMh4dHR4yAAABACUAJQHbAdsAEwAAABQHBgcGIicmJyY0NzY3NjIXFhcB2x0eMjB8MDIeHR0eMjB8MDIeAT58MDIeHR0eMjB8MDIeHR0eMgABACUAJQHbAdsAQwAAARUUBisBIicmPwEmIyIHBgcGBwYUFxYXFhcWMzI3Njc2MzIfARYVFAcGBwYjIicmJyYnJjQ3Njc2NzYzMhcWFzc2FxYB2woIgAsGBQkoKjodHBwSFAwLCwwUEhwcHSIeIBMGAQQDJwMCISspNC8mLBobFBERFBsaLCYvKicpHSUIDAsBt4AICgsLCScnCwwUEhwcOhwcEhQMCw8OHAMDJwMDAgQnFBQRFBsaLCZeJiwaGxQRDxEcJQgEBgAAAAAAAAwAlgABAAAAAAABAAUADAABAAAAAAACAAcAIgABAAAAAAADACEAbgABAAAAAAAEAAUAnAABAAAAAAAFAAsAugABAAAAAAAGAAUA0gADAAEECQABAAoAAAADAAEECQACAA4AEgADAAEECQADAEIAKgADAAEECQAEAAoAkAADAAEECQAFABYAogADAAEECQAGAAoAxgBzAGwAaQBjAGsAAHNsaWNrAABSAGUAZwB1AGwAYQByAABSZWd1bGFyAABGAG8AbgB0AEYAbwByAGcAZQAgADIALgAwACAAOgAgAHMAbABpAGMAawAgADoAIAAxADQALQA0AC0AMgAwADEANAAARm9udEZvcmdlIDIuMCA6IHNsaWNrIDogMTQtNC0yMDE0AABzAGwAaQBjAGsAAHNsaWNrAABWAGUAcgBzAGkAbwBuACAAMQAuADAAAFZlcnNpb24gMS4wAABzAGwAaQBjAGsAAHNsaWNrAAAAAAIAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAABwAAAAEAAgECAQMAhwBECmFycm93cmlnaHQJYXJyb3dsZWZ0AAAAAAAAAf//AAIAAQAAAA4AAAAYAAAAAAACAAEAAwAGAAEABAAAAAIAAAAAAAEAAAAAzu7XsAAAAADPcXh/AAAAAM9xeH8=);src:url(data:application/vnd.ms-fontobject;base64,AAgAAGQHAAABAAIAAAAAAAIABQkAAAAAAAABAJABAAAAAExQAQAAgCAAAAAAAAAAAAAAAAEAAAAAAAAATxDE8AAAAAAAAAAAAAAAAAAAAAAAAAoAcwBsAGkAYwBrAAAADgBSAGUAZwB1AGwAYQByAAAAFgBWAGUAcgBzAGkAbwBuACAAMQAuADAAAAAKAHMAbABpAGMAawAAAAAAAAEAAAANAIAAAwBQRkZUTW3RyK8AAAdIAAAAHEdERUYANAAGAAAHKAAAACBPUy8yT/b9sgAAAVgAAABWY21hcCIPRb0AAAHIAAABYmdhc3D//wADAAAHIAAAAAhnbHlmP5u2YAAAAzwAAAIsaGVhZAABMfsAAADcAAAANmhoZWED5QIFAAABFAAAACRobXR4BkoASgAAAbAAAAAWbG9jYQD2AaIAAAMsAAAAEG1heHAASwBHAAABOAAAACBuYW1lBSeBwgAABWgAAAFucG9zdC+zMgMAAAbYAAAARQABAAAAAQAA8MQQT18PPPUACwIAAAAAAM9xeH8AAAAAz3F4fwAlACUB2wHbAAAACAACAAAAAAAAAAEAAAHbAAAALgIAAAAAAAHbAAEAAAAAAAAAAAAAAAAAAAAEAAEAAAAHAEQAAgAAAAAAAgAAAAEAAQAAAEAAAAAAAAAAAQIAAZAABQAIAUwBZgAAAEcBTAFmAAAA9QAZAIQAAAIABQkAAAAAAACAAAABAAAAIAAAAAAAAAAAUGZFZABAAGEhkgHg/+AALgHb/9sAAAABAAAAAAAAAgAAAAAAAAACAAAAAgAAJQAlACUAJQAAAAAAAwAAAAMAAAAcAAEAAAAAAFwAAwABAAAAHAAEAEAAAAAMAAgAAgAEAAAAYSAiIZAhkv//AAAAAABhICIhkCGS//8AAP+l3+PedN5xAAEAAAAAAAAAAAAAAAAAAAEGAAABAAAAAAAAAAECAAAAAgAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGAIwAsAEWAAIAJQAlAdsB2wAYACwAAD8BNjQvASYjIg8BBhUUHwEHBhUUHwEWMzI2FAcGBwYiJyYnJjQ3Njc2MhcWF/GCBgaCBQcIBR0GBldXBgYdBQgH7x0eMjB8MDIeHR0eMjB8MDIecYIGDgaCBQUeBQcJBFhYBAkHBR4F0nwwMh4dHR4yMHwwMh4dHR4yAAAAAgAlACUB2wHbABgALAAAJTc2NTQvATc2NTQvASYjIg8BBhQfARYzMjYUBwYHBiInJicmNDc2NzYyFxYXASgdBgZXVwYGHQUIBwWCBgaCBQcIuB0eMjB8MDIeHR0eMjB8MDIecR4FBwkEWFgECQcFHgUFggYOBoIF0nwwMh4dHR4yMHwwMh4dHR4yAAABACUAJQHbAdsAEwAAABQHBgcGIicmJyY0NzY3NjIXFhcB2x0eMjB8MDIeHR0eMjB8MDIeAT58MDIeHR0eMjB8MDIeHR0eMgABACUAJQHbAdsAQwAAARUUBisBIicmPwEmIyIHBgcGBwYUFxYXFhcWMzI3Njc2MzIfARYVFAcGBwYjIicmJyYnJjQ3Njc2NzYzMhcWFzc2FxYB2woIgAsGBQkoKjodHBwSFAwLCwwUEhwcHSIeIBMGAQQDJwMCISspNC8mLBobFBERFBsaLCYvKicpHSUIDAsBt4AICgsLCScnCwwUEhwcOhwcEhQMCw8OHAMDJwMDAgQnFBQRFBsaLCZeJiwaGxQRDxEcJQgEBgAAAAAAAAwAlgABAAAAAAABAAUADAABAAAAAAACAAcAIgABAAAAAAADACEAbgABAAAAAAAEAAUAnAABAAAAAAAFAAsAugABAAAAAAAGAAUA0gADAAEECQABAAoAAAADAAEECQACAA4AEgADAAEECQADAEIAKgADAAEECQAEAAoAkAADAAEECQAFABYAogADAAEECQAGAAoAxgBzAGwAaQBjAGsAAHNsaWNrAABSAGUAZwB1AGwAYQByAABSZWd1bGFyAABGAG8AbgB0AEYAbwByAGcAZQAgADIALgAwACAAOgAgAHMAbABpAGMAawAgADoAIAAxADQALQA0AC0AMgAwADEANAAARm9udEZvcmdlIDIuMCA6IHNsaWNrIDogMTQtNC0yMDE0AABzAGwAaQBjAGsAAHNsaWNrAABWAGUAcgBzAGkAbwBuACAAMQAuADAAAFZlcnNpb24gMS4wAABzAGwAaQBjAGsAAHNsaWNrAAAAAAIAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAABwAAAAEAAgECAQMAhwBECmFycm93cmlnaHQJYXJyb3dsZWZ0AAAAAAAAAf//AAIAAQAAAA4AAAAYAAAAAAACAAEAAwAGAAEABAAAAAIAAAAAAAEAAAAAzu7XsAAAAADPcXh/AAAAAM9xeH8=) format("embedded-opentype"),url(data:font/woff;base64,d09GRk9UVE8AAAVkAAsAAAAAB1wAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABDRkYgAAABCAAAAi4AAAKbH/pWDkZGVE0AAAM4AAAAGgAAABxt0civR0RFRgAAA1QAAAAcAAAAIAAyAARPUy8yAAADcAAAAFIAAABgUBj/rmNtYXAAAAPEAAAAUAAAAWIiC0SwaGVhZAAABBQAAAAuAAAANgABMftoaGVhAAAERAAAABwAAAAkA+UCA2htdHgAAARgAAAADgAAAA4ESgBKbWF4cAAABHAAAAAGAAAABgAFUABuYW1lAAAEeAAAANwAAAFuBSeBwnBvc3QAAAVUAAAAEAAAACAAAwABeJw9ks9vEkEUx2cpWyeUoFYgNkHi2Wt7N3rVm3cTs3UVLC4LxIWEQvi1P3i7O1tYLJDAmlgKGEhQrsajf0j7J3jYTXrQWUrMJG+++b55n5e8NwwKBhHDMLv5kxT3ATEBxKBn3qOAl9zxHgb1MAPhHQgHkyF08Gr/L8B/Eb6zWnmCJ7AJVLubQOheArXvJ1A4EXi6j4I+Zg9F0QFKvsnlBCmXeve+sFEnb/nCptdtQ4QYhVFRAT1HrF8UQK/RL/SbmUbclsvGVFXRZKDHUE38cc4qpkbAAsuwiImvro+ufcfaOIQ6szlrmjRJDaKZKnbjN3GWKIbiIzRFUfCffuxxKOL+3LDlDVvx2TdxN84qZEsnhNBa6pgm2dAsnzbLsETdsmRFxUeHV4e+I2/ptN8TyqV8T3Dt29t7EYOuajVIw2y1Wy3M86w0zg/Fz2IvawmQAUHOVrPVfLkoScVynsqsTG0MGUs4z55nh3mnOJa+li+rl9WpPIcFfDubDeaDC+fLBdYN3QADzLauGfj4B6sZmq6CCpqmtSvF0qlUl2qf5AJIUCSlTqlb7lUG+LRfGzZGzZEyBgccMu6MuqPecNDvD4Y9Kjtj4gD+DsvKVMTcMdtqtZtmkzQstQvYje7Syep0PDSAhSOeHYXYWThEF//A/0YvYV1fSQtpKU5STtrhbQ444OtpKSWJIg3pOg8cBs7maTY1EZf07aq+hjWs7IWzdCYTGhb2CtZ47x+Uhx28AAB4nGNgYGBkAIJz765vANHnCyvqYTQAWnkHswAAeJxjYGRgYOADYgkGEGBiYARCFjAG8RgABHYAN3icY2BmYmCcwMDKwMHow5jGwMDgDqW/MkgytDAwMDGwcjKAQQMDAyOQUmCAgoA01xQGB4ZExUmMD/4/YNBjvP3/NgNEDQPjbbBKBQZGADfLDgsAAHicY2BgYGaAYBkGRgYQiAHyGMF8FgYHIM3DwMHABGQzMCQqKClOUJz0/z9YHRLv/+L7D+8V3cuHmgAHjGwM6ELUByxUMIOZCmbgAAA5LQ8XeJxjYGRgYABiO68w73h+m68M3EwMIHC+sKIeTqsyqDLeZrwN5HIwgKUB/aYJUgAAeJxjYGRgYLzNwMCgx8QAAkA2IwMqYAIAMGIB7QIAAAACAAAlACUAJQAlAAAAAFAAAAUAAHicbY49asNAEIU/2ZJDfkiRIvXapUFCEqpcptABUrg3ZhEiQoKVfY9UqVLlGDlADpAT5e16IUWysMz3hjfzBrjjjQT/EjKpCy+4YhN5yZoxcirPe+SMWz4jr6S+5UzSa3VuwpTnBfc8RF7yxDZyKs9r5IxHPiKv1P9iZqDnyAvMQ39UecbScVb/gJO03Xk4CFom3XYK1clhMdQUlKo7/d9NF13RkIdfy+MV7TSe2sl11tRFaXYmJKpWTd7kdVnJ8veevZKc+n3I93t9Jnvr5n4aTVWU/0z9AI2qMkV4nGNgZkAGjAxoAAAAjgAF) format("woff"),url(data:font/ttf;base64,AAEAAAANAIAAAwBQRkZUTW3RyK8AAAdIAAAAHEdERUYANAAGAAAHKAAAACBPUy8yT/b9sgAAAVgAAABWY21hcCIPRb0AAAHIAAABYmdhc3D//wADAAAHIAAAAAhnbHlmP5u2YAAAAzwAAAIsaGVhZAABMfsAAADcAAAANmhoZWED5QIFAAABFAAAACRobXR4BkoASgAAAbAAAAAWbG9jYQD2AaIAAAMsAAAAEG1heHAASwBHAAABOAAAACBuYW1lBSeBwgAABWgAAAFucG9zdC+zMgMAAAbYAAAARQABAAAAAQAA8MQQT18PPPUACwIAAAAAAM9xeH8AAAAAz3F4fwAlACUB2wHbAAAACAACAAAAAAAAAAEAAAHbAAAALgIAAAAAAAHbAAEAAAAAAAAAAAAAAAAAAAAEAAEAAAAHAEQAAgAAAAAAAgAAAAEAAQAAAEAAAAAAAAAAAQIAAZAABQAIAUwBZgAAAEcBTAFmAAAA9QAZAIQAAAIABQkAAAAAAACAAAABAAAAIAAAAAAAAAAAUGZFZABAAGEhkgHg/+AALgHb/9sAAAABAAAAAAAAAgAAAAAAAAACAAAAAgAAJQAlACUAJQAAAAAAAwAAAAMAAAAcAAEAAAAAAFwAAwABAAAAHAAEAEAAAAAMAAgAAgAEAAAAYSAiIZAhkv//AAAAAABhICIhkCGS//8AAP+l3+PedN5xAAEAAAAAAAAAAAAAAAAAAAEGAAABAAAAAAAAAAECAAAAAgAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGAIwAsAEWAAIAJQAlAdsB2wAYACwAAD8BNjQvASYjIg8BBhUUHwEHBhUUHwEWMzI2FAcGBwYiJyYnJjQ3Njc2MhcWF/GCBgaCBQcIBR0GBldXBgYdBQgH7x0eMjB8MDIeHR0eMjB8MDIecYIGDgaCBQUeBQcJBFhYBAkHBR4F0nwwMh4dHR4yMHwwMh4dHR4yAAAAAgAlACUB2wHbABgALAAAJTc2NTQvATc2NTQvASYjIg8BBhQfARYzMjYUBwYHBiInJicmNDc2NzYyFxYXASgdBgZXVwYGHQUIBwWCBgaCBQcIuB0eMjB8MDIeHR0eMjB8MDIecR4FBwkEWFgECQcFHgUFggYOBoIF0nwwMh4dHR4yMHwwMh4dHR4yAAABACUAJQHbAdsAEwAAABQHBgcGIicmJyY0NzY3NjIXFhcB2x0eMjB8MDIeHR0eMjB8MDIeAT58MDIeHR0eMjB8MDIeHR0eMgABACUAJQHbAdsAQwAAARUUBisBIicmPwEmIyIHBgcGBwYUFxYXFhcWMzI3Njc2MzIfARYVFAcGBwYjIicmJyYnJjQ3Njc2NzYzMhcWFzc2FxYB2woIgAsGBQkoKjodHBwSFAwLCwwUEhwcHSIeIBMGAQQDJwMCISspNC8mLBobFBERFBsaLCYvKicpHSUIDAsBt4AICgsLCScnCwwUEhwcOhwcEhQMCw8OHAMDJwMDAgQnFBQRFBsaLCZeJiwaGxQRDxEcJQgEBgAAAAAAAAwAlgABAAAAAAABAAUADAABAAAAAAACAAcAIgABAAAAAAADACEAbgABAAAAAAAEAAUAnAABAAAAAAAFAAsAugABAAAAAAAGAAUA0gADAAEECQABAAoAAAADAAEECQACAA4AEgADAAEECQADAEIAKgADAAEECQAEAAoAkAADAAEECQAFABYAogADAAEECQAGAAoAxgBzAGwAaQBjAGsAAHNsaWNrAABSAGUAZwB1AGwAYQByAABSZWd1bGFyAABGAG8AbgB0AEYAbwByAGcAZQAgADIALgAwACAAOgAgAHMAbABpAGMAawAgADoAIAAxADQALQA0AC0AMgAwADEANAAARm9udEZvcmdlIDIuMCA6IHNsaWNrIDogMTQtNC0yMDE0AABzAGwAaQBjAGsAAHNsaWNrAABWAGUAcgBzAGkAbwBuACAAMQAuADAAAFZlcnNpb24gMS4wAABzAGwAaQBjAGsAAHNsaWNrAAAAAAIAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAABwAAAAEAAgECAQMAhwBECmFycm93cmlnaHQJYXJyb3dsZWZ0AAAAAAAAAf//AAIAAQAAAA4AAAAYAAAAAAACAAEAAwAGAAEABAAAAAIAAAAAAAEAAAAAzu7XsAAAAADPcXh/AAAAAM9xeH8=) format("truetype"),url("data:image/svg+xml,%3C?xml version='1.0' standalone='no'?%3E %3C!DOCTYPE svg PUBLIC '-//W3C//DTD SVG 1.1//EN' 'http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd'%3E %3Csvg xmlns='http://www.w3.org/2000/svg'%3E %3Cmetadata%3EGenerated by Fontastic.me%3C/metadata%3E %3Cdefs%3E %3Cfont id='slick' horiz-adv-x='512'%3E %3Cfont-face font-family='slick' units-per-em='512' ascent='480' descent='-32'/%3E %3Cmissing-glyph horiz-adv-x='512' /%3E %3Cglyph unicode='&%238594;' d='M241 113l130 130c4 4 6 8 6 13 0 5-2 9-6 13l-130 130c-3 3-7 5-12 5-5 0-10-2-13-5l-29-30c-4-3-6-7-6-12 0-5 2-10 6-13l87-88-87-88c-4-3-6-8-6-13 0-5 2-9 6-12l29-30c3-3 8-5 13-5 5 0 9 2 12 5z m234 143c0-40-9-77-29-110-20-34-46-60-80-80-33-20-70-29-110-29-40 0-77 9-110 29-34 20-60 46-80 80-20 33-29 70-29 110 0 40 9 77 29 110 20 34 46 60 80 80 33 20 70 29 110 29 40 0 77-9 110-29 34-20 60-46 80-80 20-33 29-70 29-110z'/%3E %3Cglyph unicode='&%238592;' d='M296 113l29 30c4 3 6 7 6 12 0 5-2 10-6 13l-87 88 87 88c4 3 6 8 6 13 0 5-2 9-6 12l-29 30c-3 3-8 5-13 5-5 0-9-2-12-5l-130-130c-4-4-6-8-6-13 0-5 2-9 6-13l130-130c3-3 7-5 12-5 5 0 10 2 13 5z m179 143c0-40-9-77-29-110-20-34-46-60-80-80-33-20-70-29-110-29-40 0-77 9-110 29-34 20-60 46-80 80-20 33-29 70-29 110 0 40 9 77 29 110 20 34 46 60 80 80 33 20 70 29 110 29 40 0 77-9 110-29 34-20 60-46 80-80 20-33 29-70 29-110z'/%3E %3Cglyph unicode='&%238226;' d='M475 256c0-40-9-77-29-110-20-34-46-60-80-80-33-20-70-29-110-29-40 0-77 9-110 29-34 20-60 46-80 80-20 33-29 70-29 110 0 40 9 77 29 110 20 34 46 60 80 80 33 20 70 29 110 29 40 0 77-9 110-29 34-20 60-46 80-80 20-33 29-70 29-110z'/%3E %3Cglyph unicode='&%2397;' d='M475 439l0-128c0-5-1-9-5-13-4-4-8-5-13-5l-128 0c-8 0-13 3-17 11-3 7-2 14 4 20l40 39c-28 26-62 39-100 39-20 0-39-4-57-11-18-8-33-18-46-32-14-13-24-28-32-46-7-18-11-37-11-57 0-20 4-39 11-57 8-18 18-33 32-46 13-14 28-24 46-32 18-7 37-11 57-11 23 0 44 5 64 15 20 9 38 23 51 42 2 1 4 3 7 3 3 0 5-1 7-3l39-39c2-2 3-3 3-6 0-2-1-4-2-6-21-25-46-45-76-59-29-14-60-20-93-20-30 0-58 5-85 17-27 12-51 27-70 47-20 19-35 43-47 70-12 27-17 55-17 85 0 30 5 58 17 85 12 27 27 51 47 70 19 20 43 35 70 47 27 12 55 17 85 17 28 0 55-5 81-15 26-11 50-26 70-45l37 37c6 6 12 7 20 4 8-4 11-9 11-17z'/%3E %3C/font%3E%3C/defs%3E%3C/svg%3E") format("svg");font-weight:normal;font-style:normal}} ._2DDgw .slick-prev, ._2DDgw .slick-next{position:absolute;display:block;height:20px;width:20px;line-height:0px;font-size:0px;cursor:pointer;background:transparent;color:transparent;top:50%;transform:translate(0, -50%);padding:0;border:none;outline:none} ._2DDgw .slick-prev:hover, ._2DDgw .slick-prev:focus, ._2DDgw .slick-next:hover, ._2DDgw .slick-next:focus{outline:none;background:transparent;color:transparent} ._2DDgw .slick-prev:hover:before, ._2DDgw .slick-prev:focus:before, ._2DDgw .slick-next:hover:before, ._2DDgw .slick-next:focus:before{opacity:1} ._2DDgw .slick-prev.slick-disabled:before, ._2DDgw .slick-next.slick-disabled:before{opacity:.25} ._2DDgw .slick-prev:before, ._2DDgw .slick-next:before{font-family:"slick";font-size:20px;line-height:1;color:#fff;opacity:.75;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale} ._2DDgw .slick-prev{left:-25px} [dir="rtl"] ._2DDgw .slick-prev{left:auto;right:-25px} ._2DDgw .slick-prev:before{content:"←"} [dir="rtl"] ._2DDgw .slick-prev:before{content:"→"} ._2DDgw .slick-next{right:-25px} [dir="rtl"] ._2DDgw .slick-next{left:-25px;right:auto} ._2DDgw .slick-next:before{content:"→"} [dir="rtl"] ._2DDgw .slick-next:before{content:"←"} ._2DDgw .slick-dotted.slick-slider{margin-bottom:30px} ._2DDgw .slick-dots{position:absolute;bottom:-25px;list-style:none;display:block;text-align:center;padding:0;margin:0;width:100%} ._2DDgw .slick-dots li{position:relative;display:inline-block;height:20px;width:20px;margin:0 5px;padding:0;cursor:pointer} ._2DDgw .slick-dots li button{border:0;background:transparent;display:block;height:20px;width:20px;outline:none;line-height:0px;font-size:0px;color:transparent;padding:5px;cursor:pointer} ._2DDgw .slick-dots li button:hover, ._2DDgw .slick-dots li button:focus{outline:none} ._2DDgw .slick-dots li button:hover:before, ._2DDgw .slick-dots li button:focus:before{opacity:1} ._2DDgw .slick-dots li button:before{position:absolute;top:0;left:0;content:"•";width:20px;height:20px;font-family:"slick";font-size:6px;line-height:20px;text-align:center;color:#000;opacity:.25;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale} ._2DDgw .slick-dots li.slick-active button:before{color:#000;opacity:.75} ._2DDgw .slick-initialized .slick-slide{display:block} ._2DDgw .slick-loading .slick-slide{visibility:hidden} ._2DDgw .slick-vertical .slick-slide{display:block;height:auto;border:1px solid transparent} ._2DDgw .slick-track{margin-left:initial;margin-right:initial} ._3e4dm{margin:auto;position:relative;padding:0 30px;max-width:980px} ._3e4dm._15Cc8{max-width:initial} ._3e4dm._1gMVW{padding:0} ._1TkEo{height:100px;width:100px;padding:0;border-style:solid;border-width:1px;border-color:red;position:relative} ._1TkEo img{height:100%;width:100%} ._23Cb3{box-sizing:border-box;padding:2px 0;float:left} ._1TkEo{margin-right:1px} ._3OSaU{position:relative;border-color:blue} ._3OSaU:after{content:"";position:absolute;box-sizing:border-box;right:0;bottom:0;top:0;left:0;border-width:1px;border-style:solid;border-color:blue} ._1X4Gu{position:absolute;display:flex;flex-direction:column;justify-content:center} ._1X4Gu button>svg, ._1X4Gu button>svg>path{-webkit-filter:drop-shadow(0px 0px 1px #2c2c2c);filter:drop-shadow(0px 0px 1px #2c2c2c);stroke:#999;fill:#fff} ._1X4Gu{top:50%;transform:translateY(-50%);z-index:1} ._1X4Gu._3CHZl{left:4px} ._1X4Gu.AUCWC{right:4px}button._3JwT6{background-color:Transparent;background-repeat:no-repeat;border:none;cursor:pointer;overflow:hidden;outline:none;padding:0} ._3iXD8{position:absolute;top:50%;transform:translate(-50%, -50%);left:50%;color:#fff} .aM2rn .slick-slide{padding-top:3px;padding-bottom:3px} .aM2rn ._2cw7M{height:100%} .aM2rn .slick-track{display:flex} .aM2rn .slick-slide{height:initial} .aM2rn .slick-slide>div{height:100%} ._2c0wg{padding-bottom:36px}


 .Popover2659814081__root{position:relative;display:inline-block} .Popover2659814081__root.Popover2659814081--fluid{display:block} .Popover2659814081__popoverContent{background-color:#fff;border-width:1px;border-style:solid;border-color:#000;border-radius:initial;padding:initial} .Popover2659814081__arrow{width:0;height:0;border-style:solid;position:absolute;margin:5px} .Popover2659814081__popover[data-placement*=right].Popover2659814081__withArrow{padding-left:5px} .Popover2659814081__popover[data-placement*=right].Popover2659814081__withArrow .Popover2659814081__arrow{border-width:5px 5px 5px 0;left:-5px;margin-left:5px;margin-right:0;border-color:transparent #000 transparent transparent} .Popover2659814081__popover[data-placement*=left].Popover2659814081__withArrow{padding-right:5px} .Popover2659814081__popover[data-placement*=left].Popover2659814081__withArrow .Popover2659814081__arrow{border-width:5px 0 5px 5px;right:-5px;margin-left:0;margin-right:5px;border-color:transparent transparent transparent #000} .Popover2659814081__popover[data-placement*=bottom].Popover2659814081__withArrow{padding-top:5px} .Popover2659814081__popover[data-placement*=bottom].Popover2659814081__withArrow .Popover2659814081__arrow{border-width:0 5px 5px 5px;top:-5px;margin-top:5px;margin-bottom:0;border-color:transparent transparent #000 transparent} .Popover2659814081__popover[data-placement*=top].Popover2659814081__withArrow{padding-bottom:5px} .Popover2659814081__popover[data-placement*=top].Popover2659814081__withArrow .Popover2659814081__arrow{border-width:5px 5px 0 5px;bottom:-5px;margin-top:0;margin-bottom:5px;border-color:#000 transparent transparent transparent}
 .DropdownOption3183861959__root{cursor:pointer} .DropdownOption3183861959__root.DropdownOption3183861959--hovered{background-color:#d3d3d3} .DropdownOption3183861959__root.DropdownOption3183861959--disabled{cursor:default;background-color:#fff} .DropdownOption3183861959__root.DropdownOption3183861959--selected{background-color:gray} .DropdownOption3183861959__root.DropdownOption3183861959--selected.DropdownOption3183861959--hovered{background-color:#696969} .DropdownOption3183861959__root:not(.DropdownOption3183861959--selectable){cursor:default} .DropdownOption3183861959__highlight{background-color:transparent;font-weight:700}
 .Focusable1981311471__focus-box{outline:0} .Focusable1981311471__focus-box-error{outline:0}
 .RadioButton2325084521__root{display:inline-block} .RadioButton2325084521__icon{cursor:pointer;height:auto} .RadioButton2325084521__root.RadioButton2325084521--disabled{filter:grayscale(75%);opacity:.7} .RadioButton2325084521__hiddenRadio{position:absolute;overflow:hidden;height:1px;width:1px;margin:-1px;padding:0;border:0;opacity:0}
 .Divider364384534__root.Divider364384534--customDivider{reset:all} .Divider364384534__root:not(.Divider364384534--customDivider){height:1px;background-color:#000;opacity:initial;margin-top:initial;margin-bottom:initial} .Divider364384534__root.Divider364384534--vertical{height:auto;width:1px}
 .Input3499451569__root{position:relative}
 .Button3101146629__root{display:inline-flex;align-items:center;position:relative;outline:0}
 .DropdownContent3889653823__root{outline:0} .DropdownContent3889653823__optionsContainer{outline:0;overflow:auto;max-height:260px;position:relative}
 .buttonnext2552858610__root{display:inline-flex;align-items:center;cursor:pointer} .buttonnext2552858610__prefix{flex-shrink:0} .buttonnext2552858610__suffix{flex-shrink:0} .buttonnext2552858610__root.buttonnext2552858610--disabled{cursor:default} .buttonnext2552858610__root[disabled]{pointer-events:none}
 .Tooltip1846219381__root .Popover2659814081__popoverContent{overflow-wrap:break-word;word-wrap:break-word;word-break:break-word}
 .Dropdown2055179274__root .Popover2659814081__popover{min-width:100%}
 .Button429199724__root{min-width:100px;border-style:solid;box-sizing:content-box;border-radius:0;transition:background-color .2s ease-in-out,border-color .2s ease-in-out,color .2s ease-in-out} .Button429199724__root .buttonnext2552858610__content{margin:0 auto;text-overflow:ellipsis;white-space:nowrap;overflow:hidden} .Button429199724__root.Button429199724--fullWidth{width:100%;box-sizing:border-box} .Button429199724__root.Button429199724---size-4-tiny{padding:6px 16px} .Button429199724__root.Button429199724---size-5-small{padding:7px 16px} .Button429199724__root.Button429199724---size-6-medium{padding:8px 16px} .Button429199724__root.Button429199724--mobile.Button429199724---size-6-medium{padding:10px 16px} .Button429199724__root.Button429199724---size-5-large{padding:10px 16px} .Button429199724__root.Button429199724--upgrade .buttonnext2552858610__content{overflow:visible;text-overflow:unset;white-space:unset} .Button429199724__root.Button429199724--upgrade{box-sizing:border-box;line-height:1;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;display:inline-block} .Button429199724__root.Button429199724--mobile.Button429199724--upgrade{line-height:1} .Button429199724__root.Button429199724---size-4-tiny.Button429199724--upgrade{line-height:1} .Button429199724__root.Button429199724---size-5-small.Button429199724--upgrade:not(mobile){line-height:1} .Button429199724__root.Button429199724---size-6-medium.Button429199724--upgrade:not(mobile){line-height:1} .Button429199724__root.Button429199724---size-5-large.Button429199724--upgrade:not(mobile){line-height:1}
 .Tooltip758034538__root .Popover2659814081__popoverContent{background-color:#212121;padding:4px 12px;border:1px #757575 solid;border-radius:3px;color:#fff;line-height:20px;font-family:HelveticaNeueW01-45Ligh,HelveticaNeueW02-45Ligh,HelveticaNeueW10-45Ligh,Helvetica Neue,Helvetica,Arial,メイリオ,meiryo,ヒラギノ角ゴ pro w3,hiragino kaku gothic pro,sans-serif;font-size:14px;-webkit-font-smoothing:auto;box-shadow:0 4px 8px 0 rgba(0,0,0,.12),0 0 4px 0 rgba(0,0,0,.1)} .Tooltip758034538__tpaArrow{display:block;position:absolute;margin:0} .Tooltip758034538__tpaArrow svg{display:block} .Tooltip758034538__root .Popover2659814081__popover[data-placement*=top].Tooltip758034538__withArrow{padding-bottom:6px} .Tooltip758034538__root .Popover2659814081__popover[data-placement*=bottom].Tooltip758034538__withArrow{padding-top:6px} .Tooltip758034538__root .Popover2659814081__popover[data-placement*=left].Tooltip758034538__withArrow{padding-right:6px} .Tooltip758034538__root .Popover2659814081__popover[data-placement*=right].Tooltip758034538__withArrow{padding-left:6px} .Tooltip758034538__root .Popover2659814081__popover[data-placement*=top] .Tooltip758034538__tpaArrow{bottom:0;width:12px;height:7px} .Tooltip758034538__root .Popover2659814081__popover[data-placement*=bottom] .Tooltip758034538__tpaArrow{top:0;width:12px;height:7px} .Tooltip758034538__root .Popover2659814081__popover[data-placement*=left] .Tooltip758034538__tpaArrow{right:0;width:7px;height:12px} .Tooltip758034538__root .Popover2659814081__popover[data-placement*=right] .Tooltip758034538__tpaArrow{left:0;width:7px;height:12px} .Tooltip758034538__root .Popover2659814081__popover[data-placement*=top].Tooltip758034538__popoverAnimation-enter{opacity:0;transform:scale(.9) translateY(3px)} .Tooltip758034538__root .Popover2659814081__popover[data-placement*=bottom].Tooltip758034538__popoverAnimation-enter{opacity:0;transform:scale(.9) translateY(-3px)} .Tooltip758034538__root .Popover2659814081__popover[data-placement*=left].Tooltip758034538__popoverAnimation-enter{opacity:0;transform:scale(.9) translateX(10px)} .Tooltip758034538__root .Popover2659814081__popover[data-placement*=right].Tooltip758034538__popoverAnimation-enter{opacity:0;transform:scale(.9) translateX(-10px)} .Tooltip758034538__root .Popover2659814081__popover[data-placement].Tooltip758034538__popoverAnimation-enter.Tooltip758034538__popoverAnimation-enter-active{opacity:1;transition:transform 120ms cubic-bezier(.25,.46,.45,.94),applyOpacity 120ms cubic-bezier(.25,.46,.45,.94);transform:scale(1) translateY(0) translateX(0)} .Tooltip758034538__root .Popover2659814081__popover[data-placement].Tooltip758034538__popoverAnimation-exit{opacity:1;transform:scale(1) translateY(0) translateX(0)} .Tooltip758034538__root .Popover2659814081__popover[data-placement].Tooltip758034538__popoverAnimation-exit.Tooltip758034538__popoverAnimation-exit-active{opacity:0;transition:transform 80ms linear,applyOpacity 80ms linear} .Tooltip758034538__root.Tooltip758034538---skin-5-error .Popover2659814081__popoverContent{background-color:#f64d43;border:1px solid rgba(255,255,255,.25)} .Tooltip758034538__root.Tooltip758034538---skin-5-error .Tooltip758034538__tpaArrow path{fill:#f64d43}
 .ColorPickerItem3359370024__root *{box-sizing:border-box} .ColorPickerItem3359370024__radioOuter{display:flex;justify-content:center;align-items:center;margin:4px;transition:box-shadow .1s linear} .ColorPickerItem3359370024__radioInner{width:calc(100% - 2px);height:calc(100% - 2px);border:1px solid #c9c9c9}
 .DropdownBase4283233096__root{min-width:100px;border-style:solid;box-sizing:content-box;border-radius:0;transition:background-color .2s ease-in-out,border-color .2s ease-in-out,color .2s ease-in-out;display:flex;cursor:pointer;box-sizing:border-box;outline:0} .DropdownBase4283233096__root .buttonnext2552858610__content{margin:0 auto;text-overflow:ellipsis;white-space:nowrap;overflow:hidden} .DropdownBase4283233096__root.Button429199724--fullWidth{width:100%;box-sizing:border-box} .DropdownBase4283233096__root.Button429199724---size-4-tiny{padding:6px 16px} .DropdownBase4283233096__root.Button429199724---size-5-small{padding:7px 16px} .DropdownBase4283233096__root.Button429199724---size-6-medium{padding:8px 16px} .DropdownBase4283233096__root.Button429199724--mobile.Button429199724---size-6-medium{padding:10px 16px} .DropdownBase4283233096__root.Button429199724---size-5-large{padding:10px 16px} .DropdownBase4283233096__root.Button429199724--upgrade .buttonnext2552858610__content{overflow:visible;text-overflow:unset;white-space:unset} .DropdownBase4283233096__root.Button429199724--upgrade{box-sizing:border-box;line-height:1;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;display:inline-block} .DropdownBase4283233096__root.Button429199724--mobile.Button429199724--upgrade{line-height:1} .DropdownBase4283233096__root.Button429199724---size-4-tiny.Button429199724--upgrade{line-height:1} .DropdownBase4283233096__root.Button429199724---size-5-small.Button429199724--upgrade:not(mobile){line-height:1} .DropdownBase4283233096__root.Button429199724---size-6-medium.Button429199724--upgrade:not(mobile){line-height:1} .DropdownBase4283233096__root.Button429199724---size-5-large.Button429199724--upgrade:not(mobile){line-height:1} .DropdownBase4283233096__root .buttonnext2552858610__content{flex:1;text-align:start} .DropdownBase4283233096__root.Button429199724--mobile.Button429199724---size-6-medium, .DropdownBase4283233096__root.Button429199724---size-6-medium{padding:8px 0} .DropdownBase4283233096__root.Button429199724--mobile.Button429199724---size-6-medium::before, .DropdownBase4283233096__root.Button429199724---size-6-medium::before{width:12px;content:''} .DropdownBase4283233096__root.Button429199724--mobile.Button429199724---size-6-medium::after, .DropdownBase4283233096__root.Button429199724---size-6-medium::after{width:7px;content:''} .DropdownBase4283233096__root .buttonnext2552858610__content{margin:initial} .DropdownBase4283233096__root.DropdownBase4283233096--error, .DropdownBase4283233096__root.Button429199724---priority-5-basic.DropdownBase4283233096--error.Focusable1981311471--focus, .DropdownBase4283233096__root.Button429199724---priority-5-basic.DropdownBase4283233096--error:hover{border-color:#f64d43} .DropdownBase4283233096__root.Button429199724---priority-5-basic.buttonnext2552858610--disabled{cursor:default} .DropdownBase4283233096__optionIcon{display:flex} .DropdownBase4283233096__optionIcon::after{width:12px;content:''} .DropdownBase4283233096__root .DropdownBase4283233096__childrenWrapper{display:inline-block} .DropdownBase4283233096__root.Button429199724--mobile.Button429199724---size-6-medium.Button429199724--upgrade::before, .DropdownBase4283233096__root.Button429199724---size-6-medium.Button429199724--upgrade::before{width:0;content:''} .DropdownBase4283233096__root.Button429199724--upgrade{display:flex} .DropdownBase4283233096__root.Button429199724--upgrade .buttonnext2552858610__content{text-overflow:ellipsis;white-space:nowrap;overflow:hidden;display:inline-block} .DropdownBase4283233096__root.Button429199724--upgrade .DropdownBase4283233096__childrenWrapper{overflow:visible} .DropdownBase4283233096__root.Button429199724--mobile.Button429199724---size-6-medium.Button429199724--upgrade::after, .DropdownBase4283233096__root.Button429199724---size-6-medium.Button429199724--upgrade::after{width:0;content:''} .DropdownBase4283233096__root.Button429199724--mobile.Button429199724--upgrade.Button429199724---size-6-medium.Button429199724---priority-5-basic, .DropdownBase4283233096__root.Button429199724--upgrade.Button429199724---size-6-medium.Button429199724---priority-5-basic{padding:7px 7px 7px 12px} .DropdownBase4283233096__root.Button429199724--mobile.Button429199724--upgrade.Button429199724---size-6-medium.Button429199724---priority-5-basic.DropdownBase4283233096--rtl, .DropdownBase4283233096__root.Button429199724--upgrade.Button429199724---size-6-medium.Button429199724---priority-5-basic.DropdownBase4283233096--rtl{padding:7px 12px 7px 7px}
 .DropdownError622858920__root{color:#f64d43;box-sizing:border-box;position:absolute;top:50%;transform:translate(0,-50%);width:100%;display:flex;justify-content:flex-end;align-items:center;cursor:pointer} .DropdownError622858920__root .Popover2659814081__popoverContent{background-color:#212121;padding:4px 12px;border:1px #757575 solid;border-radius:3px;color:#fff;line-height:20px;font-family:HelveticaNeueW01-45Ligh,HelveticaNeueW02-45Ligh,HelveticaNeueW10-45Ligh,Helvetica Neue,Helvetica,Arial,メイリオ,meiryo,ヒラギノ角ゴ pro w3,hiragino kaku gothic pro,sans-serif;font-size:14px;-webkit-font-smoothing:auto;box-shadow:0 4px 8px 0 rgba(0,0,0,.12),0 0 4px 0 rgba(0,0,0,.1)} .DropdownError622858920__root .Tooltip758034538__tpaArrow{display:block;position:absolute;margin:0} .DropdownError622858920__root .Tooltip758034538__tpaArrow svg{display:block} .DropdownError622858920__root .Popover2659814081__popover[data-placement*=top].Tooltip758034538__withArrow{padding-bottom:6px} .DropdownError622858920__root .Popover2659814081__popover[data-placement*=bottom].Tooltip758034538__withArrow{padding-top:6px} .DropdownError622858920__root .Popover2659814081__popover[data-placement*=left].Tooltip758034538__withArrow{padding-right:6px} .DropdownError622858920__root .Popover2659814081__popover[data-placement*=right].Tooltip758034538__withArrow{padding-left:6px} .DropdownError622858920__root .Popover2659814081__popover[data-placement*=top] .Tooltip758034538__tpaArrow{bottom:0;width:12px;height:7px} .DropdownError622858920__root .Popover2659814081__popover[data-placement*=bottom] .Tooltip758034538__tpaArrow{top:0;width:12px;height:7px} .DropdownError622858920__root .Popover2659814081__popover[data-placement*=left] .Tooltip758034538__tpaArrow{right:0;width:7px;height:12px} .DropdownError622858920__root .Popover2659814081__popover[data-placement*=right] .Tooltip758034538__tpaArrow{left:0;width:7px;height:12px} .DropdownError622858920__root .Popover2659814081__popover[data-placement*=top].Tooltip758034538__popoverAnimation-enter{opacity:0;transform:scale(.9) translateY(3px)} .DropdownError622858920__root .Popover2659814081__popover[data-placement*=bottom].Tooltip758034538__popoverAnimation-enter{opacity:0;transform:scale(.9) translateY(-3px)} .DropdownError622858920__root .Popover2659814081__popover[data-placement*=left].Tooltip758034538__popoverAnimation-enter{opacity:0;transform:scale(.9) translateX(10px)} .DropdownError622858920__root .Popover2659814081__popover[data-placement*=right].Tooltip758034538__popoverAnimation-enter{opacity:0;transform:scale(.9) translateX(-10px)} .DropdownError622858920__root .Popover2659814081__popover[data-placement].Tooltip758034538__popoverAnimation-enter.Tooltip758034538__popoverAnimation-enter-active{opacity:1;transition:transform 120ms cubic-bezier(.25,.46,.45,.94),applyOpacity 120ms cubic-bezier(.25,.46,.45,.94);transform:scale(1) translateY(0) translateX(0)} .DropdownError622858920__root .Popover2659814081__popover[data-placement].Tooltip758034538__popoverAnimation-exit{opacity:1;transform:scale(1) translateY(0) translateX(0)} .DropdownError622858920__root .Popover2659814081__popover[data-placement].Tooltip758034538__popoverAnimation-exit.Tooltip758034538__popoverAnimation-exit-active{opacity:0;transition:transform 80ms linear,applyOpacity 80ms linear} .DropdownError622858920__root.Tooltip758034538---skin-5-error .Popover2659814081__popoverContent{background-color:#f64d43;border:1px solid rgba(255,255,255,.25)} .DropdownError622858920__root.Tooltip758034538---skin-5-error .Tooltip758034538__tpaArrow path{fill:#f64d43} .DropdownError622858920__root::after{width:32px;content:''} .DropdownError622858920__root .Popover2659814081__popover{min-width:initial} .DropdownError622858920__root .Popover2659814081__popoverElement{display:flex}
 .DropdownOption4208871261__root{box-sizing:border-box;display:flex;width:100%;padding:8px 12px} .DropdownOption4208871261__contentWrapper{max-width:100%} .DropdownOption4208871261__title{padding:0 12px;display:block;text-overflow:ellipsis;overflow:hidden;white-space:nowrap} .DropdownOption4208871261__root.DropdownOption4208871261--sectionTitle .DropdownOption4208871261__title{padding:0} .DropdownOption4208871261__subtitle{margin-top:4px;padding:0 12px;display:block;text-overflow:ellipsis;overflow:hidden;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;max-height:40px} .DropdownOption4208871261__icon{display:flex;justify-content:center;align-items:center;height:24px;width:24px}
 .DropdownNativeSelect1855204741__wrapper{position:relative;min-width:68px} .DropdownNativeSelect1855204741__root{min-width:100px;border-style:solid;box-sizing:content-box;border-radius:0;transition:background-color .2s ease-in-out,border-color .2s ease-in-out,color .2s ease-in-out;display:flex;cursor:pointer;box-sizing:border-box;outline:0;appearance:none;-webkit-appearance:none;-moz-appearance:none} .DropdownNativeSelect1855204741__root .buttonnext2552858610__content{margin:0 auto;text-overflow:ellipsis;white-space:nowrap;overflow:hidden} .DropdownNativeSelect1855204741__root.Button429199724--fullWidth{width:100%;box-sizing:border-box} .DropdownNativeSelect1855204741__root.Button429199724---size-4-tiny{padding:6px 16px} .DropdownNativeSelect1855204741__root.Button429199724---size-5-small{padding:7px 16px} .DropdownNativeSelect1855204741__root.Button429199724---size-6-medium{padding:8px 16px} .DropdownNativeSelect1855204741__root.Button429199724--mobile.Button429199724---size-6-medium{padding:10px 16px} .DropdownNativeSelect1855204741__root.Button429199724---size-5-large{padding:10px 16px} .DropdownNativeSelect1855204741__root.Button429199724--upgrade .buttonnext2552858610__content{overflow:visible;text-overflow:unset;white-space:unset} .DropdownNativeSelect1855204741__root.Button429199724--upgrade{box-sizing:border-box;line-height:1;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;display:inline-block} .DropdownNativeSelect1855204741__root.Button429199724--mobile.Button429199724--upgrade{line-height:1} .DropdownNativeSelect1855204741__root.Button429199724---size-4-tiny.Button429199724--upgrade{line-height:1} .DropdownNativeSelect1855204741__root.Button429199724---size-5-small.Button429199724--upgrade:not(mobile){line-height:1} .DropdownNativeSelect1855204741__root.Button429199724---size-6-medium.Button429199724--upgrade:not(mobile){line-height:1} .DropdownNativeSelect1855204741__root.Button429199724---size-5-large.Button429199724--upgrade:not(mobile){line-height:1} .DropdownNativeSelect1855204741__root.Button429199724--mobile.Button429199724---size-6-medium{padding:8px 12px;background-color:transparent} .DropdownNativeSelect1855204741__root.Button429199724--mobile.Button429199724---size-6-medium.DropdownNativeSelect1855204741--icon{padding:8px 36px} .DropdownNativeSelect1855204741__root.DropdownNativeSelect1855204741--error, .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic.DropdownNativeSelect1855204741--error.Focusable1981311471--focus{border-color:#f64d43} .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic.DropdownNativeSelect1855204741--disabled{cursor:default} .DropdownNativeSelect1855204741__arrowIcon{position:absolute;top:50%;transform:translateY(-50%);z-index:0;pointer-events:none} .DropdownNativeSelect1855204741__arrowIcon path{fill:currentColor} .DropdownNativeSelect1855204741__errorIcon{color:#f64d43} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popoverContent{background-color:#212121;padding:4px 12px;border:1px #757575 solid;border-radius:3px;color:#fff;line-height:20px;font-family:HelveticaNeueW01-45Ligh,HelveticaNeueW02-45Ligh,HelveticaNeueW10-45Ligh,Helvetica Neue,Helvetica,Arial,メイリオ,meiryo,ヒラギノ角ゴ pro w3,hiragino kaku gothic pro,sans-serif;font-size:14px;-webkit-font-smoothing:auto;box-shadow:0 4px 8px 0 rgba(0,0,0,.12),0 0 4px 0 rgba(0,0,0,.1)} .DropdownNativeSelect1855204741__errorIcon .Tooltip758034538__tpaArrow{display:block;position:absolute;margin:0} .DropdownNativeSelect1855204741__errorIcon .Tooltip758034538__tpaArrow svg{display:block} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover[data-placement*=top].Tooltip758034538__withArrow{padding-bottom:6px} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover[data-placement*=bottom].Tooltip758034538__withArrow{padding-top:6px} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover[data-placement*=left].Tooltip758034538__withArrow{padding-right:6px} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover[data-placement*=right].Tooltip758034538__withArrow{padding-left:6px} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover[data-placement*=top] .Tooltip758034538__tpaArrow{bottom:0;width:12px;height:7px} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover[data-placement*=bottom] .Tooltip758034538__tpaArrow{top:0;width:12px;height:7px} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover[data-placement*=left] .Tooltip758034538__tpaArrow{right:0;width:7px;height:12px} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover[data-placement*=right] .Tooltip758034538__tpaArrow{left:0;width:7px;height:12px} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover[data-placement*=top].Tooltip758034538__popoverAnimation-enter{opacity:0;transform:scale(.9) translateY(3px)} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover[data-placement*=bottom].Tooltip758034538__popoverAnimation-enter{opacity:0;transform:scale(.9) translateY(-3px)} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover[data-placement*=left].Tooltip758034538__popoverAnimation-enter{opacity:0;transform:scale(.9) translateX(10px)} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover[data-placement*=right].Tooltip758034538__popoverAnimation-enter{opacity:0;transform:scale(.9) translateX(-10px)} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover[data-placement].Tooltip758034538__popoverAnimation-enter.Tooltip758034538__popoverAnimation-enter-active{opacity:1;transition:transform 120ms cubic-bezier(.25,.46,.45,.94),applyOpacity 120ms cubic-bezier(.25,.46,.45,.94);transform:scale(1) translateY(0) translateX(0)} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover[data-placement].Tooltip758034538__popoverAnimation-exit{opacity:1;transform:scale(1) translateY(0) translateX(0)} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover[data-placement].Tooltip758034538__popoverAnimation-exit.Tooltip758034538__popoverAnimation-exit-active{opacity:0;transition:transform 80ms linear,applyOpacity 80ms linear} .DropdownNativeSelect1855204741__errorIcon.Tooltip758034538---skin-5-error .Popover2659814081__popoverContent{background-color:#f64d43;border:1px solid rgba(255,255,255,.25)} .DropdownNativeSelect1855204741__errorIcon.Tooltip758034538---skin-5-error .Tooltip758034538__tpaArrow path{fill:#f64d43} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popover{min-width:initial} .DropdownNativeSelect1855204741__errorIcon .Popover2659814081__popoverElement{display:flex} .DropdownNativeSelect1855204741__root.DropdownNativeSelect1855204741--rtl~.DropdownNativeSelect1855204741__arrowIcon{left:7px} .DropdownNativeSelect1855204741__root:not(.DropdownNativeSelect1855204741--rtl)~.DropdownNativeSelect1855204741__arrowIcon{right:7px} .DropdownNativeSelect1855204741__root.DropdownNativeSelect1855204741--rtl~.DropdownNativeSelect1855204741__errorIconWrapper{left:32px} .DropdownNativeSelect1855204741__root:not(.DropdownNativeSelect1855204741--rtl)~.DropdownNativeSelect1855204741__errorIconWrapper{right:32px} .DropdownNativeSelect1855204741__optionIcon{position:absolute;display:flex;top:50%;transform:translateY(-50%)} .DropdownNativeSelect1855204741__root.DropdownNativeSelect1855204741--rtl~.DropdownNativeSelect1855204741__optionIcon{right:7px} .DropdownNativeSelect1855204741__root:not(.DropdownNativeSelect1855204741--rtl)~.DropdownNativeSelect1855204741__optionIcon{left:7px} .DropdownNativeSelect1855204741__errorIconWrapper{position:absolute;display:flex;height:100%;top:0;align-items:center}
 .Counter4065152908__root{display:inline-flex;flex-flow:row-reverse;justify-content:space-between;align-items:center;box-sizing:border-box;height:40px;padding:0 6px;border-width:1px;border-style:solid} .Counter4065152908__root.Counter4065152908--error{border-color:#f64d43} .Counter4065152908__btn{background:0 0;padding:6px;border:0;cursor:pointer} .Counter4065152908__btn[disabled]{cursor:default} .Counter4065152908__root.Counter4065152908--error svg{color:#f64d43} .Counter4065152908__root .Counter4065152908__inputWrapper{flex-grow:1} .Counter4065152908__root input{padding:0;border:0;text-align:center;width:100%} .Counter4065152908__root input::-webkit-outer-spin-button, .Counter4065152908__root input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0} .Counter4065152908__root input[type=number]{-moz-appearance:textfield} .Counter4065152908__root input::-ms-clear{display:none}
 .AddToCartButton3216318065__addToCartButton{margin-top:12px;min-width:100px;border-style:solid;box-sizing:content-box;transition:background-color .2s ease-in-out,border-color .2s ease-in-out,color .2s ease-in-out} .AddToCartButton3216318065__addToCartButton .buttonnext2552858610__content{margin:0 auto;text-overflow:ellipsis;white-space:nowrap;overflow:hidden} .AddToCartButton3216318065__addToCartButton.Button429199724--fullWidth{width:100%;box-sizing:border-box} .AddToCartButton3216318065__addToCartButton.Button429199724---size-4-tiny{padding:6px 16px} .AddToCartButton3216318065__addToCartButton.Button429199724---size-5-small{padding:7px 16px} .AddToCartButton3216318065__addToCartButton.Button429199724---size-6-medium{padding:8px 16px} .AddToCartButton3216318065__addToCartButton.Button429199724--mobile.Button429199724---size-6-medium{padding:10px 16px} .AddToCartButton3216318065__addToCartButton.Button429199724---size-5-large{padding:10px 16px} .AddToCartButton3216318065__addToCartButton.Button429199724--upgrade .buttonnext2552858610__content{overflow:visible;text-overflow:unset;white-space:unset} .AddToCartButton3216318065__addToCartButton.Button429199724--upgrade{box-sizing:border-box;line-height:1;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;display:inline-block} .AddToCartButton3216318065__addToCartButton.Button429199724--mobile.Button429199724--upgrade{line-height:1} .AddToCartButton3216318065__addToCartButton.Button429199724---size-4-tiny.Button429199724--upgrade{line-height:1} .AddToCartButton3216318065__addToCartButton.Button429199724---size-5-small.Button429199724--upgrade:not(mobile){line-height:1} .AddToCartButton3216318065__addToCartButton.Button429199724---size-6-medium.Button429199724--upgrade:not(mobile){line-height:1} .AddToCartButton3216318065__addToCartButton.Button429199724---size-5-large.Button429199724--upgrade:not(mobile){line-height:1}
 .ColorPicker2061577079__root{display:inline-flex;margin:-4px;flex-wrap:wrap} .ColorPicker2061577079__item *{box-sizing:border-box} .ColorPicker2061577079__item .ColorPickerItem3359370024__radioOuter{display:flex;justify-content:center;align-items:center;margin:4px;transition:box-shadow .1s linear} .ColorPicker2061577079__item .ColorPickerItem3359370024__radioInner{width:calc(100% - 2px);height:calc(100% - 2px);border:1px solid #c9c9c9}
 .StatesButton2149414086__root{position:relative;cursor:pointer;display:block;border-style:solid;text-align:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;box-sizing:border-box} .StatesButton2149414086__root .buttonnext2552858610__content{line-height:1.5;display:block} .StatesButton2149414086__root.StatesButton2149414086--upgrade .buttonnext2552858610__content{line-height:1;display:inline-block} .StatesButton2149414086__successIcon{position:relative;top:.15em;animation:StatesButton2149414086__bounce-in .5s ease 0s 1 normal}@keyframes StatesButton2149414086__bounce-in{0%{transform:translateY(30px);opacity:0}32%{transform:translateY(-5px);opacity:1}68%{transform:translateY(2px);opacity:1}to{transform:translateY(0);opacity:1}}
 .QuantityCounter1985873316__quantityCounter{margin-top:12px;display:inline-flex;flex-flow:row-reverse;justify-content:space-between;align-items:center;box-sizing:border-box;height:40px;padding:0 6px;border-width:1px;border-style:solid;width:100%!important} .QuantityCounter1985873316__quantityCounter.Counter4065152908--error{border-color:#f64d43} .QuantityCounter1985873316__quantityCounter .Counter4065152908__btn{background:0 0;padding:6px;border:0;cursor:pointer} .QuantityCounter1985873316__quantityCounter .Counter4065152908__btn[disabled]{cursor:default} .QuantityCounter1985873316__quantityCounter.Counter4065152908--error svg{color:#f64d43} .QuantityCounter1985873316__quantityCounter .Counter4065152908__inputWrapper{flex-grow:1} .QuantityCounter1985873316__quantityCounter input{padding:0;border:0;text-align:center;width:100%} .QuantityCounter1985873316__quantityCounter input::-webkit-outer-spin-button, .QuantityCounter1985873316__quantityCounter input::-webkit-inner-spin-button{-webkit-appearance:none;margin:0} .QuantityCounter1985873316__quantityCounter input[type=number]{-moz-appearance:textfield} .QuantityCounter1985873316__quantityCounter input::-ms-clear{display:none} .Dropdown3880899842__label{display:block;margin-bottom:8px} .Dropdown3880899842__dropdown{width:100%} .Dropdown3880899842__dropdown, .Dropdown3880899842__dropdownBase.DropdownBase4283233096__root, .Dropdown3880899842__dropdownNativeSelect.DropdownNativeSelect1855204741__root{min-width:68px} .Dropdown3880899842__dropdown.Dropdown2055179274--content-visible .Dropdown3880899842__dropdownBase.DropdownBase4283233096__root.DropdownBase4283233096--error{border-color:#f64d43} .Dropdown3880899842__dropdown.Dropdown2055179274--content-visible .Dropdown3880899842__dropdownBase .DropdownBase4283233096__arrowIcon{transform:rotate(180deg)} .Dropdown3880899842__dropdown .Dropdown3880899842__dropdownBase .DropdownBase4283233096__arrowIcon path{fill:currentColor} .Dropdown3880899842__dropdown .Popover2659814081__popoverContent{border-width:0;box-sizing:border-box;margin-left:1px;max-width:100%;box-shadow:0 4px 8px 0 rgba(0,0,0,.1),0 0 4px 0 rgba(0,0,0,.1)} .Dropdown3880899842__dropdown .Dropdown2055179274__dropdownContent{padding:12px 0} .Dropdown3880899842__root.Dropdown3880899842---alignment-6-center{text-align:center} .Dropdown3880899842__root.Dropdown3880899842---alignment-6-center .Dropdown3880899842__dropdownBase.DropdownBase4283233096__root .buttonnext2552858610__content{flex:1} .Dropdown3880899842__root.Dropdown3880899842---alignment-6-center .DropdownOption4208871261__root{justify-content:center}</style><style>.comp-kdhgmi4f ._2zTHN{--gallery_productBackground: rgba(0, 0, 0, 0);--gallery_borderWidth: 0;--gallery_borderColor: #181818;background-color:rgba(255, 255, 255, 0);border-width:0px;border-color:rgb(72, 85, 177)}.comp-kdhgmi4f ._2zTHN .mxMP4{--gallery_ribbonBackground: #4855B1;background-color:rgb(72, 85, 177);left:0;font:normal normal normal 16px/1.75em raleway,sans-serif}.comp-kdhgmi4f ._2zTHN ._3ezRD{--gallery_quickViewTextColor: #000000;--gallery_quickViewBackground: rgba(255, 255, 255, 0.75);--gallery_quickViewTextFontStyle: normal normal normal 14px/1.75em raleway,sans-serif;color:rgb(24, 24, 24);background-color:rgba(255, 255, 255, 0.75);font:normal normal normal 18px/1.75em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f ._2zTHN ._3RqKm{--gallery_productMargin: 0;--gallery_alignment: left;padding:15px 0px 0px;text-align:center}.comp-kdhgmi4f ._2zTHN ._3RqKm ._2BULo{--gallery_titleFontStyle: normal normal normal 16px/1.75em raleway,sans-serif;font:normal normal normal 15px/1.875em raleway,sans-serif;text-decoration: ;color:rgb(24, 24, 24)}.comp-kdhgmi4f ._2zTHN ._3RqKm ._11uJt{--gallery_dividerColor: #181818;--gallery_dividerWidth: 1;--gallery_dividerLength: 20;border-color:rgb(24, 24, 24);border-bottom-width:1px;width:20px}.comp-kdhgmi4f ._1WPzN{right:10px}.comp-kdhgmi4f ._3-5SE ._2MTGu{background-color:#181818;color:#FFFFFF}.comp-kdhgmi4f ._3uack{--gallery_priceColor: #525252;--gallery_priceFontStyle: normal normal normal 13px/1.75em raleway,sans-serif;color:rgb(24, 24, 24);font:normal normal normal 15px/1.875em raleway,sans-serif;text-decoration: ;margin-left:-10px}.comp-kdhgmi4f ._3uack ._23IPr,.comp-kdhgmi4f ._3uack ._23ArP{margin-left:10px}.comp-kdhgmi4f ._3DJ-f{--gallery_outOfStockTextColor: #525252;color:rgb(24, 24, 24);font:normal normal normal 18px/1.75em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f ._2c0wg{text-align:start;color:#181818;font:normal normal normal 25px/1.34em avenir-lt-w01_85-heavy1475544,sans-serif;text-decoration: }

.comp-kdhgmi4f .Text2391806263__root.Text2391806263---typography-10-smallTitle{color:#181818;font:normal normal normal 24px/1.33em avenir-lt-w01_85-heavy1475544,sans-serif;text-decoration: }.comp-kdhgmi4f .Text2391806263__root.Text2391806263---typography-11-runningText{color:#181818;font:normal normal normal 16px/1.5em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .Text2391806263__root.Text2391806263---typography-8-listText{color:#181818;font:normal normal normal 16px/2em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .Text2391806263__root.Text2391806263---typography-10-largeTitle{color:#181818;font:normal normal normal 32px/1.25em avenir-lt-w01_85-heavy1475544,sans-serif;text-decoration: }.comp-kdhgmi4f .Text2391806263__root.Text2391806263--mobile.Text2391806263---typography-10-smallTitle{color:#181818;font:normal normal normal 20px/1.4em avenir-lt-w01_85-heavy1475544,sans-serif;text-decoration: }.comp-kdhgmi4f .Text2391806263__root.Text2391806263--mobile.Text2391806263---typography-11-runningText{color:#181818;font:normal normal normal 14px/1.42em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .Text2391806263__root.Text2391806263--mobile.Text2391806263---typography-8-listText{color:#181818;font:normal normal normal 14px/1.72em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .Text2391806263__root.Text2391806263--mobile.Text2391806263---typography-10-largeTitle{color:#181818;font:normal normal normal 24px/1.33em avenir-lt-w01_85-heavy1475544,sans-serif;text-decoration: }.comp-kdhgmi4f .Button429199724__root{border-color:#4855B1}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-5-basic{color:#FFFFFF;background-color:#181818;border-width:0px}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-5-basic:active,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-5-basic.Focusable1981311471--focus,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-5-basic:hover{background-color:rgba(24, 24, 24, 0.7);color:rgba(255, 255, 255, 0.7)}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-14-basicSecondary{color:#181818;background-color:rgba(0, 0, 0, 0);border-color:#181818;border-width:1px}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-14-basicSecondary:active,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-14-basicSecondary.Focusable1981311471--focus,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-14-basicSecondary:hover{color:rgba(24, 24, 24, 0.7);border-color:rgba(24, 24, 24, 0.7)}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-7-primary{color:#FFFFFF;background-color:#4855B1;border-width:0px}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-7-primary:active,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-7-primary.Focusable1981311471--focus,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-7-primary:hover{background-color:rgba(72, 85, 177, 0.7);color:rgba(255, 255, 255, 0.7)}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-9-secondary{color:#4855B1;background-color:rgba(0, 0, 0, 0);border-color:#4855B1;border-width:1px}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-9-secondary:active,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-9-secondary.Focusable1981311471--focus,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-9-secondary:hover{color:rgba(72, 85, 177, 0.7);border-color:rgba(72, 85, 177, 0.7)}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-5-basic.buttonnext2552858610--disabled,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-7-primary.buttonnext2552858610--disabled{background-color:#8c8c8c}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-14-basicSecondary.buttonnext2552858610--disabled,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-9-secondary.buttonnext2552858610--disabled{color:#8c8c8c;border-color:#8c8c8c}.comp-kdhgmi4f .Button429199724__root.Button429199724---size-4-tiny{font:normal normal normal 14px/1.43em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .Button429199724__root.Button429199724---size-5-small{font:normal normal normal 16px/1.5em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .Button429199724__root.Button429199724---size-6-medium{font:normal normal normal 16px/1.5em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .Button429199724__root.Button429199724--mobile.Button429199724---size-6-medium{font:normal normal normal 14px/1.44em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .Button429199724__root.Button429199724---size-5-large{font:normal normal normal 20px/1.5em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .Button429199724__root.Button429199724--mobile.Button429199724--upgrade{font:normal normal normal 14px/1 raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .Button429199724__root.Button429199724---size-4-tiny.Button429199724--upgrade{font:normal normal normal 14px/1 raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-9-secondary.Button429199724--upgrade.Button429199724---size-4-tiny,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-14-basicSecondary.Button429199724--upgrade.Button429199724---size-4-tiny{padding:calc(9px - 1px) 16px}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-4-tiny,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-4-tiny{padding:calc(9px - 0px) 16px}.comp-kdhgmi4f .Button429199724__root.Button429199724---size-5-small.Button429199724--upgrade:not(mobile){font:normal normal normal 16px/1 raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .Button429199724__root.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-5-small,.comp-kdhgmi4f .Button429199724__root.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-5-small{padding:calc(10px - 1px) 16px}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-small,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-small{padding:calc(10px - 0px) 16px}.comp-kdhgmi4f .Button429199724__root.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-5-small.Button429199724--mobile,.comp-kdhgmi4f .Button429199724__root.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-5-small.Button429199724--mobile{padding:calc(11px - 1px) 16px}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-small.Button429199724--mobile,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-small.Button429199724--mobile{padding:calc(11px - 0px) 16px}.comp-kdhgmi4f .Button429199724__root.Button429199724---size-6-medium.Button429199724--upgrade:not(mobile){font:normal normal normal 16px/1 raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .Button429199724__root.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-6-medium,.comp-kdhgmi4f .Button429199724__root.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-6-medium{padding:calc(12px - 1px) 16px}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-6-medium,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-6-medium{padding:calc(12px - 0px) 16px}.comp-kdhgmi4f .Button429199724__root.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-6-medium.Button429199724--mobile,.comp-kdhgmi4f .Button429199724__root.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-6-medium.Button429199724--mobile{padding:calc(13px - 1px) 16px}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-6-medium.Button429199724--mobile,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-6-medium.Button429199724--mobile{padding:calc(13px - 0px) 16px}.comp-kdhgmi4f .Button429199724__root.Button429199724---size-5-large.Button429199724--upgrade:not(mobile){font:normal normal normal 16px/1 raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .Button429199724__root.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-9-secondary,.comp-kdhgmi4f .Button429199724__root.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-14-basicSecondary{padding:calc(16px - 1px) 16px}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-large,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-large{padding:calc(16px - 0px) 16px}.comp-kdhgmi4f .Button429199724__root.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724--mobile,.comp-kdhgmi4f .Button429199724__root.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724--mobile{padding:calc(17px - 1px) 16px}.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-large.Button429199724--mobile,.comp-kdhgmi4f .Button429199724__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-large.Button429199724--mobile{padding:calc(17px - 1px) 16px}.comp-kdhgmi4f .ColorPickerItem3359370024__radioOuter{width:24px;height:24px;border-radius:12px;box-shadow:0 0 0 0 rgba(24, 24, 24, 0.6)}.comp-kdhgmi4f .ColorPickerItem3359370024__root.ColorPickerItem3359370024--checked .ColorPickerItem3359370024__radioOuter,.comp-kdhgmi4f .ColorPickerItem3359370024__root.ColorPickerItem3359370024--focused .ColorPickerItem3359370024__radioOuter{box-shadow:0 0 0 1px rgba(24, 24, 24, 0.6)}.comp-kdhgmi4f .ColorPickerItem3359370024__radioInner{border-radius:12px}.comp-kdhgmi4f .DropdownBase4283233096__root{border-color:rgba(24, 24, 24, 0.6)}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic{color:#181818;background-color:#FFFFFF;border-width:1px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic:active,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic.Focusable1981311471--focus,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic:hover{background-color:rgba(255, 255, 255, 0.7);color:rgba(24, 24, 24, 0.7)}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-14-basicSecondary{color:#181818;background-color:#FFFFFF;border-color:rgba(24, 24, 24, 0.6);border-width:1px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-14-basicSecondary:active,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-14-basicSecondary.Focusable1981311471--focus,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-14-basicSecondary:hover{color:rgba(24, 24, 24, 0.7);border-color:rgba(24, 24, 24, 0.42)}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-7-primary{color:#181818;background-color:#FFFFFF;border-width:1px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-7-primary:active,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-7-primary.Focusable1981311471--focus,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-7-primary:hover{background-color:rgba(255, 255, 255, 0.7);color:rgba(24, 24, 24, 0.7)}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-9-secondary{color:#181818;background-color:#FFFFFF;border-color:rgba(24, 24, 24, 0.6);border-width:1px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-9-secondary:active,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-9-secondary.Focusable1981311471--focus,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-9-secondary:hover{color:rgba(24, 24, 24, 0.7);border-color:rgba(24, 24, 24, 0.42)}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic.buttonnext2552858610--disabled,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-7-primary.buttonnext2552858610--disabled{background-color:#8c8c8c}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-14-basicSecondary.buttonnext2552858610--disabled,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-9-secondary.buttonnext2552858610--disabled{color:#8c8c8c;border-color:#8c8c8c}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---size-4-tiny{font:normal normal normal 14px/1.43em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---size-5-small{font:normal normal normal 16px/1.5em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---size-6-medium{font:normal normal normal 16px/1.5em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724--mobile.Button429199724---size-6-medium{font:normal normal normal 14px/1.44em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---size-5-large{font:normal normal normal 20px/1.5em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724--mobile.Button429199724--upgrade{font:normal normal normal 14px/1 raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---size-4-tiny.Button429199724--upgrade{font:normal normal normal 14px/1 raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-9-secondary.Button429199724--upgrade.Button429199724---size-4-tiny,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-14-basicSecondary.Button429199724--upgrade.Button429199724---size-4-tiny{padding:calc(9px - 1px) 16px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-4-tiny,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-4-tiny{padding:calc(9px - 1px) 16px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---size-5-small.Button429199724--upgrade:not(mobile){font:normal normal normal 16px/1 raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-5-small,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-5-small{padding:calc(10px - 1px) 16px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-small,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-small{padding:calc(10px - 1px) 16px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-5-small.Button429199724--mobile,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-5-small.Button429199724--mobile{padding:calc(11px - 1px) 16px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-small.Button429199724--mobile,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-small.Button429199724--mobile{padding:calc(11px - 1px) 16px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---size-6-medium.Button429199724--upgrade:not(mobile){font:normal normal normal 16px/1 raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-6-medium,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-6-medium{padding:calc(12px - 1px) 16px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-6-medium,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-6-medium{padding:calc(12px - 1px) 16px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-6-medium.Button429199724--mobile,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-6-medium.Button429199724--mobile{padding:calc(13px - 1px) 16px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-6-medium.Button429199724--mobile,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-6-medium.Button429199724--mobile{padding:calc(13px - 1px) 16px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---size-5-large.Button429199724--upgrade:not(mobile){font:normal normal normal 16px/1 raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-9-secondary,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-14-basicSecondary{padding:calc(16px - 1px) 16px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-large,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-large{padding:calc(16px - 1px) 16px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724--mobile,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724--mobile{padding:calc(17px - 1px) 16px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-large.Button429199724--mobile,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-large.Button429199724--mobile{padding:calc(17px - 1px) 16px}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic.Focusable1981311471--focus,.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic:hover{border-color:#181818;background-color:#FFFFFF}.comp-kdhgmi4f .DropdownBase4283233096__root.DropdownBase4283233096--placeholder{color:rgba(24, 24, 24, 0.6)}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic.buttonnext2552858610--disabled{background-color:#FFFFFF;color:rgba(24, 24, 24, 0.3);border-color:rgba(24, 24, 24, 0.3)}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic.buttonnext2552858610--disabled:hover{border-color:rgba(24, 24, 24, 0.3)}.comp-kdhgmi4f .DropdownBase4283233096__arrowIcon{color:#181818}.comp-kdhgmi4f .DropdownBase4283233096__root.Button429199724---priority-5-basic.buttonnext2552858610--disabled .DropdownBase4283233096__arrowIcon{color:rgba(24, 24, 24, 0.3)}.comp-kdhgmi4f .DropdownOption4208871261__root:not(.DropdownOption4208871261--selectable) .DropdownOption4208871261__title.Text2391806263---typography-10-smallTitle{color:rgba(24, 24, 24, 0.6);font:normal normal normal 24px/1.33em avenir-lt-w01_85-heavy1475544,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownOption4208871261__root:not(.DropdownOption4208871261--selectable) .DropdownOption4208871261__title.Text2391806263---typography-11-runningText{color:rgba(24, 24, 24, 0.6);font:normal normal normal 16px/1.5em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownOption4208871261__root:not(.DropdownOption4208871261--selectable) .DropdownOption4208871261__title.Text2391806263---typography-8-listText{color:rgba(24, 24, 24, 0.6);font:normal normal normal 16px/2em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownOption4208871261__root:not(.DropdownOption4208871261--selectable) .DropdownOption4208871261__title.Text2391806263---typography-10-largeTitle{color:rgba(24, 24, 24, 0.6);font:normal normal normal 32px/1.25em avenir-lt-w01_85-heavy1475544,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownOption4208871261__root:not(.DropdownOption4208871261--selectable) .DropdownOption4208871261__title.Text2391806263--mobile.Text2391806263---typography-10-smallTitle{color:rgba(24, 24, 24, 0.6);font:normal normal normal 20px/1.4em avenir-lt-w01_85-heavy1475544,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownOption4208871261__root:not(.DropdownOption4208871261--selectable) .DropdownOption4208871261__title.Text2391806263--mobile.Text2391806263---typography-11-runningText{color:rgba(24, 24, 24, 0.6);font:normal normal normal 14px/1.42em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownOption4208871261__root:not(.DropdownOption4208871261--selectable) .DropdownOption4208871261__title.Text2391806263--mobile.Text2391806263---typography-8-listText{color:rgba(24, 24, 24, 0.6);font:normal normal normal 14px/1.72em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownOption4208871261__root:not(.DropdownOption4208871261--selectable) .DropdownOption4208871261__title.Text2391806263--mobile.Text2391806263---typography-10-largeTitle{color:rgba(24, 24, 24, 0.6);font:normal normal normal 24px/1.33em avenir-lt-w01_85-heavy1475544,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownOption4208871261__subtitle.Text2391806263---typography-10-smallTitle{color:rgba(24, 24, 24, 0.6);font:normal normal normal 14px/20px raleway,sans-serif}.comp-kdhgmi4f .DropdownOption4208871261__subtitle.Text2391806263---typography-11-runningText{color:rgba(24, 24, 24, 0.6);font:normal normal normal 14px/20px raleway,sans-serif}.comp-kdhgmi4f .DropdownOption4208871261__subtitle.Text2391806263---typography-8-listText{color:rgba(24, 24, 24, 0.6);font:normal normal normal 14px/20px raleway,sans-serif}.comp-kdhgmi4f .DropdownOption4208871261__subtitle.Text2391806263---typography-10-largeTitle{color:rgba(24, 24, 24, 0.6);font:normal normal normal 14px/20px raleway,sans-serif}.comp-kdhgmi4f .DropdownOption4208871261__subtitle.Text2391806263--mobile.Text2391806263---typography-10-smallTitle{color:rgba(24, 24, 24, 0.6);font:normal normal normal 14px/20px raleway,sans-serif}.comp-kdhgmi4f .DropdownOption4208871261__subtitle.Text2391806263--mobile.Text2391806263---typography-11-runningText{color:rgba(24, 24, 24, 0.6);font:normal normal normal 14px/20px raleway,sans-serif}.comp-kdhgmi4f .DropdownOption4208871261__subtitle.Text2391806263--mobile.Text2391806263---typography-8-listText{color:rgba(24, 24, 24, 0.6);font:normal normal normal 14px/20px raleway,sans-serif}.comp-kdhgmi4f .DropdownOption4208871261__subtitle.Text2391806263--mobile.Text2391806263---typography-10-largeTitle{color:rgba(24, 24, 24, 0.6);font:normal normal normal 14px/20px raleway,sans-serif}.comp-kdhgmi4f .DropdownNativeSelect1855204741__wrapper{background-color:#FFFFFF}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root{border-color:rgba(24, 24, 24, 0.6)}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic{color:#181818;background-color:#FFFFFF;border-width:1px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic:active,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic.Focusable1981311471--focus,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic:hover{background-color:rgba(255, 255, 255, 0.7);color:rgba(24, 24, 24, 0.7)}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-14-basicSecondary{color:#181818;background-color:#FFFFFF;border-color:rgba(24, 24, 24, 0.6);border-width:1px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-14-basicSecondary:active,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-14-basicSecondary.Focusable1981311471--focus,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-14-basicSecondary:hover{color:rgba(24, 24, 24, 0.7);border-color:rgba(24, 24, 24, 0.42)}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-7-primary{color:#181818;background-color:#FFFFFF;border-width:1px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-7-primary:active,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-7-primary.Focusable1981311471--focus,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-7-primary:hover{background-color:rgba(255, 255, 255, 0.7);color:rgba(24, 24, 24, 0.7)}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-9-secondary{color:#181818;background-color:#FFFFFF;border-color:rgba(24, 24, 24, 0.6);border-width:1px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-9-secondary:active,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-9-secondary.Focusable1981311471--focus,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-9-secondary:hover{color:rgba(24, 24, 24, 0.7);border-color:rgba(24, 24, 24, 0.42)}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic.buttonnext2552858610--disabled,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-7-primary.buttonnext2552858610--disabled{background-color:#8c8c8c}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-14-basicSecondary.buttonnext2552858610--disabled,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-9-secondary.buttonnext2552858610--disabled{color:#8c8c8c;border-color:#8c8c8c}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---size-4-tiny{font:normal normal normal 14px/1.43em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---size-5-small{font:normal normal normal 16px/1.5em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---size-6-medium{font:normal normal normal 16px/1.5em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724--mobile.Button429199724---size-6-medium{font:normal normal normal 14px/1.44em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---size-5-large{font:normal normal normal 20px/1.5em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724--mobile.Button429199724--upgrade{font:normal normal normal 14px/1 raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---size-4-tiny.Button429199724--upgrade{font:normal normal normal 14px/1 raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-9-secondary.Button429199724--upgrade.Button429199724---size-4-tiny,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-14-basicSecondary.Button429199724--upgrade.Button429199724---size-4-tiny{padding:calc(9px - 1px) 16px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-4-tiny,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-4-tiny{padding:calc(9px - 1px) 16px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---size-5-small.Button429199724--upgrade:not(mobile){font:normal normal normal 16px/1 raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-5-small,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-5-small{padding:calc(10px - 1px) 16px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-small,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-small{padding:calc(10px - 1px) 16px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-5-small.Button429199724--mobile,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-5-small.Button429199724--mobile{padding:calc(11px - 1px) 16px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-small.Button429199724--mobile,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-small.Button429199724--mobile{padding:calc(11px - 1px) 16px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---size-6-medium.Button429199724--upgrade:not(mobile){font:normal normal normal 16px/1 raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-6-medium,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-6-medium{padding:calc(12px - 1px) 16px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-6-medium,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-6-medium{padding:calc(12px - 1px) 16px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-6-medium.Button429199724--mobile,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-6-medium.Button429199724--mobile{padding:calc(13px - 1px) 16px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-6-medium.Button429199724--mobile,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-6-medium.Button429199724--mobile{padding:calc(13px - 1px) 16px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---size-5-large.Button429199724--upgrade:not(mobile){font:normal normal normal 16px/1 raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-9-secondary,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-14-basicSecondary{padding:calc(16px - 1px) 16px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-large,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-large{padding:calc(16px - 1px) 16px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724--mobile,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724--mobile{padding:calc(17px - 1px) 16px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-large.Button429199724--mobile,.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-large.Button429199724--mobile{padding:calc(17px - 1px) 16px}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic.Focusable1981311471--focus{border-color:#181818;background-color:#FFFFFF}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.DropdownNativeSelect1855204741--placeholder{color:rgba(24, 24, 24, 0.6)}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic.DropdownNativeSelect1855204741--disabled{background-color:#FFFFFF;color:rgba(24, 24, 24, 0.3);border-color:rgba(24, 24, 24, 0.3)}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic.DropdownNativeSelect1855204741--disabled:hover{border-color:rgba(24, 24, 24, 0.3)}.comp-kdhgmi4f .DropdownNativeSelect1855204741__root.Button429199724---priority-5-basic.DropdownNativeSelect1855204741--disabled~.DropdownNativeSelect1855204741__arrowIcon{color:rgba(24, 24, 24, 0.3)}.comp-kdhgmi4f .DropdownNativeSelect1855204741__arrowIcon{color:#181818}.comp-kdhgmi4f .Counter4065152908__root{width:104px;background:#FFFFFF;border-color:#181818}.comp-kdhgmi4f .Counter4065152908__root.Counter4065152908--disabled{border-color:#8c8c8c}.comp-kdhgmi4f .Counter4065152908__btn path{fill:#181818}.comp-kdhgmi4f .Counter4065152908__btn[disabled] path{fill:#8c8c8c}.comp-kdhgmi4f .Counter4065152908__root.Counter4065152908--disabled .Counter4065152908__btn{color:#8c8c8c}.comp-kdhgmi4f .Counter4065152908__root input{background:#FFFFFF;color:#181818;font:normal normal normal 16px/1.5em raleway,sans-serif}.comp-kdhgmi4f .Counter4065152908__root.Counter4065152908--disabled input{color:#8c8c8c}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton{border-color:#181818;border-radius:0px}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-5-basic{color:#FFFFFF;background-color:#181818;border-width:0}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-5-basic:active,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-5-basic.Focusable1981311471--focus,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-5-basic:hover{background-color:rgba(24, 24, 24, 0.7);color:rgba(255, 255, 255, 0.7)}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-14-basicSecondary{color:#FFFFFF;background-color:rgba(0, 0, 0, 0);border-color:#181818;border-width:0}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-14-basicSecondary:active,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-14-basicSecondary.Focusable1981311471--focus,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-14-basicSecondary:hover{color:rgba(255, 255, 255, 0.7);border-color:rgba(24, 24, 24, 0.7)}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-7-primary{color:#FFFFFF;background-color:#4855B1;border-width:0}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-7-primary:active,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-7-primary.Focusable1981311471--focus,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-7-primary:hover{background-color:rgba(72, 85, 177, 0.7);color:rgba(255, 255, 255, 0.7)}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-9-secondary{color:#FFFFFF;background-color:rgba(0, 0, 0, 0);border-color:#181818;border-width:0}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-9-secondary:active,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-9-secondary.Focusable1981311471--focus,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-9-secondary:hover{color:rgba(255, 255, 255, 0.7);border-color:rgba(24, 24, 24, 0.7)}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-5-basic.buttonnext2552858610--disabled,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-7-primary.buttonnext2552858610--disabled{background-color:#8c8c8c}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-14-basicSecondary.buttonnext2552858610--disabled,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-9-secondary.buttonnext2552858610--disabled{color:#8c8c8c;border-color:#8c8c8c}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---size-4-tiny{font:normal normal normal 15px/1.75em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---size-5-small{font:normal normal normal 15px/1.75em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---size-6-medium{font:normal normal normal 15px/1.75em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724--mobile.Button429199724---size-6-medium{font:normal normal normal 15px/1.75em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---size-5-large{font:normal normal normal 15px/1.75em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724--mobile.Button429199724--upgrade{font:normal normal normal 15px/1.75em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---size-4-tiny.Button429199724--upgrade{font:normal normal normal 15px/1.75em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-9-secondary.Button429199724--upgrade.Button429199724---size-4-tiny,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-14-basicSecondary.Button429199724--upgrade.Button429199724---size-4-tiny{padding:calc(9px - 0) 16px}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-4-tiny,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-4-tiny{padding:calc(9px - 0) 16px}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---size-5-small.Button429199724--upgrade:not(mobile){font:normal normal normal 15px/1.75em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-5-small,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-5-small{padding:calc(10px - 0) 16px}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-small,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-small{padding:calc(10px - 0) 16px}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-5-small.Button429199724--mobile,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-5-small.Button429199724--mobile{padding:calc(11px - 0) 16px}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-small.Button429199724--mobile,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-small.Button429199724--mobile{padding:calc(11px - 0) 16px}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---size-6-medium.Button429199724--upgrade:not(mobile){font:normal normal normal 15px/1.75em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-6-medium,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-6-medium{padding:calc(12px - 0) 16px}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-6-medium,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-6-medium{padding:calc(12px - 0) 16px}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724---size-6-medium.Button429199724--mobile,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724---size-6-medium.Button429199724--mobile{padding:calc(13px - 0) 16px}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-6-medium.Button429199724--mobile,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-6-medium.Button429199724--mobile{padding:calc(13px - 0) 16px}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---size-5-large.Button429199724--upgrade:not(mobile){font:normal normal normal 15px/1.75em raleway,sans-serif;text-decoration: }.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-9-secondary,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-14-basicSecondary{padding:calc(16px - 0) 16px}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-large,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-large{padding:calc(16px - 0) 16px}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-9-secondary.Button429199724--mobile,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---size-5-large.Button429199724--upgrade.Button429199724---priority-14-basicSecondary.Button429199724--mobile{padding:calc(17px - 0) 16px}.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-7-primary.Button429199724--upgrade.Button429199724---size-5-large.Button429199724--mobile,.comp-kdhgmi4f .AddToCartButton3216318065__addToCartButton.Button429199724---priority-5-basic.Button429199724--upgrade.Button429199724---size-5-large.Button429199724--mobile{padding:calc(17px - 0) 16px}.comp-kdhgmi4f .ColorPicker2061577079__item .ColorPickerItem3359370024__radioOuter{width:24px;height:24px;border-radius:12px;box-shadow:0 0 0 0 rgba(24, 24, 24, 0.6)}.comp-kdhgmi4f .ColorPicker2061577079__item.ColorPickerItem3359370024--checked .ColorPickerItem3359370024__radioOuter,.comp-kdhgmi4f .ColorPicker2061577079__item.ColorPickerItem3359370024--focused .ColorPickerItem3359370024__radioOuter{box-shadow:0 0 0 1px rgba(24, 24, 24, 0.6)}.comp-kdhgmi4f .ColorPicker2061577079__item .ColorPickerItem3359370024__radioInner{border-radius:12px}.comp-kdhgmi4f .QuantityCounter1985873316__quantityCounter{width:100%;background:#FFFFFF;border-color:#181818}.comp-kdhgmi4f .QuantityCounter1985873316__quantityCounter.Counter4065152908--disabled{border-color:#8c8c8c}.comp-kdhgmi4f .QuantityCounter1985873316__quantityCounter .Counter4065152908__btn path{fill:#181818}.comp-kdhgmi4f .QuantityCounter1985873316__quantityCounter .Counter4065152908__btn[disabled] path{fill:#8c8c8c}.comp-kdhgmi4f .QuantityCounter1985873316__quantityCounter.Counter4065152908--disabled .Counter4065152908__btn{color:#8c8c8c}.comp-kdhgmi4f .QuantityCounter1985873316__quantityCounter input{background:#FFFFFF;color:#181818;font:normal normal normal 16px/1.5em raleway,sans-serif}.comp-kdhgmi4f .QuantityCounter1985873316__quantityCounter.Counter4065152908--disabled input{color:#8c8c8c}.comp-kdhgmi4f .Dropdown3880899842__root.Dropdown3880899842--mobile .Dropdown3880899842__label.Text2391806263---typography-10-smallTitle{color:#181818;font:normal normal normal 12px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__root.Dropdown3880899842--mobile .Dropdown3880899842__label.Text2391806263---typography-11-runningText{color:#181818;font:normal normal normal 12px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__root.Dropdown3880899842--mobile .Dropdown3880899842__label.Text2391806263---typography-8-listText{color:#181818;font:normal normal normal 12px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__root.Dropdown3880899842--mobile .Dropdown3880899842__label.Text2391806263---typography-10-largeTitle{color:#181818;font:normal normal normal 12px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__root.Dropdown3880899842--mobile .Dropdown3880899842__label.Text2391806263--mobile.Text2391806263---typography-10-smallTitle{color:#181818;font:normal normal normal 12px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__root.Dropdown3880899842--mobile .Dropdown3880899842__label.Text2391806263--mobile.Text2391806263---typography-11-runningText{color:#181818;font:normal normal normal 12px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__root.Dropdown3880899842--mobile .Dropdown3880899842__label.Text2391806263--mobile.Text2391806263---typography-8-listText{color:#181818;font:normal normal normal 12px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__root.Dropdown3880899842--mobile .Dropdown3880899842__label.Text2391806263--mobile.Text2391806263---typography-10-largeTitle{color:#181818;font:normal normal normal 12px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__label.Text2391806263---typography-10-smallTitle{color:#181818;font:normal normal normal 14px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__label.Text2391806263---typography-11-runningText{color:#181818;font:normal normal normal 14px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__label.Text2391806263---typography-8-listText{color:#181818;font:normal normal normal 14px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__label.Text2391806263---typography-10-largeTitle{color:#181818;font:normal normal normal 14px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__label.Text2391806263--mobile.Text2391806263---typography-10-smallTitle{color:#181818;font:normal normal normal 14px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__label.Text2391806263--mobile.Text2391806263---typography-11-runningText{color:#181818;font:normal normal normal 14px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__label.Text2391806263--mobile.Text2391806263---typography-8-listText{color:#181818;font:normal normal normal 14px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__label.Text2391806263--mobile.Text2391806263---typography-10-largeTitle{color:#181818;font:normal normal normal 14px/1.75em raleway,sans-serif}.comp-kdhgmi4f .Dropdown3880899842__dropdown.Dropdown2055179274--content-visible .Dropdown3880899842__dropdownBase.DropdownBase4283233096__root{border-color:#181818}.comp-kdhgmi4f .Dropdown3880899842__dropdown .Popover2659814081__popoverContent{background-color:#FFFFFF}.comp-kdhgmi4f .Dropdown3880899842__dropdown .Dropdown2055179274__dropdownContent .DropdownContent3889653823__dropdownOption.DropdownOption3183861959--hovered,.comp-kdhgmi4f .Dropdown3880899842__dropdown .Dropdown2055179274__dropdownContent .DropdownContent3889653823__dropdownOption.DropdownOption3183861959--selected,.comp-kdhgmi4f .Dropdown3880899842__dropdown .Dropdown2055179274__dropdownContent .DropdownContent3889653823__dropdownOption.DropdownOption3183861959--selected.DropdownOption3183861959--hovered{background-color:rgba(24, 24, 24, 0.05)}</style><style>/* must use this as inline so we will have this style(which calculates the height of productItem in gallery) on first paint
numbers represents ratios in ImageRatioId enum*/

.heightByImageRatio:before {
  content: "";
  display: block;
}

.heightByImageRatio0:before {
  padding-top: calc(100% / (3 / 2));
}

.heightByImageRatio1:before {
  padding-top: calc(100% / (4 / 3));
}

.heightByImageRatio2:before {
  padding-top: calc(100%);
}

.heightByImageRatio3:before {
  padding-top: calc(100% / (3 / 4));
}

.heightByImageRatio4:before {
  padding-top: calc(100% / (2 / 3));
}

.heightByImageRatio5:before {
  padding-top: calc(100% / (16 / 9));
}

.heightByImageRatio6:before {
  padding-top: calc(100% / (9 / 16));
}
</style><div data-hook="slider-gallery" data-slider-index="0" style="background-color:rgba(255,255,255,0)" class="_2DDgw"><div data-hook="slides-container" class="_3e4dm _15Cc8"><div class="slick-slider aM2rn slick-initialized" dir="ltr"><div class="slick-list"><div class="slick-track" style="width:700%;left:-100%"><div data-index="-4" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"></div><div data-index="-3" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"></div><div data-index="-2" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"></div><div data-index="-1" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"></div><div data-index="0" class="slick-slide slick-active slick-current" tabindex="-1" aria-hidden="false" style="outline:none;width:3.5714285714285716%"><div><div class="_2cw7M" tabindex="-1" style="width:100%;display:inline-block"><div data-hook="slider-gallery-slide" style="height:100%;padding-left:10px;padding-right:10px"><div style="height:100%" data-hook="product-item-root" class="_2zTHN _124MD"><a href="https://igrejaevredencao74.wixsite.com/akipertinho/product-page/sou-um-produto" class="_34sIs" data-hook="product-item-container"><div class="_3-5SE heightByImageRatio heightByImageRatio2" style="background-image:url(https://static.wixstatic.com/media/b75703_e2f6529d99ec4f708a0cd4ab5e47bce0~mv2.jpg/v1/fill/w_100,h_100,al_c,q_80,usm_0.66_1.00_0.01/b75703_e2f6529d99ec4f708a0cd4ab5e47bce0~mv2.jpg);background-size:cover" data-hook="product-item-images"><button class="_3ezRD" data-hook="product-item-quick-view-button" tabindex="-1" aria-hidden="true">Visualização Rápida</button></div><div class="_3RqKm" data-hook="product-item-product-details"><h3 class="_2BULo" data-hook="product-item-name">Sou um produto</h3><div class="_3uack"><span class="kpb5P" data-hook="sr-product-item-price-before-discount">Preço normal</span><span data-hook="product-item-price-before-discount" class="_23IPr">R$ 100,00</span><span class="kpb5P" data-hook="sr-product-item-price-to-pay">Preço promocional</span><span data-hook="product-item-price-to-pay" class="_23ArP">R$ 85,00</span></div></div></a></div></div></div></div></div><div data-index="1" class="slick-slide slick-active" tabindex="-1" aria-hidden="false" style="outline:none;width:3.5714285714285716%"><div><div class="_2cw7M" tabindex="-1" style="width:100%;display:inline-block"><div data-hook="slider-gallery-slide" style="height:100%;padding-left:10px;padding-right:10px"><div style="height:100%" data-hook="product-item-root" class="_2zTHN _124MD"><a href="https://igrejaevredencao74.wixsite.com/akipertinho/product-page/sou-um-produto-1" class="_34sIs" data-hook="product-item-container"><div class="_3-5SE heightByImageRatio heightByImageRatio2" style="background-image:url(https://static.wixstatic.com/media/b75703_855098dee93b418eb263c618ab6a9eb8~mv2.jpg/v1/fill/w_100,h_100,al_c,q_80,usm_0.66_1.00_0.01/b75703_855098dee93b418eb263c618ab6a9eb8~mv2.jpg);background-size:cover" data-hook="product-item-images"><button class="_3ezRD" data-hook="product-item-quick-view-button" tabindex="-1" aria-hidden="true">Visualização Rápida</button></div><div class="_3RqKm" data-hook="product-item-product-details"><h3 class="_2BULo" data-hook="product-item-name">Sou um produto</h3><div class="_3uack"><span class="kpb5P" data-hook="sr-product-item-price-to-pay">Preço</span><span data-hook="product-item-price-to-pay" class="_23ArP">R$ 115,00</span></div></div></a></div></div></div></div></div><div data-index="2" class="slick-slide slick-active" tabindex="-1" aria-hidden="false" style="outline:none;width:3.5714285714285716%"><div><div class="_2cw7M" tabindex="-1" style="width:100%;display:inline-block"><div data-hook="slider-gallery-slide" style="height:100%;padding-left:10px;padding-right:10px"><div style="height:100%" data-hook="product-item-root" class="_2zTHN _124MD"><a href="https://igrejaevredencao74.wixsite.com/akipertinho/product-page/sou-um-produto-2" class="_34sIs" data-hook="product-item-container"><div class="_3-5SE heightByImageRatio heightByImageRatio2" style="background-image:url(https://static.wixstatic.com/media/b75703_c66d7ccf7a014e98b0128492cae887f1~mv2.jpg/v1/fill/w_100,h_100,al_c,q_80,usm_0.66_1.00_0.01/b75703_c66d7ccf7a014e98b0128492cae887f1~mv2.jpg);background-size:cover" data-hook="product-item-images"><span class="mxMP4" data-hook="product-item-ribbon">Mais vendido</span><button class="_3ezRD" data-hook="product-item-quick-view-button" tabindex="-1" aria-hidden="true">Visualização Rápida</button></div><div class="_3RqKm" data-hook="product-item-product-details"><h3 class="_2BULo" data-hook="product-item-name">Sou um produto</h3><div class="_3uack"><span class="kpb5P" data-hook="sr-product-item-price-to-pay">Preço</span><span data-hook="product-item-price-to-pay" class="_23ArP">R$ 10,00</span></div></div></a></div></div></div></div></div><div data-index="3" class="slick-slide slick-active" tabindex="-1" aria-hidden="false" style="outline:none;width:3.5714285714285716%"><div><div class="_2cw7M" tabindex="-1" style="width:100%;display:inline-block"><div data-hook="slider-gallery-slide" style="height:100%;padding-left:10px;padding-right:10px"><div style="height:100%" data-hook="product-item-root" class="_2zTHN _124MD"><a href="https://igrejaevredencao74.wixsite.com/akipertinho/product-page/sou-um-produto-3" class="_34sIs" data-hook="product-item-container"><div class="_3-5SE heightByImageRatio heightByImageRatio2" style="background-image:url(https://static.wixstatic.com/media/b75703_3f3920ee1618489ab6b3ccd0c816423d~mv2.jpg/v1/fill/w_100,h_100,al_c,q_80,usm_0.66_1.00_0.01/b75703_3f3920ee1618489ab6b3ccd0c816423d~mv2.jpg);background-size:cover" data-hook="product-item-images"><button class="_3ezRD" data-hook="product-item-quick-view-button" tabindex="-1" aria-hidden="true">Visualização Rápida</button></div><div class="_3RqKm" data-hook="product-item-product-details"><h3 class="_2BULo" data-hook="product-item-name">Sou um produto</h3><div class="_3uack"><span class="kpb5P" data-hook="sr-product-item-price-to-pay">Preço</span><span data-hook="product-item-price-to-pay" class="_23ArP">R$ 25,00</span></div></div></a></div></div></div></div></div><div data-index="4" class="slick-slide" tabindex="-1" aria-hidden="true" style="outline:none;width:3.5714285714285716%"></div><div data-index="5" class="slick-slide" tabindex="-1" aria-hidden="true" style="outline:none;width:3.5714285714285716%"></div><div data-index="6" class="slick-slide" tabindex="-1" aria-hidden="true" style="outline:none;width:3.5714285714285716%"></div><div data-index="7" class="slick-slide" tabindex="-1" aria-hidden="true" style="outline:none;width:3.5714285714285716%"></div><div data-index="8" class="slick-slide" tabindex="-1" aria-hidden="true" style="outline:none;width:3.5714285714285716%"></div><div data-index="9" class="slick-slide" tabindex="-1" aria-hidden="true" style="outline:none;width:3.5714285714285716%"></div><div data-index="10" class="slick-slide" tabindex="-1" aria-hidden="true" style="outline:none;width:3.5714285714285716%"></div><div data-index="11" class="slick-slide" tabindex="-1" aria-hidden="true" style="outline:none;width:3.5714285714285716%"></div><div data-index="12" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"><div><div class="_2cw7M" tabindex="-1" style="width:100%;display:inline-block"><div data-hook="slider-gallery-slide" style="height:100%;padding-left:10px;padding-right:10px"><div style="height:100%" data-hook="product-item-root" class="_2zTHN _124MD"><a href="https://igrejaevredencao74.wixsite.com/akipertinho/product-page/sou-um-produto" class="_34sIs" data-hook="product-item-container"><div class="_3-5SE heightByImageRatio heightByImageRatio2" style="background-image:url(https://static.wixstatic.com/media/b75703_e2f6529d99ec4f708a0cd4ab5e47bce0~mv2.jpg/v1/fill/w_100,h_100,al_c,q_80,usm_0.66_1.00_0.01/b75703_e2f6529d99ec4f708a0cd4ab5e47bce0~mv2.jpg);background-size:cover" data-hook="product-item-images"><button class="_3ezRD" data-hook="product-item-quick-view-button" tabindex="-1" aria-hidden="true">Visualização Rápida</button></div><div class="_3RqKm" data-hook="product-item-product-details"><h3 class="_2BULo" data-hook="product-item-name">Sou um produto</h3><div class="_3uack"><span class="kpb5P" data-hook="sr-product-item-price-before-discount">Preço normal</span><span data-hook="product-item-price-before-discount" class="_23IPr">R$ 100,00</span><span class="kpb5P" data-hook="sr-product-item-price-to-pay">Preço promocional</span><span data-hook="product-item-price-to-pay" class="_23ArP">R$ 85,00</span></div></div></a></div></div></div></div></div><div data-index="13" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"><div><div class="_2cw7M" tabindex="-1" style="width:100%;display:inline-block"><div data-hook="slider-gallery-slide" style="height:100%;padding-left:10px;padding-right:10px"><div style="height:100%" data-hook="product-item-root" class="_2zTHN _124MD"><a href="https://igrejaevredencao74.wixsite.com/akipertinho/product-page/sou-um-produto-1" class="_34sIs" data-hook="product-item-container"><div class="_3-5SE heightByImageRatio heightByImageRatio2" style="background-image:url(https://static.wixstatic.com/media/b75703_855098dee93b418eb263c618ab6a9eb8~mv2.jpg/v1/fill/w_100,h_100,al_c,q_80,usm_0.66_1.00_0.01/b75703_855098dee93b418eb263c618ab6a9eb8~mv2.jpg);background-size:cover" data-hook="product-item-images"><button class="_3ezRD" data-hook="product-item-quick-view-button" tabindex="-1" aria-hidden="true">Visualização Rápida</button></div><div class="_3RqKm" data-hook="product-item-product-details"><h3 class="_2BULo" data-hook="product-item-name">Sou um produto</h3><div class="_3uack"><span class="kpb5P" data-hook="sr-product-item-price-to-pay">Preço</span><span data-hook="product-item-price-to-pay" class="_23ArP">R$ 115,00</span></div></div></a></div></div></div></div></div><div data-index="14" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"><div><div class="_2cw7M" tabindex="-1" style="width:100%;display:inline-block"><div data-hook="slider-gallery-slide" style="height:100%;padding-left:10px;padding-right:10px"><div style="height:100%" data-hook="product-item-root" class="_2zTHN _124MD"><a href="https://igrejaevredencao74.wixsite.com/akipertinho/product-page/sou-um-produto-2" class="_34sIs" data-hook="product-item-container"><div class="_3-5SE heightByImageRatio heightByImageRatio2" style="background-image:url(https://static.wixstatic.com/media/b75703_c66d7ccf7a014e98b0128492cae887f1~mv2.jpg/v1/fill/w_100,h_100,al_c,q_80,usm_0.66_1.00_0.01/b75703_c66d7ccf7a014e98b0128492cae887f1~mv2.jpg);background-size:cover" data-hook="product-item-images"><span class="mxMP4" data-hook="product-item-ribbon">Mais vendido</span><button class="_3ezRD" data-hook="product-item-quick-view-button" tabindex="-1" aria-hidden="true">Visualização Rápida</button></div><div class="_3RqKm" data-hook="product-item-product-details"><h3 class="_2BULo" data-hook="product-item-name">Sou um produto</h3><div class="_3uack"><span class="kpb5P" data-hook="sr-product-item-price-to-pay">Preço</span><span data-hook="product-item-price-to-pay" class="_23ArP">R$ 10,00</span></div></div></a></div></div></div></div></div><div data-index="15" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"><div><div class="_2cw7M" tabindex="-1" style="width:100%;display:inline-block"><div data-hook="slider-gallery-slide" style="height:100%;padding-left:10px;padding-right:10px"><div style="height:100%" data-hook="product-item-root" class="_2zTHN _124MD"><a href="https://igrejaevredencao74.wixsite.com/akipertinho/product-page/sou-um-produto-3" class="_34sIs" data-hook="product-item-container"><div class="_3-5SE heightByImageRatio heightByImageRatio2" style="background-image:url(https://static.wixstatic.com/media/b75703_3f3920ee1618489ab6b3ccd0c816423d~mv2.jpg/v1/fill/w_100,h_100,al_c,q_80,usm_0.66_1.00_0.01/b75703_3f3920ee1618489ab6b3ccd0c816423d~mv2.jpg);background-size:cover" data-hook="product-item-images"><button class="_3ezRD" data-hook="product-item-quick-view-button" tabindex="-1" aria-hidden="true">Visualização Rápida</button></div><div class="_3RqKm" data-hook="product-item-product-details"><h3 class="_2BULo" data-hook="product-item-name">Sou um produto</h3><div class="_3uack"><span class="kpb5P" data-hook="sr-product-item-price-to-pay">Preço</span><span data-hook="product-item-price-to-pay" class="_23ArP">R$ 25,00</span></div></div></a></div></div></div></div></div><div data-index="16" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"></div><div data-index="17" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"></div><div data-index="18" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"></div><div data-index="19" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"></div><div data-index="20" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"></div><div data-index="21" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"></div><div data-index="22" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"></div><div data-index="23" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true" style="width:3.5714285714285716%"></div></div></div></div></div></div></div></div></div></div></div></div></div></div></div></section><section style="left:0;width:100%;min-width:980px;height:auto;top:;bottom:;right:;position:;margin-left:0" data-responsive="true" data-is-screen-width="true" data-col-margin="0" data-row-margin="0" class="strc1" id="comp-kdhgmjf4"><div style="position:absolute;top:0;width:calc(100% - 0px);height:100%;overflow:hidden;pointer-events:auto;min-width:980px;left:0;right:0;bottom:0" data-page-id="o0j6r" data-enable-video="true" data-bg-effect-name="" data-full-screen-height="" data-media-type="" data-use-clip-path="" data-needs-clipping="" data-wix-video-layout="true" class="strc1balata" id="comp-kdhgmjf4balata"><div style="position:absolute;width:100%;height:100%;top:0;background-color:transparent" class="bgColor" id="comp-kdhgmjf4balatabgcolor"><div style="width:100%;height:100%;position:absolute;top:0;background-image:;opacity:1" id="comp-kdhgmjf4balatabgcoloroverlay" class="bgColoroverlay"></div></div></div><div style="position:relative;width:calc(100% - 0px);min-width:980px" id="comp-kdhgmjf4inlineContent" class="strc1inlineContent"><div style="position:relative;width:100%;left:0;flex:980;margin-left:0;min-width:980px;top:0;margin-top:0;margin-bottom:0;height:;display:flex;bottom:;right:" data-content-width="980" data-is-mesh="true" class="mc1" id="comp-kdhgmjf5"><div class="mc1container" style="position:relative;height:100%;width:100%" id="comp-kdhgmjf5container"><div style="position:absolute;top:0;width:100%;height:100%;overflow:hidden;pointer-events:auto;left:0;right:0;bottom:0" data-page-id="o0j6r" data-enable-video="true" data-bg-effect-name="" data-full-screen-height="" data-media-type="" data-use-clip-path="" data-needs-clipping="" data-wix-video-layout="true" class="mc1balata" id="comp-kdhgmjf5balata"><div style="position:absolute;width:100%;height:100%;top:0;background-color:rgba(227, 216, 62, 1)" class="bgColor" id="comp-kdhgmjf5balatabgcolor"><div style="width:100%;height:100%;position:absolute;top:0;background-image:;opacity:1" id="comp-kdhgmjf5balatabgcoloroverlay" class="bgColoroverlay"></div></div></div><div class="mc1inlineContentParent" style="position:relative;left:0;right:0;top:0;bottom:0" id="comp-kdhgmjf5inlineContentParent"><div style="width:100%;position:relative;top:0;bottom:0" class="mc1inlineContent" id="comp-kdhgmjf5inlineContent"><style id="comp-kdhgmjf5-mesh-styles">
    
#comp-kdhgmjf5inlineContent {
    height: auto;
    width: 100%;
    position: relative;
}

#comp-kdhgmjf5inlineContent-gridWrapper {
    pointer-events: none;
}

#comp-kdhgmjf5inlineContent-gridContainer {
    position: static;
    display: grid;
    height: auto;
    width: 100%;
    min-height: 540px;
    grid-template-rows: min-content 1fr;
    grid-template-columns: 100%;
}

#comp-kdhgmjf51 {
    position: relative;
    margin: 124px 0px 28px calc((100% - 980px) * 0.5);
    left: 100px;
    grid-area: 1 / 1 / 2 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdhgmjf53 {
    position: relative;
    margin: 0px 0px 10px calc((100% - 980px) * 0.5);
    left: 100px;
    grid-area: 2 / 1 / 3 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdhgmjf5centeredContent {
    position: relative;
}

#comp-kdhgmjf5inlineContent-gridContainer > * {
    pointer-events: auto;
}

#comp-kdhgmjf5inlineContent-gridContainer > [id$="-rotated-wrapper"] {
    pointer-events: none;
}

#comp-kdhgmjf5inlineContent-gridContainer > [id$="-rotated-wrapper"] > * {
    pointer-events: auto;
}</style><div id="comp-kdhgmjf5inlineContent-gridWrapper" data-mesh-internal="true"><div id="comp-kdhgmjf5inlineContent-gridContainer" data-mesh-internal="true"><div data-packed="true" data-vertical-text="false" style="top:;bottom:;left:;right:;width:780px;height:auto;position:;pointer-events:none" class="txtNew" id="comp-kdhgmjf51"><h1 class="font_6" style="text-align:center; line-height:1.35em;"><span class="color_15"><span style="text-transform:uppercase;">SOBRE</span></span></h1></div><div data-packed="true" data-vertical-text="false" style="top:;bottom:;left:;right:;width:780px;height:auto;position:;pointer-events:none" class="txtNew" id="comp-kdhgmjf53"><p class="font_9" style="line-height:1.875em; text-align:center;"><span class="color_15">Um portal que se destina a prestação de serviços de divulgação, anúncios exclusivos para empresas que querem anunciar seus produtos e serviços.</span></p><p class="font_9" style="line-height:1.875em; text-align:center;"><span class="color_15">O portal foi desenvolvido pensando em você empresários e profissionais liberais que buscam de forma fácil, ágil e objetiva divulgar seus produtos e serviços com qualidade.<br>Nossa proposta é de divulgar, ampliar e colocar sua empresa e seus produtos em evidência de uma maneira fácil e rápida, abrangendo seus diversos clientes e proporcionar a esses clientes uma rápida e fácil localização de seus produtos e serviços.</span></p></div></div></div></div></div></div></div></div></section></div></div></div></div></div></div></div></main><div id="soapAfterPagesContainer" class="page-without-sosp"><style id="soapAfterPagesContainer-mesh-styles">
    
#soapAfterPagesContainerinlineContent {
    height: auto;
    width: 100%;
    position: relative;
}

#soapAfterPagesContainerinlineContent-gridContainer {
    position: static;
    height: auto;
    width: 100%;
    min-height: auto;
    padding-bottom: 0px;
    box-sizing: border-box;
}

#CONTROLLER_COMP_CUSTOM_ID {
    position: absolute;
    top: -265px;
    left: 20px;
}

#soapAfterPagesContainercenteredContent {
    position: relative;
}

#soapAfterPagesContainerinlineContent-gridWrapper {
    pointer-events: none;
}

#soapAfterPagesContainerinlineContent-gridContainer > * {
    pointer-events: auto;
}

#soapAfterPagesContainerinlineContent-gridContainer > [id$="-rotated-wrapper"] {
    pointer-events: none;
}

#soapAfterPagesContainerinlineContent-gridContainer > [id$="-rotated-wrapper"] > * {
    pointer-events: auto;
}</style><div id="soapAfterPagesContainerinlineContent-gridContainer" data-mesh-internal="true"><div style="width:;height:;top:;bottom:;left:;right:;position:" class="style-kdhjonrb" id="CONTROLLER_COMP_CUSTOM_ID"></div></div></div><footer style="bottom:auto;overflow:hidden;left:0;margin-left:0;width:100%;min-width:980px;top:;right:;position:" class="fc1_footer fc1" tabindex="-1" data-site-width="980" data-fixedposition="false" data-isrunninginmobile="false" data-is-absolute-layout="false" data-state=" " id="SITE_FOOTER"><div style="left:0;width:100%" id="SITE_FOOTERscreenWidthBackground" class="fc1screenWidthBackground"><div class="fc1_bg"></div></div><div style="width:100%" id="SITE_FOOTERcenteredContent" class="fc1centeredContent"><div style="margin-left:calc((100% - 980px) / 2);width:980px" id="SITE_FOOTERbg" class="fc1bg"><div class="fc1_bg-center"></div></div><div id="SITE_FOOTERinlineContent" class="fc1inlineContent"><style id="SITE_FOOTER-mesh-styles">
    
#SITE_FOOTERinlineContent {
    height: auto;
    width: 100%;
    position: relative;
}

#SITE_FOOTERinlineContent-gridWrapper {
    pointer-events: none;
}

#SITE_FOOTERinlineContent-gridContainer {
    position: static;
    display: grid;
    height: auto;
    width: 100%;
    min-height: auto;
    grid-template-rows: min-content min-content min-content 1fr;
    grid-template-columns: 100%;
}

#comp-kdhleess {
    position: relative;
    margin: 48px 0px 0 calc((100% - 980px) * 0.5);
    left: 20px;
    grid-area: 1 / 1 / 2 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdgakdub {
    position: relative;
    margin: 0px 0px 10px calc((100% - 980px) * 0.5);
    left: 20px;
    grid-area: 2 / 1 / 3 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdhglxvo {
    position: relative;
    margin: 37px 0px 38px calc((100% - 980px) * 0.5);
    left: 532px;
    grid-area: 1 / 1 / 4 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdhld9nv {
    position: relative;
    margin: 0px 0px 2px calc((100% - 980px) * 0.5);
    left: 0px;
    grid-area: 4 / 1 / 5 / 2;
    justify-self: start;
    align-self: start;
}

#comp-kdgakdub1 {
    position: relative;
    margin: 5px 0px 7px calc((100% - 980px) * 0.5);
    left: 20px;
    grid-area: 4 / 1 / 5 / 2;
    justify-self: start;
    align-self: start;
}

#SITE_FOOTERcenteredContent {
    position: relative;
}

#SITE_FOOTERinlineContent-gridContainer > * {
    pointer-events: auto;
}

#SITE_FOOTERinlineContent-gridContainer > [id$="-rotated-wrapper"] {
    pointer-events: none;
}

#SITE_FOOTERinlineContent-gridContainer > [id$="-rotated-wrapper"] > * {
    pointer-events: auto;
}</style><div id="SITE_FOOTERinlineContent-gridWrapper" data-mesh-internal="true"><div id="SITE_FOOTERinlineContent-gridContainer" data-mesh-internal="true"><div data-packed="true" data-vertical-text="false" style="top:;bottom:;left:;right:;width:193px;height:auto;position:;pointer-events:none" class="txtNew" id="comp-kdhleess"><p class="font_9" style="text-align:center; line-height:1.875em;"><span class="color_15"><object height="0"><a class="auto-generated-link" data-auto-recognition="true" data-content="admin@todonegocio.online" href="mailto:admin@todonegocio.online" data-type="mail">admin@todonegocio.online</a></object></span></p></div><div data-packed="false" data-vertical-text="false" style="top:;bottom:;left:;right:;width:146px;height:auto;position:;min-height:28px;pointer-events:none" data-min-height="28" class="txtNew" id="comp-kdgakdub"><p class="font_9" style="text-align:center; line-height:1.875em;"><span class="color_15">Contato 41-3232-1111</span></p></div><wix-iframe style="top:;bottom:;left:;right:;width:450px;height:103px;position:;overflow:hidden;visibility:hidden;min-height:103px;min-width:450px" data-has-iframe="true" data-src="https://gs.wixapps.net/statics/index?cacheKiller=1596731300551&amp;commonConfig=%7B%22brand%22%3A%22wix%22%2C%22consentPolicy%22%3A%7B%22essential%22%3Atrue%2C%22functional%22%3Atrue%2C%22analytics%22%3Atrue%2C%22advertising%22%3Atrue%2C%22dataToThirdParty%22%3Atrue%7D%2C%22consentPolicyHeader%22%3A%7B%7D%7D&amp;compId=comp-kdhglxvo&amp;consent-policy=%7B%7BconsentPolicy%7D%7D&amp;currency=BRL&amp;deviceType=desktop&amp;height=103&amp;instance=YdBAScrX4CsxCNu2qtnL66MEKQ95as2Sxxj5_7fGmO4.eyJpbnN0YW5jZUlkIjoiMTA3MTQ0MWUtZWZjZS00ZjUyLTkyZjMtODk1NjllN2M4YWUzIiwiYXBwRGVmSWQiOiIxMzc1YmFhOC04ZWNhLTU2NTktY2U5ZC00NTViMjAwOTI1MGQiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsImJpVG9rZW4iOiJmZDI0MGMwYy0wMTAyLTBmOGMtM2VjYi04M2E0MGJiN2VhOTgiLCJzaXRlT3duZXJJZCI6ImI3NTcwMzJmLWExY2ItNGMxYS1iMjM3LWUxMGMwYmY0NjljOCJ9&amp;locale=pt&amp;pageId=masterPage&amp;siteRevision=57&amp;tz=America%2FSao_Paulo&amp;viewMode=site&amp;viewerCompId=comp-kdhglxvo&amp;width=450" data-is-tpa="true" data-widget-id="1375babd-6f2b-87ed-ff19-5778602c8b86" data-app-definition-id="1375baa8-8eca-5659-ce9d-455b2009250d" id="comp-kdhglxvo" class="style-kdhglyer"><iframe data-src="https://gs.wixapps.net/statics/index?cacheKiller=1596731300551&amp;commonConfig=%7B%22brand%22%3A%22wix%22%2C%22consentPolicy%22%3A%7B%22essential%22%3Atrue%2C%22functional%22%3Atrue%2C%22analytics%22%3Atrue%2C%22advertising%22%3Atrue%2C%22dataToThirdParty%22%3Atrue%7D%2C%22consentPolicyHeader%22%3A%7B%7D%7D&amp;compId=comp-kdhglxvo&amp;consent-policy=%7B%7BconsentPolicy%7D%7D&amp;currency=BRL&amp;deviceType=desktop&amp;height=103&amp;instance=YdBAScrX4CsxCNu2qtnL66MEKQ95as2Sxxj5_7fGmO4.eyJpbnN0YW5jZUlkIjoiMTA3MTQ0MWUtZWZjZS00ZjUyLTkyZjMtODk1NjllN2M4YWUzIiwiYXBwRGVmSWQiOiIxMzc1YmFhOC04ZWNhLTU2NTktY2U5ZC00NTViMjAwOTI1MGQiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsImJpVG9rZW4iOiJmZDI0MGMwYy0wMTAyLTBmOGMtM2VjYi04M2E0MGJiN2VhOTgiLCJzaXRlT3duZXJJZCI6ImI3NTcwMzJmLWExY2ItNGMxYS1iMjM3LWUxMGMwYmY0NjljOCJ9&amp;locale=pt&amp;pageId=masterPage&amp;siteRevision=57&amp;tz=America%2FSao_Paulo&amp;viewMode=site&amp;viewerCompId=comp-kdhglxvo&amp;width=450" scrolling="no" frameBorder="0" allow="autoplay; camera; microphone; geolocation; vr" allowtransparency="true" allowfullscreen="" name="comp-kdhglxvo" style="width:450px;height:103px;min-height:103px;min-width:450px;display:block;position:absolute;z-index:" title="Wix Get Subscribers" aria-label="Wix Get Subscribers" id="comp-kdhglxvoiframe" class="style-kdhglyeriframe"></iframe><div id="comp-kdhglxvooverlay" class="style-kdhglyeroverlay"></div></wix-iframe><section style="left:0;width:100%;min-width:980px;height:auto;top:;bottom:;right:;position:;margin-left:0" data-responsive="true" data-is-screen-width="true" data-col-margin="0" data-row-margin="0" class="strc1" id="comp-kdhld9nv"><div style="position:absolute;top:0;width:calc(100% - 0px);height:100%;overflow:hidden;pointer-events:auto;min-width:980px;left:0;right:0;bottom:0" data-page-id="masterPage" data-enable-video="true" data-bg-effect-name="" data-full-screen-height="" data-media-type="" data-use-clip-path="" data-needs-clipping="" data-wix-video-layout="true" class="strc1balata" id="comp-kdhld9nvbalata"><div style="position:absolute;width:100%;height:100%;top:0;background-color:transparent" class="bgColor" id="comp-kdhld9nvbalatabgcolor"><div style="width:100%;height:100%;position:absolute;top:0;background-image:;opacity:1" id="comp-kdhld9nvbalatabgcoloroverlay" class="bgColoroverlay"></div></div></div><div style="position:relative;width:calc(100% - 0px);min-width:980px" id="comp-kdhld9nvinlineContent" class="strc1inlineContent"><div style="position:relative;width:100%;left:0;flex:980;margin-left:0;min-width:980px;top:0;margin-top:0;margin-bottom:0;height:;display:flex;bottom:;right:" data-content-width="980" data-is-mesh="true" class="mc1" id="comp-kdhld9nw"><div class="mc1container" style="position:relative;height:100%;width:100%" id="comp-kdhld9nwcontainer"><div style="position:absolute;top:0;width:100%;height:100%;overflow:hidden;pointer-events:auto;left:0;right:0;bottom:0" data-page-id="masterPage" data-enable-video="true" data-bg-effect-name="" data-full-screen-height="" data-media-type="" data-use-clip-path="" data-needs-clipping="" data-wix-video-layout="true" class="mc1balata" id="comp-kdhld9nwbalata"><div style="position:absolute;width:100%;height:100%;top:0;background-color:rgba(245, 245, 243, 1)" class="bgColor" id="comp-kdhld9nwbalatabgcolor"><div style="width:100%;height:100%;position:absolute;top:0;background-image:;opacity:1" id="comp-kdhld9nwbalatabgcoloroverlay" class="bgColoroverlay"></div></div></div><div class="mc1inlineContentParent" style="position:relative;left:0;right:0;top:0;bottom:0" id="comp-kdhld9nwinlineContentParent"><div style="width:100%;position:relative;top:0;bottom:0" class="mc1inlineContent" id="comp-kdhld9nwinlineContent"><style id="comp-kdhld9nw-mesh-styles">
    
#comp-kdhld9nwinlineContent {
    height: auto;
    width: 100%;
    position: relative;
}

#comp-kdhld9nwinlineContent-gridContainer {
    position: static;
    height: auto;
    width: 100%;
    min-height: 35px;
}

#comp-kdhld9nwcenteredContent {
    position: relative;
}

#comp-kdhld9nwinlineContent-gridWrapper {
    pointer-events: none;
}

#comp-kdhld9nwinlineContent-gridContainer > * {
    pointer-events: auto;
}

#comp-kdhld9nwinlineContent-gridContainer > [id$="-rotated-wrapper"] {
    pointer-events: none;
}

#comp-kdhld9nwinlineContent-gridContainer > [id$="-rotated-wrapper"] > * {
    pointer-events: auto;
}</style><div id="comp-kdhld9nwinlineContent-gridContainer" data-mesh-internal="true"></div></div></div></div></div></div></section><div data-packed="false" data-vertical-text="false" style="top:;bottom:;left:;right:;width:486px;height:auto;position:;min-height:25px;pointer-events:none" data-min-height="25" class="txtNew" id="comp-kdgakdub1"><p class="font_10" style="text-align:left; line-height:1.79em;"><span class="color_15">©2020 por Todo Negócio AKI Pertinho. Criado com Topdesignevirtual.com</span></p></div></div></div></div></div></footer><wix-iframe style="top:671px;bottom:;left:1047px;right:;width:376px;height:70px;position:fixed;overflow:hidden;visibility:hidden;min-height:70px;min-width:376px;z-index:52" data-has-iframe="true" data-src="https://engage.wixapps.net/chat-widget-server/renderChatWidget/index?cacheKiller=1596731300551&amp;commonConfig=%7B%22brand%22%3A%22wix%22%2C%22consentPolicy%22%3A%7B%22essential%22%3Atrue%2C%22functional%22%3Atrue%2C%22analytics%22%3Atrue%2C%22advertising%22%3Atrue%2C%22dataToThirdParty%22%3Atrue%7D%2C%22consentPolicyHeader%22%3A%7B%7D%7D&amp;compId=comp-kdgakqt5&amp;consent-policy=%7B%7BconsentPolicy%7D%7D&amp;currency=BRL&amp;deviceType=desktop&amp;height=70&amp;instance=ZcCke3SdKXwdsbjBcpUi6E7Hv9lzJOEEIDibP6UcDDM.eyJpbnN0YW5jZUlkIjoiMmE2MzE3OTItMTA2MC00NTFiLWJjMjMtMDlkZWYzZjBiZWU5IiwiYXBwRGVmSWQiOiIxNDUxN2UxYS0zZmYwLWFmOTgtNDA4ZS0yYmQ2OTUzYzM2YTIiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsImJpVG9rZW4iOiJjNzM2NWY4MC1mZWFjLTA1YzUtMTAxYi0wMzJjNjYzYmRlOTIiLCJzaXRlT3duZXJJZCI6ImI3NTcwMzJmLWExY2ItNGMxYS1iMjM3LWUxMGMwYmY0NjljOCJ9&amp;locale=pt&amp;pageId=masterPage&amp;siteRevision=57&amp;tz=America%2FSao_Paulo&amp;viewMode=site&amp;viewerCompId=comp-kdgakqt5&amp;width=376" data-is-tpa="true" data-widget-id="14517f3f-ffc5-eced-f592-980aaa0bbb5c" data-app-definition-id="14517e1a-3ff0-af98-408e-2bd6953c36a2" data-horizontal-margin="0" data-vertical-margin="0" data-placement="BOTTOM_RIGHT" id="comp-kdgakqt5" class="tpagw0"><iframe data-src="https://engage.wixapps.net/chat-widget-server/renderChatWidget/index?cacheKiller=1596731300551&amp;commonConfig=%7B%22brand%22%3A%22wix%22%2C%22consentPolicy%22%3A%7B%22essential%22%3Atrue%2C%22functional%22%3Atrue%2C%22analytics%22%3Atrue%2C%22advertising%22%3Atrue%2C%22dataToThirdParty%22%3Atrue%7D%2C%22consentPolicyHeader%22%3A%7B%7D%7D&amp;compId=comp-kdgakqt5&amp;consent-policy=%7B%7BconsentPolicy%7D%7D&amp;currency=BRL&amp;deviceType=desktop&amp;height=70&amp;instance=ZcCke3SdKXwdsbjBcpUi6E7Hv9lzJOEEIDibP6UcDDM.eyJpbnN0YW5jZUlkIjoiMmE2MzE3OTItMTA2MC00NTFiLWJjMjMtMDlkZWYzZjBiZWU5IiwiYXBwRGVmSWQiOiIxNDUxN2UxYS0zZmYwLWFmOTgtNDA4ZS0yYmQ2OTUzYzM2YTIiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsImJpVG9rZW4iOiJjNzM2NWY4MC1mZWFjLTA1YzUtMTAxYi0wMzJjNjYzYmRlOTIiLCJzaXRlT3duZXJJZCI6ImI3NTcwMzJmLWExY2ItNGMxYS1iMjM3LWUxMGMwYmY0NjljOCJ9&amp;locale=pt&amp;pageId=masterPage&amp;siteRevision=57&amp;tz=America%2FSao_Paulo&amp;viewMode=site&amp;viewerCompId=comp-kdgakqt5&amp;width=376" scrolling="no" frameBorder="0" allow="autoplay; camera; microphone; geolocation; vr" allowtransparency="true" allowfullscreen="" name="comp-kdgakqt5" style="width:376px;height:70px;min-height:70px;min-width:376px;display:block;position:absolute;z-index:" title="Wix Chat" aria-label="Wix Chat" id="comp-kdgakqt5iframe" class="tpagw0iframe"></iframe><div id="comp-kdgakqt5overlay" class="tpagw0overlay"></div></wix-iframe></div></div><div id="WIX_ADS" class="wix-ads-2 visible desktop"><style type="text/css" data-styleid="wixAds-style">@charset "UTF-8";
/*the ad font is Helvetica. we don't wont users to use it in the sites, so we changed the name of the font */
@font-face {
  font-family: "wixFreemiumFontW01-35Thin";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/56be84de-9d60-4089-8df0-0ea6ec786b84.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/56be84de-9d60-4089-8df0-0ea6ec786b84.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/50d35bbc-dfd4-48f1-af16-cf058f69421d.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/278bef59-6be1-4800-b5ac-1f769ab47430.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/2e309b1b-08b8-477f-bc9e-7067cf0af0b3.svg#2e309b1b-08b8-477f-bc9e-7067cf0af0b3") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW01-45Ligh";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/ae1656aa-5f8f-4905-aed0-93e667bd6e4a.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/ae1656aa-5f8f-4905-aed0-93e667bd6e4a.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/530dee22-e3c1-4e9f-bf62-c31d510d9656.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/688ab72b-4deb-4e15-a088-89166978d469.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/7816f72f-f47e-4715-8cd7-960e3723846a.svg#7816f72f-f47e-4715-8cd7-960e3723846a") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW01-55Roma";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/b7693a83-b861-4aa6-85e0-9ecf676bc4d6.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/b7693a83-b861-4aa6-85e0-9ecf676bc4d6.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/bcf54343-d033-41ee-bbd7-2b77df3fe7ba.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/b0ffdcf0-26da-47fd-8485-20e4a40d4b7d.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/da09f1f1-062a-45af-86e1-2bbdb3dd94f9.svg#da09f1f1-062a-45af-86e1-2bbdb3dd94f9") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW01-65Medi";
  font-weight: bold;
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/07fe0fec-b63f-4963-8ee1-535528b67fdb.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/07fe0fec-b63f-4963-8ee1-535528b67fdb.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/60be5c39-863e-40cb-9434-6ebafb62ab2b.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/4c6503c9-859b-4d3b-a1d5-2d42e1222415.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/36c182c6-ef98-4021-9b0d-d63122c2bbf5.svg#36c182c6-ef98-4021-9b0d-d63122c2bbf5") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW02-35Thin";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/30b6ffc3-3b64-40dd-9ff8-a3a850daf535.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/30b6ffc3-3b64-40dd-9ff8-a3a850daf535.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/775a65da-14aa-4634-be95-6724c05fd522.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/988eaaa7-5565-4f65-bb17-146b650ce9e9.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/3503a1a6-91c3-4c42-8e66-2ea7b2b57541.svg#3503a1a6-91c3-4c42-8e66-2ea7b2b57541") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW02-45Ligh";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/88fcd49a-13c7-4d0c-86b1-ad1e258bd75d.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/88fcd49a-13c7-4d0c-86b1-ad1e258bd75d.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/9a2e4855-380f-477f-950e-d98e8db54eac.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/fa82d0ee-4fbd-4cc9-bf9f-226ad1fcbae2.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/48d599a6-92b5-4d43-a4ac-8959f6971853.svg#48d599a6-92b5-4d43-a4ac-8959f6971853") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW02-55Roma";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/0b3a3fca-0fad-402b-bd38-fdcbad1ef776.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/0b3a3fca-0fad-402b-bd38-fdcbad1ef776.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/d5af76d8-a90b-4527-b3a3-182207cc3250.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/1d238354-d156-4dde-89ea-4770ef04b9f9.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/b68875cb-14a9-472e-8177-0247605124d7.svg#b68875cb-14a9-472e-8177-0247605124d7") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW02-65Medi";
  font-weight: bold;
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/55f60419-09c3-42bd-b81f-1983ff093852.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/55f60419-09c3-42bd-b81f-1983ff093852.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/5b4a262e-3342-44e2-8ad7-719998a68134.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/4a3ef5d8-cfd9-4b96-bd67-90215512f1e5.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/58ab5075-53ea-46e6-9783-cbb335665f88.svg#58ab5075-53ea-46e6-9783-cbb335665f88") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW10-35Thin";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/93b6bf6a-418e-4a8f-8f79-cb9c99ef3e32.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/93b6bf6a-418e-4a8f-8f79-cb9c99ef3e32.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/c881c21b-4148-4a11-a65d-f35e42999bc8.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/03634cf1-a9c9-4e13-b049-c90d830423d4.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/1bc99c0a-298b-46f9-b325-18b5e5169795.svg#1bc99c0a-298b-46f9-b325-18b5e5169795") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW10-45Ligh";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/5b85c7cc-6ad4-4226-83f5-9d19e2974123.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/5b85c7cc-6ad4-4226-83f5-9d19e2974123.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/835e7b4f-b524-4374-b57b-9a8fc555fd4e.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/2c694ef6-9615-473e-8cf4-d8d00c6bd973.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/3fc84193-a13f-4fe8-87f7-238748a4ac54.svg#3fc84193-a13f-4fe8-87f7-238748a4ac54") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW10-65Medi";
  font-weight: bold;
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/7092fdcc-7036-48ce-ae23-cfbc9be2e3b0.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/7092fdcc-7036-48ce-ae23-cfbc9be2e3b0.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/5b29e833-1b7a-40ab-82a5-cfd69c8650f4.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/b0298148-2d59-44d1-9ec9-1ca6bb097603.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/ae1dea8c-a953-4845-b616-74a257ba72e6.svg#ae1dea8c-a953-4845-b616-74a257ba72e6") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW10-55Roma";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/f1feaed7-6bce-400a-a07e-a893ae43a680.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/f1feaed7-6bce-400a-a07e-a893ae43a680.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/8ac9e38d-29c6-41ea-8e47-4ae4d2b1a4e1.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/4bd09087-655e-4abb-844c-dccdeb68003d.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/df234d87-eada-4058-aa80-5871e7fbe1c3.svg#df234d87-eada-4058-aa80-5871e7fbe1c3") format("svg"); }

.wrapper.hidden {
  display: none; }

.wrapper.visible {
  display: block;
  visibility: visible; }

.wrapper .desktop-top {
  position: fixed;
  top: 0;
  right: 39px;
  border-top: solid 2px #459fed;
  border-bottom-left-radius: 10px;
  border-bottom-right-radius: 10px;
  transition: height 100ms;
  cursor: pointer;
  overflow: hidden;
  color: #ffffff;
  display: block;
  font-family: wixFreemiumFontW01-55Roma, wixFreemiumFontW02-55Roma, wixFreemiumFontW10-55Roma, Helvetica Neue, Helvetica, Arial, メイリオ, meiryo, ヒラギノ角ゴ pro w3, hiragino kaku gothic pro, sans-serif;
  letter-spacing: 0.05em;
  font-size: 13px;
  z-index: 999; }
  .wrapper .desktop-top:hover {
    min-height: 72px;
    background-color: #43515c;
    padding-bottom: 6px;
    word-wrap: break-word; }
    .wrapper .desktop-top:hover > .hover1 {
      display: block;
      font-family: wixFreemiumFontW01-35Thin, wixFreemiumFontW02-35Thin, wixFreemiumFontW10-35Thin, Helvetica Neue, Helvetica, Arial, メイリオ, meiryo, ヒラギノ角ゴ pro w3, hiragino kaku gothic pro, sans-serif;
      padding-top: 4px; }
    .wrapper .desktop-top:hover > .arrow,
    .wrapper .desktop-top:hover > .hover2 {
      display: inline-block; }
  .wrapper .desktop-top > .main {
    padding: 0 6px 0 10px;
    text-align: center;
    line-height: 26px;
    border-bottom-left-radius: 10px;
    border-bottom-right-radius: 10px;
    background-color: #20303c; }
    .wrapper .desktop-top > .main > .banner1,
    .wrapper .desktop-top > .main > .wix,
    .wrapper .desktop-top > .main > .banner2,
    .wrapper .desktop-top > .main > .arrow {
      display: inline-block; }
    .wrapper .desktop-top > .main > .wix {
      fill: #fff;
      width: 28px;
      height: 14px;
      padding: 0 1px 4px 1px;
      vertical-align: middle; }
      .wrapper .desktop-top > .main > .wix > .dot {
        fill: #fc0; }
  .wrapper .desktop-top > .hover1,
  .wrapper .desktop-top > .hover2 {
    padding-left: 14px;
    line-height: 20px;
    display: none; }
  .wrapper .desktop-top > .hover2 {
    color: #459fed;
    padding-right: 4px; }
  .wrapper .desktop-top > .arrow {
    display: none;
    fill: none;
    stroke: #459fed;
    stroke-miterlimit: 10;
    stroke-width: 2px;
    height: 10px;
    width: 6px;
    padding-bottom: 5px;
    vertical-align: bottom; }

.wrapper .desktop-bottom {
  position: fixed;
  width: 100%;
  height: 40px;
  background-color: #20303c;
  bottom: 0;
  max-height: 10vh;
  color: #ffffff;
  font-size: 14px;
  display: inline-block;
  line-height: 40px;
  text-align: center;
  letter-spacing: 0.05em;
  align-items: center;
  font-family: wixFreemiumFontW01-55Roma, wixFreemiumFontW02-55Roma, wixFreemiumFontW10-55Roma, Helvetica Neue, Helvetica, Arial, メイリオ, meiryo, ヒラギノ角ゴ pro w3, hiragino kaku gothic pro, sans-serif;
  transition: background-color 150ms;
  cursor: pointer;
  z-index: 999; }
  .wrapper .desktop-bottom.preview {
    cursor: default; }
  .wrapper .desktop-bottom:not(.preview):hover {
    background-color: #43515c; }
  .wrapper .desktop-bottom > .contents .wix-logo {
    fill: #fff;
    width: 36px;
    vertical-align: middle;
    padding-bottom: 6px;
    height: 16px; }
    .wrapper .desktop-bottom > .contents .wix-logo > .dot {
      fill: #fc0; }
  .wrapper .desktop-bottom > .contents .com {
    color: #ffffff; }
  .wrapper .desktop-bottom > .contents > .arrow {
    fill: none;
    stroke: #459fed;
    stroke-miterlimit: 10;
    stroke-width: 2px;
    height: 10px;
    padding-bottom: 1px;
    vertical-align: middle; }
  .wrapper .desktop-bottom > .contents > .second {
    color: #459fed;
    padding: 0 5px 0 6px; }

@media (orientation: landscape) and (max-width: 600px) {
  .wrapper .mobile-top.not-preview {
    display: none; } }

.wrapper .mobile-top {
  position: relative;
  display: block;
  height: 38px;
  top: 0px;
  width: 100%;
  font-family: wixFreemiumFontW01-65Medi, wixFreemiumFontW02-65Medi, wixFreemiumFontW10-65Medi, Helvetica Neue, Helvetica, Arial, メイリオ, meiryo, ヒラギノ角ゴ pro w3, hiragino kaku gothic pro, sans-serif;
  letter-spacing: 0.05em;
  font-size: 14px;
  color: #ffffff;
  background-color: #20303c;
  z-index: 999;
  text-align: center;
  cursor: default; }
  .wrapper .mobile-top.fixed-ad-mobile {
    position: fixed;
    width: 320px;
    z-index: 1000; }
  .wrapper .mobile-top > .first {
    display: inline-block;
    text-align: center;
    line-height: 38px; }
  .wrapper .mobile-top .wix-logo {
    fill: #fff;
    width: 30px;
    padding-bottom: 4px;
    vertical-align: middle;
    height: 15px; }
    .wrapper .mobile-top .wix-logo > .dot {
      fill: #fc0; }

/* old banner*/
.wixAds_wrapper-old.hidden {
  display: none; }

.wixAds_wrapper-old.visible {
  display: block; }

.wixAds_wrapper-old .wixAdsdesktopWADTop {
  position: fixed;
  z-index: 999;
  height: 26px;
  top: 0;
  right: 50px;
  overflow: hidden;
  background-color: #404040;
  border-radius: 0 0 6px 6px;
  pointer-events: all;
  cursor: pointer;
  -webkit-transition: all .3s ease-in-out;
  transition: all .3s ease-in-out; }
  .wixAds_wrapper-old .wixAdsdesktopWADTop:hover {
    height: 97px;
    background-color: rgba(50, 50, 50, 0.8); }
    .wixAds_wrapper-old .wixAdsdesktopWADTop:hover .topLabel {
      background-color: #222222; }

.wixAds_wrapper-old .topLabel {
  padding: 6px;
  font-size: 13px;
  line-height: 1.3em;
  color: #FFF;
  width: 100%;
  font-size: 13px;
  color: #FFF;
  font-weight: bold;
  line-height: 18px;
  text-align: justify;
  padding: 5px 10px; }
  .wixAds_wrapper-old .topLabel .smallMusa {
    display: inline-block;
    text-indent: -9999px;
    width: 16px;
    height: 16px;
    margin-right: 5px;
    background-image: url("//static.wixstatic.com/media/0da768_0c5ce9e2ffa442bea0b79b690223a939~mv2.png");
    background-repeat: no-repeat;
    background-position: 0% 0%; }
  .wixAds_wrapper-old .topLabel .smallLogo {
    display: inline-block;
    text-indent: -9999px;
    width: 29px;
    height: 16px;
    background-image: url("//static.wixstatic.com/media/0da768_0c5ce9e2ffa442bea0b79b690223a939~mv2.png");
    background-repeat: no-repeat;
    background-position: -16px top; }

.wixAds_wrapper-old .topContent {
  font-size: 13px;
  line-height: 1.3em;
  color: #ffffff;
  font-weight: bold;
  line-height: 18px;
  text-align: justify;
  padding: 5px 10px;
  width: 100%; }
  .wixAds_wrapper-old .topContent .emphasis {
    color: #ffcc00;
    line-height: 26px; }

.wixAds_wrapper-old .desktop-bottom {
  position: fixed;
  z-index: 999;
  width: 100%;
  bottom: 0;
  max-height: 10vh; }
  .wixAds_wrapper-old .desktop-bottom:hover .siteBanner,
  .wixAds_wrapper-old .desktop-bottom:hover .footerLabel {
    background-color: #222222 !important; }
  .wixAds_wrapper-old .desktop-bottom .footerLabel {
    width: 100%;
    height: 40px;
    text-align: center;
    background-color: #404040;
    border-radius: 6px 6px 0 0;
    pointer-events: all;
    cursor: pointer; }
    .wixAds_wrapper-old .desktop-bottom .footerLabel .siteBanner {
      background-color: #404040;
      border-radius: 6px 6px 0 0;
      width: 100%;
      height: 100%;
      text-align: center; }
      .wixAds_wrapper-old .desktop-bottom .footerLabel .siteBanner .bigMusa {
        text-indent: -9999px;
        width: 36px;
        background-image: url("//static.wixstatic.com/media/0da768_0c5ce9e2ffa442bea0b79b690223a939~mv2.png");
        background-repeat: no-repeat;
        background-position: left bottom;
        position: relative;
        top: -19px; }
      .wixAds_wrapper-old .desktop-bottom .footerLabel .siteBanner .wrapper {
        padding: 5px 0; }
      .wixAds_wrapper-old .desktop-bottom .footerLabel .siteBanner .wrapper div {
        display: inline-block;
        height: 30px; }
      .wixAds_wrapper-old .desktop-bottom .footerLabel .siteBanner .txt {
        line-height: 47px;
        color: #ffffff;
        font-weight: bold;
        font-size: 15px; }
        .wixAds_wrapper-old .desktop-bottom .footerLabel .siteBanner .txt a {
          color: #ffffff; }
    .wixAds_wrapper-old .desktop-bottom .footerLabel .emphasis {
      color: #ffcc00;
      font-size: 16px;
      text-transform: uppercase; }

.wixAds_wrapper-old .mobile-top {
  width: 100%;
  height: 30px;
  position: relative;
  display: block;
  text-align: center;
  background-color: #313131;
  z-index: 999; }
  .wixAds_wrapper-old .mobile-top .wixAdsmobileAdImg {
    height: 30px; }

@media (orientation: landscape) and (max-width: 600px) {
  .wixAds_wrapper-old .mobile-top.not-preview {
    display: none; } }

.wixAds_wrapper-old .spacer {
  line-height: 26px; }

/*the ad font is Helvetica. we don't wont users to use it in the sites, so we changed the name of the font */
@font-face {
  font-family: "wixFreemiumFontW01-35Thin";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/56be84de-9d60-4089-8df0-0ea6ec786b84.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/56be84de-9d60-4089-8df0-0ea6ec786b84.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/50d35bbc-dfd4-48f1-af16-cf058f69421d.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/278bef59-6be1-4800-b5ac-1f769ab47430.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/2e309b1b-08b8-477f-bc9e-7067cf0af0b3.svg#2e309b1b-08b8-477f-bc9e-7067cf0af0b3") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW01-45Ligh";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/ae1656aa-5f8f-4905-aed0-93e667bd6e4a.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/ae1656aa-5f8f-4905-aed0-93e667bd6e4a.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/530dee22-e3c1-4e9f-bf62-c31d510d9656.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/688ab72b-4deb-4e15-a088-89166978d469.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/7816f72f-f47e-4715-8cd7-960e3723846a.svg#7816f72f-f47e-4715-8cd7-960e3723846a") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW01-55Roma";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/b7693a83-b861-4aa6-85e0-9ecf676bc4d6.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/b7693a83-b861-4aa6-85e0-9ecf676bc4d6.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/bcf54343-d033-41ee-bbd7-2b77df3fe7ba.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/b0ffdcf0-26da-47fd-8485-20e4a40d4b7d.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/da09f1f1-062a-45af-86e1-2bbdb3dd94f9.svg#da09f1f1-062a-45af-86e1-2bbdb3dd94f9") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW01-65Medi";
  font-weight: bold;
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/07fe0fec-b63f-4963-8ee1-535528b67fdb.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/07fe0fec-b63f-4963-8ee1-535528b67fdb.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/60be5c39-863e-40cb-9434-6ebafb62ab2b.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/4c6503c9-859b-4d3b-a1d5-2d42e1222415.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/36c182c6-ef98-4021-9b0d-d63122c2bbf5.svg#36c182c6-ef98-4021-9b0d-d63122c2bbf5") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW02-35Thin";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/30b6ffc3-3b64-40dd-9ff8-a3a850daf535.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/30b6ffc3-3b64-40dd-9ff8-a3a850daf535.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/775a65da-14aa-4634-be95-6724c05fd522.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/988eaaa7-5565-4f65-bb17-146b650ce9e9.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/3503a1a6-91c3-4c42-8e66-2ea7b2b57541.svg#3503a1a6-91c3-4c42-8e66-2ea7b2b57541") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW02-45Ligh";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/88fcd49a-13c7-4d0c-86b1-ad1e258bd75d.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/88fcd49a-13c7-4d0c-86b1-ad1e258bd75d.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/9a2e4855-380f-477f-950e-d98e8db54eac.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/fa82d0ee-4fbd-4cc9-bf9f-226ad1fcbae2.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/48d599a6-92b5-4d43-a4ac-8959f6971853.svg#48d599a6-92b5-4d43-a4ac-8959f6971853") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW02-55Roma";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/0b3a3fca-0fad-402b-bd38-fdcbad1ef776.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/0b3a3fca-0fad-402b-bd38-fdcbad1ef776.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/d5af76d8-a90b-4527-b3a3-182207cc3250.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/1d238354-d156-4dde-89ea-4770ef04b9f9.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/b68875cb-14a9-472e-8177-0247605124d7.svg#b68875cb-14a9-472e-8177-0247605124d7") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW02-65Medi";
  font-weight: bold;
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/55f60419-09c3-42bd-b81f-1983ff093852.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/55f60419-09c3-42bd-b81f-1983ff093852.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/5b4a262e-3342-44e2-8ad7-719998a68134.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/4a3ef5d8-cfd9-4b96-bd67-90215512f1e5.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/58ab5075-53ea-46e6-9783-cbb335665f88.svg#58ab5075-53ea-46e6-9783-cbb335665f88") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW10-35Thin";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/93b6bf6a-418e-4a8f-8f79-cb9c99ef3e32.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/93b6bf6a-418e-4a8f-8f79-cb9c99ef3e32.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/c881c21b-4148-4a11-a65d-f35e42999bc8.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/03634cf1-a9c9-4e13-b049-c90d830423d4.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/1bc99c0a-298b-46f9-b325-18b5e5169795.svg#1bc99c0a-298b-46f9-b325-18b5e5169795") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW10-45Ligh";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/5b85c7cc-6ad4-4226-83f5-9d19e2974123.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/5b85c7cc-6ad4-4226-83f5-9d19e2974123.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/835e7b4f-b524-4374-b57b-9a8fc555fd4e.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/2c694ef6-9615-473e-8cf4-d8d00c6bd973.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/3fc84193-a13f-4fe8-87f7-238748a4ac54.svg#3fc84193-a13f-4fe8-87f7-238748a4ac54") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW10-65Medi";
  font-weight: bold;
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/7092fdcc-7036-48ce-ae23-cfbc9be2e3b0.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/7092fdcc-7036-48ce-ae23-cfbc9be2e3b0.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/5b29e833-1b7a-40ab-82a5-cfd69c8650f4.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/b0298148-2d59-44d1-9ec9-1ca6bb097603.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/ae1dea8c-a953-4845-b616-74a257ba72e6.svg#ae1dea8c-a953-4845-b616-74a257ba72e6") format("svg"); }

@font-face {
  font-family: "wixFreemiumFontW10-55Roma";
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/f1feaed7-6bce-400a-a07e-a893ae43a680.eot?#iefix");
  src: url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/f1feaed7-6bce-400a-a07e-a893ae43a680.eot?#iefix") format("eot"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/8ac9e38d-29c6-41ea-8e47-4ae4d2b1a4e1.woff") format("woff"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/4bd09087-655e-4abb-844c-dccdeb68003d.ttf") format("truetype"), url("//static.parastorage.com/services/third-party/fonts/Helvetica/Fonts/df234d87-eada-4058-aa80-5871e7fbe1c3.svg#df234d87-eada-4058-aa80-5871e7fbe1c3") format("svg"); }

.wix-ads-2 {
  width: 100%; }
  .wix-ads-2.hidden {
    display: none; }
  .wix-ads-2.visible {
    display: block;
    visibility: visible; }
  .wix-ads-2.desktop {
    z-index: 999;
    position: fixed;
    top: 0; }
  .wix-ads-2.mobile {
    z-index: 999; }
  .wix-ads-2 .rtl {
    direction: rtl; }
  .wix-ads-2 .ltr {
    direction: ltr; }
  .wix-ads-2 .desktop-top {
    height: 50px;
    box-sizing: border-box;
    background: #eff1f2;
    display: flex;
    justify-content: center;
    align-items: center;
    border-bottom: 3px solid #a0138e;
    width: 100%; }
    .wix-ads-2 .desktop-top.overlay {
      background-color: #ff0000;
      border: none; }
    .wix-ads-2 .desktop-top.preview {
      cursor: default; }
    .wix-ads-2 .desktop-top > .contents {
      display: flex;
      align-items: center; }
      .wix-ads-2 .desktop-top > .contents .text {
        font-family: wixFreemiumFontW01-65Medi, wixFreemiumFontW02-65Medi, wixFreemiumFontW10-65Medi, Helvetica Neue, Helvetica, Arial, メイリオ, meiryo, ヒラギノ角ゴ pro w3, hiragino kaku gothic pro, sans-serif;
        font-size: 14px;
        color: #20303C;
        line-height: 24px;
        flex-shrink: 0; }
        .wix-ads-2 .desktop-top > .contents .text .wix-logo {
          fill: #20303C;
          width: 36px;
          vertical-align: middle;
          padding-bottom: 6px;
          height: 16px; }
          .wix-ads-2 .desktop-top > .contents .text .wix-logo > .dot {
            fill: #fc0; }
        .wix-ads-2 .desktop-top > .contents .text .com {
          color: #20303C; }
      .wix-ads-2 .desktop-top > .contents .button {
        font-family: wixFreemiumFontW01-65Medi, wixFreemiumFontW02-65Medi, wixFreemiumFontW10-65Medi, Helvetica Neue, Helvetica, Arial, メイリオ, meiryo, ヒラギノ角ゴ pro w3, hiragino kaku gothic pro, sans-serif;
        font-size: 14px;
        color: #a0138e;
        border: 1px solid #a0138e;
        display: inline-flex;
        width: 112px;
        height: 35px;
        justify-content: center;
        align-items: center;
        border-radius: 17px;
        flex-shrink: 0;
        text-align: center; }
        .wix-ads-2 .desktop-top > .contents .button.ltr {
          margin-left: 6px; }
        .wix-ads-2 .desktop-top > .contents .button.rtl {
          margin-right: 6px; }
    .wix-ads-2 .desktop-top:not(.overlay):hover {
      cursor: pointer;
      background: #fff; }
      .wix-ads-2 .desktop-top:not(.overlay):hover .button {
        color: #fff;
        background-color: #a0138e; }
  .wix-ads-2 .mobile-top {
    height: 38px;
    box-sizing: border-box;
    background: #eff1f2;
    display: flex;
    justify-content: center;
    align-items: center;
    border-bottom: 3px solid #a0138e;
    width: 100%;
    position: relative;
    top: 0;
    z-index: 1; }
    .wix-ads-2 .mobile-top.overlay {
      background-color: #ff0000;
      border: none; }
    .wix-ads-2 .mobile-top.fixed-ad-mobile {
      position: fixed;
      width: 320px;
      z-index: 1000; }
    .wix-ads-2 .mobile-top .content {
      font-family: wixFreemiumFontW01-65Medi, wixFreemiumFontW02-65Medi, wixFreemiumFontW10-65Medi, Helvetica Neue, Helvetica, Arial, メイリオ, meiryo, ヒラギノ角ゴ pro w3, hiragino kaku gothic pro, sans-serif;
      font-size: 14px;
      color: #20303C;
      line-height: 10px;
      letter-spacing: 0.05em;
      align-items: baseline;
      display: flex;
      white-space: nowrap; }
      .wix-ads-2 .mobile-top .content .wix-logo {
        fill: #20303C;
        vertical-align: middle;
        padding: 0 5px;
        height: 10.5px; }
        .wix-ads-2 .mobile-top .content .wix-logo > .dot {
          fill: #fc0; }
    .wix-ads-2 .mobile-top.one-app-banner .content {
      font-family: wixFreemiumFontW01-55Roma, wixFreemiumFontW02-55Roma, wixFreemiumFontW10-55Roma, Helvetica Neue, Helvetica, Arial, メイリオ, meiryo, ヒラギノ角ゴ pro w3, hiragino kaku gothic pro, sans-serif;
      font-size: 16px;
      color: #1c1c1c;
      line-height: 38px; }
    .wix-ads-2 .mobile-top.one-app-banner .wix-logo {
      padding: 0 2px 0 6px; }
    .wix-ads-2 .mobile-top.one-app-banner .download-logo {
      height: 22px;
      align-self: center;
      padding-left: 10px;
      margin-left: -4px; }

/*# sourceMappingURL=wix-freemuim-css-entry.css.map */</style><a class="desktop-top ltr" id="top" data-aid="WIX_ADSdesktopTop" style="height:50px;display:flex" href="//pt.wix.com/lpviral/pt900viral?utm_campaign=vir_wixad_live&amp;adsVersion=white&amp;orig_msid=ed554812-eecc-40de-ac38-0af295cb607b" target="_blank" rel="nofollow"><span class="contents"><span class="text">Este site foi desenvolvido com o construtor de sites <div style="direction: ltr; display: inline-flex"><div><svg class="wix-logo" viewBox="0 0 28 10.89" alt="wix"><path d="M16.02.2c-.55.3-.76.78-.76 2.14a2.17 2.17 0 0 1 .7-.42 3 3 0 0 0 .7-.4A1.62 1.62 0 0 0 17.22 0a3 3 0 0 0-1.18.2z" class="dot"></path><path d="M12.77.52a2.12 2.12 0 0 0-.58 1l-1.5 5.8-1.3-4.75a4.06 4.06 0 0 0-.7-1.55 2.08 2.08 0 0 0-2.9 0 4.06 4.06 0 0 0-.7 1.55L3.9 7.32l-1.5-5.8a2.12 2.12 0 0 0-.6-1A2.6 2.6 0 0 0 0 .02l2.9 10.83a3.53 3.53 0 0 0 1.42-.17c.62-.33.92-.57 1.3-2 .33-1.33 1.26-5.2 1.35-5.47a.5.5 0 0 1 .34-.4.5.5 0 0 1 .4.5c.1.3 1 4.2 1.4 5.5.4 1.5.7 1.7 1.3 2a3.53 3.53 0 0 0 1.4.2l2.8-11a2.6 2.6 0 0 0-1.82.53zm4.43 1.26a1.76 1.76 0 0 1-.58.5c-.26.16-.52.26-.8.4a.82.82 0 0 0-.57.82v7.36a2.47 2.47 0 0 0 1.2-.15c.6-.3.75-.6.75-2V1.8zm7.16 3.68L28 .06a3.22 3.22 0 0 0-2.3.42 8.67 8.67 0 0 0-1 1.24l-1.34 1.93a.3.3 0 0 1-.57 0l-1.4-1.93a8.67 8.67 0 0 0-1-1.24 3.22 3.22 0 0 0-2.3-.43l3.6 5.4-3.7 5.4a3.54 3.54 0 0 0 2.32-.48 7.22 7.22 0 0 0 1-1.16l1.33-1.9a.3.3 0 0 1 .57 0l1.37 2a8.2 8.2 0 0 0 1 1.2 3.47 3.47 0 0 0 2.33.5z"></path></svg></div><div class="com" >.com</div></div>. Crie seu site hoje.</span><span class="button ltr">Comece já</span></span></a></div><div id="aspectCompsContainer" class="siteAspectsContainer"><div style="position:absolute" id="popoverLayer"></div><wix-iframe style="top:;bottom:;left:;right:;position:;overflow:hidden;visibility:hidden" data-has-iframe="true" data-src="https://apps.wix.com/members-area/app-worker?cacheKiller=1596731300551&amp;commonConfig=%7B%22brand%22%3A%22wix%22%2C%22consentPolicy%22%3A%7B%22essential%22%3Atrue%2C%22functional%22%3Atrue%2C%22analytics%22%3Atrue%2C%22advertising%22%3Atrue%2C%22dataToThirdParty%22%3Atrue%7D%2C%22consentPolicyHeader%22%3A%7B%7D%7D&amp;compId=tpaWorker_3546&amp;consent-policy=%7B%7BconsentPolicy%7D%7D&amp;currency=BRL&amp;deviceType=desktop&amp;endpointType=worker&amp;instance=nOoGH--bmI1fRuM_1MOAn1VXlntMyDuvdglCAVAaRuI.eyJpbnN0YW5jZUlkIjoiNjA0Zjc0MTMtZTc3Ni00YzBlLWJhMTgtOGNlNGJiZjhiZTljIiwiYXBwRGVmSWQiOiIxNGNlMjhmNy03ZWIwLTM3NDUtMjJmOC0wNzRiMGUyNDAxZmIiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsImJpVG9rZW4iOiI4ZDFhM2MwMS0wOWJhLTBjZDAtMTYyMC04NjE2MmUzM2RlZTciLCJzaXRlT3duZXJJZCI6ImI3NTcwMzJmLWExY2ItNGMxYS1iMjM3LWUxMGMwYmY0NjljOCJ9&amp;locale=pt&amp;siteRevision=57&amp;tz=America%2FSao_Paulo&amp;viewMode=site&amp;viewerCompId=tpaWorker_3546" data-is-tpa="true" data-app-definition-id="14ce28f7-7eb0-3745-22f8-074b0e2401fb" id="tpaWorker_3546" class="s_DtaksTPAWidgetSkin"><iframe data-src="https://apps.wix.com/members-area/app-worker?cacheKiller=1596731300551&amp;commonConfig=%7B%22brand%22%3A%22wix%22%2C%22consentPolicy%22%3A%7B%22essential%22%3Atrue%2C%22functional%22%3Atrue%2C%22analytics%22%3Atrue%2C%22advertising%22%3Atrue%2C%22dataToThirdParty%22%3Atrue%7D%2C%22consentPolicyHeader%22%3A%7B%7D%7D&amp;compId=tpaWorker_3546&amp;consent-policy=%7B%7BconsentPolicy%7D%7D&amp;currency=BRL&amp;deviceType=desktop&amp;endpointType=worker&amp;instance=nOoGH--bmI1fRuM_1MOAn1VXlntMyDuvdglCAVAaRuI.eyJpbnN0YW5jZUlkIjoiNjA0Zjc0MTMtZTc3Ni00YzBlLWJhMTgtOGNlNGJiZjhiZTljIiwiYXBwRGVmSWQiOiIxNGNlMjhmNy03ZWIwLTM3NDUtMjJmOC0wNzRiMGUyNDAxZmIiLCJtZXRhU2l0ZUlkIjoiZWQ1NTQ4MTItZWVjYy00MGRlLWFjMzgtMGFmMjk1Y2I2MDdiIiwic2lnbkRhdGUiOiIyMDIwLTA4LTA2VDE3OjU4OjA3LjQ4MVoiLCJkZW1vTW9kZSI6ZmFsc2UsImFpZCI6Ijc4NjNmODA3LWIxZjAtNGVlZS1iZDNjLTQ2MDRjNzZlYzhkZCIsImJpVG9rZW4iOiI4ZDFhM2MwMS0wOWJhLTBjZDAtMTYyMC04NjE2MmUzM2RlZTciLCJzaXRlT3duZXJJZCI6ImI3NTcwMzJmLWExY2ItNGMxYS1iMjM3LWUxMGMwYmY0NjljOCJ9&amp;locale=pt&amp;siteRevision=57&amp;tz=America%2FSao_Paulo&amp;viewMode=site&amp;viewerCompId=tpaWorker_3546" scrolling="no" frameBorder="0" allow="autoplay; camera; microphone; geolocation; vr" allowtransparency="true" allowfullscreen="" name="tpaWorker_3546" style="display:none;position:absolute;z-index:" title="Profile Card" aria-label="Profile Card" id="tpaWorker_3546iframe" class="s_DtaksTPAWidgetSkiniframe"></iframe><div id="tpaWorker_3546overlay" class="s_DtaksTPAWidgetSkinoverlay"></div></wix-iframe></div><div id="SCROLL_TO_BOTTOM" tabindex="-1" aria-label="bottom of page" role="region" style="height:0"></div><script id="partiallyVisibleBeat">
                if (window.wixBiSession) {
                    wixBiSession.isUsingMesh = true;
                    if (wixBiSession.sendBeat) {
                        wixBiSession.sendBeat(12, 'Partially visible', '&pid=o0j6r');
                    }
                }
                if (window.requestCloseWelcomeScreen) {
                    requestCloseWelcomeScreen();
                }
            </script></div><div class="font-ruler-container" style="overflow:hidden;visibility:hidden;max-height:0;max-width:0;position:absolute"><style>.font-ruler-content::after {content:"@#$%%^&*~IAO"}</style><div style="position:absolute;overflow:hidden;font-size:1200px;left:-2000px;visibility:hidden"><div style="position:relative;white-space:nowrap;font-family:serif"><div style="position:absolute;width:100%;height:100%;overflow:hidden"><div></div></div><span class="font-ruler-content"></span></div></div><div style="position:absolute;overflow:hidden;font-size:1200px;left:-2000px;visibility:hidden"><div style="position:relative;white-space:nowrap;font-family:serif"><div style="position:absolute;width:100%;height:100%;overflow:hidden"><div></div></div><span class="font-ruler-content"></span></div></div></div></div>


    
    <script type="text/javascript">
        var warmupData = {"layoutData":{"displayedPagesData":{"o0j6r":{"structure":{"DESKTOP":{"o0j6r":{"id":"o0j6r","type":"Page","metaData":{"pageId":"o0j6r"},"componentType":"mobile.core.components.Page","skin":"wysiwyg.viewer.skins.page.TransparentPageSkin","dataQuery":"#o0j6r","layout":{"width":1423,"height":1496,"x":0,"y":0,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"p1","components":["comp-kdhlz5o0","comp-kdhgmi4e2","comp-kdhgmjf4"]},"comp-kdhlz5o0":{"id":"comp-kdhlz5o0","type":"Container","metaData":{"pageId":"o0j6r"},"parent":"o0j6r","componentType":"wysiwyg.viewer.components.StripColumnsContainer","propertyQuery":"propItem-kdhlz5o5","layout":{"width":1423,"height":520,"x":0,"y":0,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"designQuery":"#dataItem-kdhnwz3j2","styleId":"strc1","components":["comp-kdhlz5o1"]},"comp-kdhgmi4e2":{"id":"comp-kdhgmi4e2","type":"Container","metaData":{"pageId":"o0j6r"},"parent":"o0j6r","componentType":"wysiwyg.viewer.components.StripColumnsContainer","propertyQuery":"propItem-kdhgmi8d","layout":{"width":1423,"height":436,"x":0,"y":520,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"designQuery":"#dataItem-kdhnwz3j5","styleId":"strc1","components":["comp-kdhgmi4e3"]},"comp-kdhgmjf4":{"id":"comp-kdhgmjf4","type":"Container","metaData":{"pageId":"o0j6r"},"parent":"o0j6r","componentType":"wysiwyg.viewer.components.StripColumnsContainer","propertyQuery":"propItem-kdhgmk0b","layout":{"width":1423,"height":540,"x":0,"y":956,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"designQuery":"#dataItem-kdhnwz3j8","styleId":"strc1","components":["comp-kdhgmjf5"]},"comp-kdhlz5o1":{"id":"comp-kdhlz5o1","type":"Container","metaData":{"pageId":"o0j6r"},"parent":"comp-kdhlz5o0","componentType":"wysiwyg.viewer.components.Column","skin":"wysiwyg.viewer.skins.mediaContainer.DefaultMediaContainer","propertyQuery":"propItem-kdhlz5oc","layout":{"width":980,"height":520,"x":-1,"y":0,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"designQuery":"#dataItem-kdhlz5oc1","styleId":"mc1","components":["comp-kdhlz5o12"]},"comp-kdhgmi4e3":{"id":"comp-kdhgmi4e3","type":"Container","metaData":{"pageId":"o0j6r"},"parent":"comp-kdhgmi4e2","componentType":"wysiwyg.viewer.components.Column","skin":"wysiwyg.viewer.skins.mediaContainer.DefaultMediaContainer","propertyQuery":"propItem-kdhgmi8g","layout":{"width":980,"height":436,"x":-1,"y":0,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"designQuery":"#dataItem-kdhgmi8g1","styleId":"mc1","components":["comp-kdhgmi4f"]},"comp-kdhgmjf5":{"id":"comp-kdhgmjf5","type":"Container","metaData":{"pageId":"o0j6r"},"parent":"comp-kdhgmjf4","componentType":"wysiwyg.viewer.components.Column","skin":"wysiwyg.viewer.skins.mediaContainer.DefaultMediaContainer","propertyQuery":"propItem-kdhgmk0f","layout":{"width":980,"height":540,"x":-1,"y":0,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"designQuery":"#dataItem-kdhgmk0f1","styleId":"mc1","components":["comp-kdhgmjf51","comp-kdhgmjf53"]},"comp-kdhlz5o12":{"id":"comp-kdhlz5o12","type":"Component","metaData":{"pageId":"o0j6r"},"parent":"comp-kdhlz5o1","componentType":"tpa.viewer.components.StripSlideshow","skin":"wysiwyg.viewer.skins.TPAStripSlideshowSkin","dataQuery":"#dataItem-kdhlz5on","propertyQuery":"propItem-kdhlz5oo","layout":{"width":940,"height":520,"x":-222,"y":0,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"style-kdhlz5op"},"comp-kdhgmi4f":{"id":"comp-kdhgmi4f","type":"Component","metaData":{"pageId":"o0j6r"},"parent":"comp-kdhgmi4e3","componentType":"wysiwyg.viewer.components.tpapps.TPAWidgetNative","skin":"wysiwyg.viewer.skins.TPAWidgetSkin","dataQuery":"#dataItem-kdhgmiu1","layout":{"width":1423,"height":429,"x":-222,"y":0,"scale":1,"rotationInDegrees":0,"fixedPosition":false,"docked":{"left":{"px":0,"vw":0},"right":{"px":0,"vw":0}}},"styleId":"style-kdhgmj6m"},"comp-kdhgmjf51":{"id":"comp-kdhgmjf51","type":"Component","metaData":{"pageId":"o0j6r"},"parent":"comp-kdhgmjf5","componentType":"wysiwyg.viewer.components.WRichText","skin":"wysiwyg.viewer.skins.WRichTextNewSkin","dataQuery":"#dataItem-kdhgmk0j","propertyQuery":"propItem-kdhgmk0j1","layout":{"width":780,"height":54,"x":100,"y":124,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"txtNew"},"comp-kdhgmjf53":{"id":"comp-kdhgmjf53","type":"Component","metaData":{"pageId":"o0j6r"},"parent":"comp-kdhgmjf5","componentType":"wysiwyg.viewer.components.WRichText","skin":"wysiwyg.viewer.skins.WRichTextNewSkin","dataQuery":"#dataItem-kdhgmk0p","propertyQuery":"propItem-kdhgmk0p1","layout":{"width":780,"height":196,"x":100,"y":206,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"txtNew"}}},"data":{"behaviors_data":{},"connections_data":{},"document_data":{},"design_data":{"dataItem-kdhnwz3j2":{"type":"MediaContainerDesignData","id":"dataItem-kdhnwz3j2","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"1.0","isHidden":false},"background":{"type":"BackgroundMedia","id":"dataItem-kdhnwz3j1","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"1.0","isHidden":false},"color":"#FFFFFF","colorOpacity":0,"alignType":"center","fittingType":"fill","scrollType":"none","colorOverlay":"","colorOverlayOpacity":1}},"dataItem-kdhnwz3j5":{"type":"MediaContainerDesignData","id":"dataItem-kdhnwz3j5","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"1.0","isHidden":false},"background":{"type":"BackgroundMedia","id":"dataItem-kdhnwz3j4","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"1.0","isHidden":false},"color":"#FFFFFF","colorOpacity":0,"alignType":"center","fittingType":"fill","scrollType":"none","colorOverlay":"","colorOverlayOpacity":1}},"dataItem-kdhnwz3j8":{"type":"MediaContainerDesignData","id":"dataItem-kdhnwz3j8","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"1.0","isHidden":false},"background":{"type":"BackgroundMedia","id":"dataItem-kdhnwz3j7","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"1.0","isHidden":false},"color":"#FFFFFF","colorOpacity":0,"alignType":"center","fittingType":"fill","scrollType":"none","colorOverlay":"","colorOverlayOpacity":1}},"dataItem-kdhlz5oc1":{"type":"MediaContainerDesignData","id":"dataItem-kdhlz5oc1","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"1.0","isHidden":false},"background":{"type":"BackgroundMedia","id":"dataItem-kdhm1xtw1","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"1.0","isHidden":false},"color":"{color_11}","colorOpacity":1,"alignType":"center","fittingType":"fill","scrollType":"scroll","colorOverlay":"","colorOverlayOpacity":0},"charas":"design-kdhm1xtw","dataChangeBehaviors":[]},"dataItem-kdhgmi8g1":{"type":"MediaContainerDesignData","id":"dataItem-kdhgmi8g1","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"1.0","isHidden":false},"background":{"type":"BackgroundMedia","id":"dataItem-kdhgmi8g2","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"1.0","isHidden":false},"color":"{color_11}","colorOpacity":1,"alignType":"center","fittingType":"fill","scrollType":"scroll","colorOverlay":"","colorOverlayOpacity":0}},"dataItem-kdhgmk0f1":{"type":"MediaContainerDesignData","id":"dataItem-kdhgmk0f1","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"1.0","isHidden":false},"background":{"type":"BackgroundMedia","id":"dataItem-kdhm18y51","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"1.0","isHidden":false},"color":"{color_32}","colorOpacity":1,"alignType":"center","fittingType":"fill","scrollType":"scroll","colorOverlay":"","colorOverlayOpacity":0},"charas":"design-kdhm18y5","dataChangeBehaviors":[]}},"mobile_hints":{},"component_properties":{},"anchors_data":{},"breakpoints_data":{},"layout_data":{},"variants_data":{},"theme_data":{},"transformations_data":{},"transitions_data":{}}},"masterPage":{"structure":{"DESKTOP":{"SITE_FOOTER":{"id":"SITE_FOOTER","type":"Container","metaData":{"pageId":"masterPage"},"parent":"masterPage","componentType":"wysiwyg.viewer.components.FooterContainer","skin":"wysiwyg.viewer.skins.screenwidthcontainer.TransparentScreen","layout":{"width":980,"height":215,"x":0,"y":1776,"scale":1,"rotationInDegrees":0,"fixedPosition":false,"overflow":"hidden"},"styleId":"fc1","components":["comp-kdhleess","comp-kdgakdub","comp-kdhglxvo","comp-kdhld9nv","comp-kdgakdub1"]},"comp-kdhld9nv":{"id":"comp-kdhld9nv","type":"Container","metaData":{"pageId":"masterPage"},"parent":"SITE_FOOTER","componentType":"wysiwyg.viewer.components.StripColumnsContainer","propertyQuery":"propItem-kdhlda0p","layout":{"width":1423,"height":35,"x":0,"y":178,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"designQuery":"#dataItem-kdhnwz482","styleId":"strc1","components":["comp-kdhld9nw"]},"SITE_HEADER":{"id":"SITE_HEADER","type":"Container","metaData":{"pageId":"masterPage"},"parent":"masterPage","componentType":"wysiwyg.viewer.components.HeaderContainer","skin":"wysiwyg.viewer.skins.screenwidthcontainer.TransparentScreen","layout":{"width":980,"height":280,"x":0,"y":0,"scale":1,"rotationInDegrees":0,"fixedPosition":false,"zIndex":50},"styleId":"hc1","components":["comp-kdhjqs1y","comp-kdgakdu1","comp-kdhmasr3"]},"comp-kdhjqs1y":{"id":"comp-kdhjqs1y","type":"Container","metaData":{"pageId":"masterPage"},"parent":"SITE_HEADER","componentType":"wysiwyg.viewer.components.StripColumnsContainer","skin":"wysiwyg.viewer.skins.stripContainer.DefaultStripContainer","propertyQuery":"propItem-kdhjqs30","layout":{"width":1303,"height":36,"x":0,"y":30,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"designQuery":"#dataItem-kdhnwz492","styleId":"strc1","components":["comp-kdhjqs1y1","comp-kdhjqs1z"]},"comp-kdhmasr3":{"id":"comp-kdhmasr3","type":"Container","metaData":{"pageId":"masterPage"},"parent":"SITE_HEADER","componentType":"wysiwyg.viewer.components.StripColumnsContainer","skin":"wysiwyg.viewer.skins.stripContainer.DefaultStripContainer","propertyQuery":"propItem-kdhmass3","layout":{"width":1303,"height":180,"x":0,"y":70,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"designQuery":"#dataItem-kdhnwz495","styleId":"strc1","components":["comp-kdhmasr31","comp-kdhmasr4"]},"comp-kdhld9nw":{"id":"comp-kdhld9nw","type":"Container","metaData":{"pageId":"masterPage"},"parent":"comp-kdhld9nv","componentType":"wysiwyg.viewer.components.Column","skin":"wysiwyg.viewer.skins.mediaContainer.DefaultMediaContainer","propertyQuery":"propItem-kdhlda0y","layout":{"width":980,"height":35,"x":-1,"y":0,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"designQuery":"#dataItem-kdhlda0z","styleId":"mc1","components":[]},"comp-kdhjqs1y1":{"id":"comp-kdhjqs1y1","type":"Container","metaData":{"pageId":"masterPage"},"parent":"comp-kdhjqs1y","componentType":"wysiwyg.viewer.components.Column","skin":"wysiwyg.viewer.skins.mediaContainer.DefaultMediaContainer","propertyQuery":"propItem-kdhjqs34","layout":{"width":20,"height":36,"x":-162,"y":0,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"designQuery":"#dataItem-kdhjqs341","styleId":"mc1","components":[]},"comp-kdhjqs1z":{"id":"comp-kdhjqs1z","type":"Container","metaData":{"pageId":"masterPage"},"parent":"comp-kdhjqs1y","componentType":"wysiwyg.viewer.components.Column","skin":"wysiwyg.viewer.skins.mediaContainer.DefaultMediaContainer","propertyQuery":"propItem-kdhjqs38","layout":{"width":960,"height":36,"x":181,"y":0,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"designQuery":"#dataItem-kdhjqs381","styleId":"mc1","components":["comp-kdhjooyy","comp-kdgakvfd"]},"comp-kdhmasr31":{"id":"comp-kdhmasr31","type":"Container","metaData":{"pageId":"masterPage"},"parent":"comp-kdhmasr3","componentType":"wysiwyg.viewer.components.Column","skin":"wysiwyg.viewer.skins.mediaContainer.DefaultMediaContainer","propertyQuery":"propItem-kdhmass8","layout":{"width":592,"height":180,"x":-162,"y":0,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"designQuery":"#dataItem-kdhmass81","styleId":"mc1","components":["comp-kdhmasr32","comp-kdhmasr33"]},"comp-kdhmasr4":{"id":"comp-kdhmasr4","type":"Container","metaData":{"pageId":"masterPage"},"parent":"comp-kdhmasr3","componentType":"wysiwyg.viewer.components.Column","skin":"wysiwyg.viewer.skins.mediaContainer.DefaultMediaContainer","propertyQuery":"propItem-kdhmassu","layout":{"width":388,"height":180,"x":753,"y":0,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"designQuery":"#dataItem-kdhmassv","styleId":"mc1","components":["comp-kdhmau0v","comp-kdhmasr41"]},"SITE_BACKGROUND":{"id":"SITE_BACKGROUND","metaData":{"pageId":"masterPage"},"parent":"BOLT_SITE","componentType":"wysiwyg.viewer.components.SiteBackground","skin":"wysiwyg.viewer.skins.siteBackgroundSkin","layout":{},"styleId":"siteBackground"},"masterPage":{"id":"masterPage","type":"Document","metaData":{"pageId":"masterPage"},"componentType":"mobile.core.components.MasterPage","dataQuery":"#masterPage","modes":{"definitions":[{"type":"SHOW_ON_SOME_PAGES","modeId":"masterPage-mode-kdhjouho","label":"SOSP-members_pages_group","settings":{"pagesGroupId":"#dataItem-kdhjoowu"}}],"overrides":[]},"layout":{"y":0,"rotationInDegrees":0,"anchors":[{"distance":0,"type":"BOTTOM_TOP","locked":false,"targetComponent":"PAGES_CONTAINER"}]},"components":["SITE_FOOTER","PAGES_CONTAINER","CONTROLLER_COMP_CUSTOM_ID","SITE_HEADER","comp-kdgakqt5"]},"PAGES_CONTAINER":{"id":"PAGES_CONTAINER","type":"Container","metaData":{"pageId":"masterPage"},"parent":"masterPage","componentType":"wysiwyg.viewer.components.PagesContainer","skin":"wysiwyg.viewer.skins.screenwidthcontainer.BlankScreen","layout":{"width":980,"height":1496,"x":0,"y":280,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"pc1","components":["SITE_PAGES"]},"comp-kdgakqt5":{"id":"comp-kdgakqt5","type":"Component","metaData":{"pageId":"masterPage"},"parent":"masterPage","componentType":"wysiwyg.viewer.components.tpapps.TPAGluedWidget","skin":"wysiwyg.viewer.skins.TPAWidgetSkin","dataQuery":"#dataItem-kdgakro2","propertyQuery":"propItem-kdgakro3","layout":{"width":376,"height":70,"x":1047,"y":671,"scale":1,"rotationInDegrees":0,"fixedPosition":true,"zIndex":52},"styleId":"tpagw0"},"comp-kdhleess":{"id":"comp-kdhleess","type":"Component","metaData":{"pageId":"masterPage"},"parent":"SITE_FOOTER","componentType":"wysiwyg.viewer.components.WRichText","skin":"wysiwyg.viewer.skins.WRichTextNewSkin","dataQuery":"#dataItem-kdhlef7e","propertyQuery":"propItem-kdhlef7f","layout":{"width":193,"height":28,"x":20,"y":48,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"txtNew"},"comp-kdgakdub":{"id":"comp-kdgakdub","type":"Component","metaData":{"pageId":"masterPage"},"parent":"SITE_FOOTER","componentType":"wysiwyg.viewer.components.WRichText","skin":"wysiwyg.viewer.skins.WRichTextNewSkin","dataQuery":"#dataItem-kdgakfz5","propertyQuery":"propItem-kdgakfzh","layout":{"width":146,"height":28,"x":20,"y":76,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"txtNew"},"comp-kdhglxvo":{"id":"comp-kdhglxvo","type":"Component","metaData":{"pageId":"masterPage"},"parent":"SITE_FOOTER","componentType":"wysiwyg.viewer.components.tpapps.TPAWidget","skin":"wysiwyg.viewer.skins.TPAWidgetSkin","dataQuery":"#dataItem-kdhglye6","layout":{"width":450,"height":103,"x":532,"y":37,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"style-kdhglyer"},"comp-kdgakdub1":{"id":"comp-kdgakdub1","type":"Component","metaData":{"pageId":"masterPage"},"parent":"SITE_FOOTER","componentType":"wysiwyg.viewer.components.WRichText","skin":"wysiwyg.viewer.skins.WRichTextNewSkin","dataQuery":"#dataItem-kdgakg09","propertyQuery":"propItem-kdgakg0a","layout":{"width":486,"height":25,"x":20,"y":183,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"txtNew"},"comp-kdgakdu1":{"id":"comp-kdgakdu1","type":"Component","metaData":{"pageId":"masterPage"},"parent":"SITE_HEADER","componentType":"wysiwyg.viewer.components.FiveGridLine","skin":"wysiwyg.viewer.skins.line.SolidLine","propertyQuery":"propItem-kdgake1r","layout":{"width":1263,"height":5,"x":-142,"y":69,"scale":1,"rotationInDegrees":0,"fixedPosition":false,"docked":{"left":{"px":80,"vw":0},"right":{"px":80,"vw":0}}},"styleId":"style-kdgake21"},"SITE_PAGES":{"id":"SITE_PAGES","type":"Container","metaData":{"pageId":"masterPage"},"parent":"PAGES_CONTAINER","componentType":"wysiwyg.viewer.components.PageGroup","skin":"wysiwyg.viewer.skins.PageGroupSkin","propertyQuery":"SITE_PAGES","layout":{"width":980,"height":1496,"x":0,"y":0,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"components":[]},"CONTROLLER_COMP_CUSTOM_ID":{"id":"CONTROLLER_COMP_CUSTOM_ID","type":"Component","metaData":{"pageId":"masterPage"},"parent":"masterPage","componentType":"platform.components.AppController","skin":"platform.components.skins.controllerSkin","dataQuery":"#CONTROLLER_COMP_CUSTOM_ID","layout":{"width":60,"height":96,"x":20,"y":15,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"style-kdhjonrb"},"SOSP_CONTAINER_CUSTOM_ID":{"id":"SOSP_CONTAINER_CUSTOM_ID","type":"Container","metaData":{"pageId":"masterPage"},"parent":false,"componentType":"wysiwyg.viewer.components.SiteRegionContainer","modes":{"overrides":[{"modeIds":["masterPage-mode-kdhjouho"],"isHiddenByModes":false}],"isHiddenByModes":true},"layout":{"width":291,"height":317,"x":0,"y":221,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"style-kdhjoof7","components":["comp-kdhjoozf","comp-kdhjopim"]},"comp-kdhjoozf":{"id":"comp-kdhjoozf","type":"Component","metaData":{"pageId":"masterPage"},"parent":"SOSP_CONTAINER_CUSTOM_ID","componentType":"wysiwyg.common.components.verticalmenu.viewer.VerticalMenu","dataQuery":"#dataItem-kdhjop0a","connectionQuery":"connection-kdhjopja","propertyQuery":"propItem-kdhjop0b","layout":{"width":250,"height":162,"x":20,"y":95,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"style-kdhjop0c"},"comp-kdhjooyy":{"id":"comp-kdhjooyy","type":"Component","metaData":{"pageId":"masterPage"},"parent":"comp-kdhjqs1z","componentType":"wysiwyg.viewer.components.LoginSocialBar","skin":"wysiwyg.viewer.skins.LoginSocialBarSkin","dataQuery":"#dataItem-kdhjoozp","connectionQuery":"connection-kdhjoozx","propertyQuery":"propItem-kdhjoozs","layout":{"width":220,"height":40,"x":689,"y":-4,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"style-kdhjoozt"},"comp-kdhmasr41":{"id":"comp-kdhmasr41","type":"Component","metaData":{"pageId":"masterPage"},"parent":"comp-kdhmasr4","componentType":"wysiwyg.viewer.components.LinkBar","skin":"wysiwyg.viewer.skins.LinkBarNoBGSkin","dataQuery":"#dataItem-kdhmassy","propertyQuery":"propItem-kdhmast0","layout":{"width":50,"height":20,"x":318,"y":90,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"lb1"},"comp-kdgakvfd":{"id":"comp-kdgakvfd","type":"Component","metaData":{"pageId":"masterPage"},"parent":"comp-kdhjqs1z","componentType":"wysiwyg.viewer.components.tpapps.TPAWidgetNative","skin":"wysiwyg.viewer.skins.TPAWidgetSkin","dataQuery":"#dataItem-kdgakvfh","layout":{"width":24,"height":20,"x":916,"y":5,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"style-kdhglxy7"},"comp-kdhmasr32":{"id":"comp-kdhmasr32","type":"Component","metaData":{"pageId":"masterPage"},"parent":"comp-kdhmasr31","componentType":"wysiwyg.viewer.components.WPhoto","skin":"wysiwyg.viewer.skins.photo.NoSkinPhoto","dataQuery":"#dataItem-kdhmassf","propertyQuery":"propItem-kdhmassg","layout":{"width":227,"height":160,"x":20,"y":20,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"wp1"},"comp-kdhmasr33":{"id":"comp-kdhmasr33","type":"Component","metaData":{"pageId":"masterPage"},"parent":"comp-kdhmasr31","componentType":"wysiwyg.viewer.components.WRichText","skin":"wysiwyg.viewer.skins.WRichTextNewSkin","dataQuery":"#dataItem-kdhmassj","propertyQuery":"propItem-kdhmassk","layout":{"width":330,"height":28,"x":262,"y":81,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"txtNew"},"comp-kdhmau0v":{"id":"comp-kdhmau0v","type":"Component","metaData":{"pageId":"masterPage"},"parent":"comp-kdhmasr4","componentType":"wysiwyg.viewer.components.menus.DropDownMenu","skin":"wysiwyg.common.components.dropdownmenu.viewer.skins.TextOnlyMenuButtonSkin","dataQuery":"#dataItem-kdhmau1c","propertyQuery":"propItem-kdhmau1c1","layout":{"width":216,"height":30,"x":92,"y":85,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"style-kdhmau1d"},"comp-kdhjopim":{"id":"comp-kdhjopim","type":"Component","metaData":{"pageId":"masterPage"},"parent":"SOSP_CONTAINER_CUSTOM_ID","componentType":"wysiwyg.viewer.components.tpapps.TPAWidget","skin":"wysiwyg.viewer.skins.TPAWidgetSkin","dataQuery":"#dataItem-kdhjoptb","layout":{"width":250,"height":186,"x":20,"y":60,"scale":1,"rotationInDegrees":0,"fixedPosition":false},"styleId":"tpaw0"}}},"data":{"behaviors_data":{},"connections_data":{},"document_data":{"o0j6r":{"type":"Page","id":"o0j6r","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"2.0","isHidden":false},"title":"Início","hideTitle":true,"icon":"","descriptionSEO":"Um portal que se destina a prestação de serviços de divulgação, anúncios exclusivos para empresas que querem anunciar seus produtos e serviços.","metaKeywordsSEO":"Aqui perto, produtos, região, pertinho, perto, todo negócio","pageTitleSEO":"Início | Todo Negócio AKI Pertinho","pageUriSEO":"início","hidePage":false,"isMobileLandingPage":false,"underConstruction":false,"tpaApplicationId":0,"pageSecurity":{"requireLogin":false,"passwordDigest":"","dialogLanguage":""},"isPopup":false,"indexable":true,"isLandingPage":false,"pageBackgrounds":{"desktop":{"custom":true,"ref":{"type":"BackgroundMedia","id":"o0j6r_desktop_bg","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"2.0","isHidden":false},"color":"{color_11}","alignType":"top","fittingType":"fill","scrollType":"fixed"},"isPreset":true},"mobile":{"custom":true,"ref":{"type":"BackgroundMedia","id":"o0j6r_mobile_bg","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"2.0","isHidden":false},"color":"{color_11}","alignType":"top","fittingType":"fill","scrollType":"fixed"},"isPreset":true,"mediaSizing":"viewport"}},"translationData":{"uriSEOTranslated":false}},"dataItem-kdgakro2":{"type":"TPAWidget","id":"dataItem-kdgakro2","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"applicationId":"1552","appDefinitionId":"14517e1a-3ff0-af98-408e-2bd6953c36a2","widgetId":"14517f3f-ffc5-eced-f592-980aaa0bbb5c"},"dataItem-kdhglye6":{"type":"TPAWidget","id":"dataItem-kdhglye6","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"applicationId":"1104","appDefinitionId":"1375baa8-8eca-5659-ce9d-455b2009250d","tpaData":{"type":"TPAData","id":"tpaData-kdhglyet","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"content":"{\"settings\":{\"version\":10,\"language\":\"pt\",\"generalSettings\":{\"subscriptionNotifications\":true,\"collectName\":false,\"collectPhone\":false,\"nameRequired\":false,\"phoneRequired\":false,\"namePlaceholder\":\"\",\"phonePlaceholder\":\"\",\"emailPlaceholder\":\"\"},\"signupForm\":{\"showTitle\":true,\"showSubtitle\":false,\"titleText\":\"Formulário de Assinatura\",\"subtitleText\":\"Mantenha-se atualizado\",\"buttonText\":\"Enviar\",\"thankYouTitleText\":\"\",\"thankYouSubtitleText\":\"\",\"layout\":0},\"popup\":{\"showPopup\":false,\"showPopupOnEveryVisitForNonSubscriber\":true,\"hideFormIfSubscribedViaPopup\":true,\"popupTimer\":5,\"showSubtitle\":true,\"popupTitleText\":\"\",\"popupSubtitleText\":\"\",\"popupButtonText\":\"\",\"popupThankYouTitle\":\"\",\"popupThankYouSubtitle\":\"\"},\"style\":{\"appStyle\":1,\"headerAlignment\":0,\"bodyAlignment\":0,\"buttonAlignment\":1},\"gdpr\":{\"requireConsent\":false,\"consentMessage\":\"\",\"isPrivacyPolicyLinkEnabled\":false,\"policyLinkText\":\"\",\"policyLinkUrl\":\"https:\/\/\"}}}"},"widgetId":"1375babd-6f2b-87ed-ff19-5778602c8b86"},"masterPage":{"type":"Document","id":"masterPage","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"siteName":"Template Base","mainPage":{"type":"Page","id":"o0j6r","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"2.0","isHidden":false},"title":"Início","hideTitle":true,"icon":"","descriptionSEO":"Um portal que se destina a prestação de serviços de divulgação, anúncios exclusivos para empresas que querem anunciar seus produtos e serviços.","metaKeywordsSEO":"Aqui perto, produtos, região, pertinho, perto, todo negócio","pageTitleSEO":"Início | Todo Negócio AKI Pertinho","pageUriSEO":"início","hidePage":false,"isMobileLandingPage":false,"underConstruction":false,"tpaApplicationId":0,"pageSecurity":{"requireLogin":false,"passwordDigest":"","dialogLanguage":""},"isPopup":false,"indexable":true,"isLandingPage":false,"pageBackgrounds":{"desktop":{"custom":true,"ref":{"type":"BackgroundMedia","id":"o0j6r_desktop_bg","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"2.0","isHidden":false},"color":"{color_11}","alignType":"top","fittingType":"fill","scrollType":"fixed"},"isPreset":true},"mobile":{"custom":true,"ref":{"type":"BackgroundMedia","id":"o0j6r_mobile_bg","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"2.0","isHidden":false},"color":"{color_11}","alignType":"top","fittingType":"fill","scrollType":"fixed"},"isPreset":true,"mediaSizing":"viewport"}},"translationData":{"uriSEOTranslated":false}},"mainPageId":"o0j6r","renderModifiers":{"pageAutoShrink":true},"characterSets":["hebrew","arabic","latin"],"usedFonts":[],"smSettings":{"smFirstDialogLogin":false,"socialLoginGoogleEnabled":true,"socialLoginFacebookEnabled":true,"termsOfUse":{"enabled":false},"privacyPolicy":{"enabled":false},"customNoPermissionsPageId":"fnpl6"},"accessibilitySettings":{"visualFocusDisabled":false},"layoutSettings":{"useDesktopSectionsLayout":true,"mechanism":"mesh","soapCompsAroundPagesContainer":true},"styleSettings":{"stylesPerPage":"1.0"},"mobileSettings":{"animationsEnabled":false}},"dataItem-kdhjoozp":{"type":"LoginSocialBar","id":"dataItem-kdhjoozp","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"menuItemsRef":{"type":"CustomMenuDataRef","id":"dataItem-kdhnubc3","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"menuRef":{"type":"CustomMenu","id":"MEMBERS_LOGIN_MENU","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"name":"Login Menu","items":[{"type":"BasicMenuItem","id":"dataItem-kdhjowlc","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"label":"Meus pedidos","isVisible":true,"isVisibleMobile":true,"items":[],"link":{"type":"DynamicPageLink","id":"dataItem-kdhjowlc1","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"routerId":"routers-kdhjontm","innerRoute":"my-orders"}},{"type":"BasicMenuItem","id":"dataItem-kdhjowlc2","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"label":"Meus endereços","isVisible":true,"isVisibleMobile":true,"items":[],"link":{"type":"DynamicPageLink","id":"dataItem-kdhjowlc3","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"routerId":"routers-kdhjontm","innerRoute":"my-addresses"}},{"type":"BasicMenuItem","id":"dataItem-kdhjowld","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"label":"Minha carteira","isVisible":true,"isVisibleMobile":true,"items":[],"link":{"type":"DynamicPageLink","id":"dataItem-kdhjowld1","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"routerId":"routers-kdhjontm","innerRoute":"my-wallet"}},{"type":"BasicMenuItem","id":"dataItem-kdhjot8c","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"label":"Minha conta","isVisible":true,"isVisibleMobile":true,"items":[],"link":{"type":"DynamicPageLink","id":"dataItem-kdhjot8c1","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"routerId":"routers-kdhjontm","innerRoute":"my-account"}}],"appId":3035,"syncWithPages":false}},"iconItemsRef":{"type":"CustomMenuDataRef","id":"dataItem-kdhnubc4","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"menuRef":{"type":"CustomMenu","id":"MEMBERS_LOGIN_ICONS_MENU","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"name":"Login Icons","items":[],"appId":3035,"syncWithPages":false}},"logOutText":"Log Out","loggedOutText":"Log In","loggedInText":"","loggedInMember":"textOnly","language":"pt","showLoggedInText":false},"dataItem-kdhmassf":{"type":"Image","id":"dataItem-kdhmassf","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"title":"","uri":"b75703_43677f9c7e074ee19ae3822f2908427f~mv2.png","description":"","width":2048,"height":1442,"alt":"5.png","name":"5.png","link":{"type":"PageLink","id":"dataItem-kdhmassf1","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"pageId":{"type":"Page","id":"o0j6r","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"2.0","isHidden":false},"title":"Início","hideTitle":true,"icon":"","descriptionSEO":"Um portal que se destina a prestação de serviços de divulgação, anúncios exclusivos para empresas que querem anunciar seus produtos e serviços.","metaKeywordsSEO":"Aqui perto, produtos, região, pertinho, perto, todo negócio","pageTitleSEO":"Início | Todo Negócio AKI Pertinho","pageUriSEO":"início","hidePage":false,"isMobileLandingPage":false,"underConstruction":false,"tpaApplicationId":0,"pageSecurity":{"requireLogin":false,"passwordDigest":"","dialogLanguage":""},"isPopup":false,"indexable":true,"isLandingPage":false,"pageBackgrounds":{"desktop":{"custom":true,"ref":{"type":"BackgroundMedia","id":"o0j6r_desktop_bg","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"2.0","isHidden":false},"color":"{color_11}","alignType":"top","fittingType":"fill","scrollType":"fixed"},"isPreset":true},"mobile":{"custom":true,"ref":{"type":"BackgroundMedia","id":"o0j6r_mobile_bg","metaData":{"pageId":"o0j6r","isPreset":false,"schemaVersion":"2.0","isHidden":false},"color":"{color_11}","alignType":"top","fittingType":"fill","scrollType":"fixed"},"isPreset":true,"mediaSizing":"viewport"}},"translationData":{"uriSEOTranslated":false}},"target":"_self"},"displayMode":"fit"},"dataItem-kdhjoptb":{"type":"TPAWidget","id":"dataItem-kdhjoptb","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"applicationId":"3546","appDefinitionId":"14ce28f7-7eb0-3745-22f8-074b0e2401fb","widgetId":"14cefc05-d163-dbb7-e4ec-cd4f2c4d6ddd"}},"design_data":{"dataItem-kdhnwz482":{"type":"MediaContainerDesignData","id":"dataItem-kdhnwz482","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"background":{"type":"BackgroundMedia","id":"dataItem-kdhnwz481","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"color":"#FFFFFF","colorOpacity":0,"alignType":"center","fittingType":"fill","scrollType":"none","colorOverlay":"","colorOverlayOpacity":1}},"dataItem-kdhnwz492":{"type":"MediaContainerDesignData","id":"dataItem-kdhnwz492","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"background":{"type":"BackgroundMedia","id":"dataItem-kdhnwz491","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"color":"#FFFFFF","colorOpacity":0,"alignType":"center","fittingType":"fill","scrollType":"none","colorOverlay":"","colorOverlayOpacity":1}},"dataItem-kdhnwz495":{"type":"MediaContainerDesignData","id":"dataItem-kdhnwz495","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"background":{"type":"BackgroundMedia","id":"dataItem-kdhnwz494","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"color":"#FFFFFF","colorOpacity":0,"alignType":"center","fittingType":"fill","scrollType":"none","colorOverlay":"","colorOverlayOpacity":1}},"dataItem-kdhlda0z":{"type":"MediaContainerDesignData","id":"dataItem-kdhlda0z","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"background":{"type":"BackgroundMedia","id":"dataItem-kdhlda0z1","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"color":"{color_27}","colorOpacity":1,"alignType":"center","fittingType":"fill","scrollType":"scroll","colorOverlay":"","colorOverlayOpacity":0}},"dataItem-kdhjqs341":{"type":"MediaContainerDesignData","id":"dataItem-kdhjqs341","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"background":{"type":"BackgroundMedia","id":"dataItem-kdhjqs35","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"color":"","colorOpacity":0,"fittingType":"fill","scrollType":"none","colorOverlay":"","colorOverlayOpacity":0}},"dataItem-kdhjqs381":{"type":"MediaContainerDesignData","id":"dataItem-kdhjqs381","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"background":{"type":"BackgroundMedia","id":"dataItem-kdhjqs382","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"color":"","colorOpacity":0,"fittingType":"fill","scrollType":"none","colorOverlay":"","colorOverlayOpacity":0}},"dataItem-kdhmass81":{"type":"MediaContainerDesignData","id":"dataItem-kdhmass81","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"background":{"type":"BackgroundMedia","id":"dataItem-kdhmass82","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"color":"","colorOpacity":0,"fittingType":"fill","scrollType":"none","colorOverlay":"","colorOverlayOpacity":0}},"dataItem-kdhmassv":{"type":"MediaContainerDesignData","id":"dataItem-kdhmassv","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"background":{"type":"BackgroundMedia","id":"dataItem-kdhmassv1","metaData":{"pageId":"masterPage","isPreset":false,"schemaVersion":"1.0","isHidden":false},"color":"","colorOpacity":0,"fittingType":"fill","scrollType":"none","colorOverlay":"","colorOverlayOpacity":0}}},"mobile_hints":{},"component_properties":{},"anchors_data":{},"breakpoints_data":{},"layout_data":{},"variants_data":{},"theme_data":{},"transformations_data":{},"transitions_data":{}}}},"anchorsMap":null,"ssr":{"shouldRenderPage":true,"aspectsComponentStructures":{"POPOVER_LAYER":{"componentType":"PopoverLayer","metaData":{"pageId":"PopoverAspect"},"parent":"aspectCompsContainer"},"tpaWorker_3546":{"componentType":"tpa.viewer.classes.TPAWorker","skin":"wysiwyg.viewer.skins.TPAWidgetSkin","type":"Component","id":"tpaWorker_3546","metaData":{"pageId":"tpaPostMessageAspect"},"parent":"aspectCompsContainer"}}},"currentUrl":{"full":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho","protocol":"https:","host":"igrejaevredencao74.wixsite.com","hostname":"igrejaevredencao74.wixsite.com","port":"","path":"\/akipertinho","search":"","hash":"","query":{}},"isMobileView":false,"siteMemberDetails":null,"isPageAllowed":true,"browserFlags":{"highlightAnchorsInMenu":true,"fixedSiteBackground":true,"animateRevealScrubAction":false,"animateParallaxScrubAction":false,"animateTinyMenuIcon":true,"preserve3DParallaxScrubAction":true,"fixedBackgroundColorBalata":true,"forceOverflowScroll":false,"doubleResetMobileViewport":false,"shouldDisableSmoothScrolling":true,"mixBlendModeSupported":true,"cssGridSupported":true,"svgImageOnLoadEvent":true,"cssFiltersSupported":true,"cssClipPathSupported":true,"cssVariablesSupported":true,"webpImageSupported":true,"webglCrossOriginSupported":true,"webglVideoTextureSupported":true,"useDropShadowFilterOnVideo":false,"cssFeatureQueriesSupported":true}},"svgShapes":{"3d84bae5ad4d4d8a96de15e9f4b79a08.svg":{"content":"<svg data-bbox=\"0 0 50 50\" data-type=\"shape\" xmlns=\"http:\/\/www.w3.org\/2000\/svg\" width=\"50\" height=\"50\" viewBox=\"0 0 50 50\">\n    <g>\n        <path d=\"M25 48.077c-5.924 0-11.31-2.252-15.396-5.921 2.254-5.362 7.492-8.267 15.373-8.267 7.889 0 13.139 3.044 15.408 8.418-4.084 3.659-9.471 5.77-15.385 5.77m.278-35.3c4.927 0 8.611 3.812 8.611 8.878 0 5.21-3.875 9.456-8.611 9.456s-8.611-4.246-8.611-9.456c0-5.066 3.684-8.878 8.611-8.878M25 0C11.193 0 0 11.193 0 25c0 .915.056 1.816.152 2.705.032.295.091.581.133.873.085.589.173 1.176.298 1.751.073.338.169.665.256.997.135.515.273 1.027.439 1.529.114.342.243.675.37 1.01.18.476.369.945.577 1.406.149.331.308.657.472.98.225.446.463.883.714 1.313.182.312.365.619.56.922.272.423.56.832.856 1.237.207.284.41.568.629.841.325.408.671.796 1.02 1.182.22.244.432.494.662.728.405.415.833.801 1.265 1.186.173.154.329.325.507.475l.004-.011A24.886 24.886 0 0 0 25 50a24.881 24.881 0 0 0 16.069-5.861.126.126 0 0 1 .003.01c.172-.144.324-.309.49-.458.442-.392.88-.787 1.293-1.209.228-.232.437-.479.655-.72.352-.389.701-.78 1.028-1.191.218-.272.421-.556.627-.838.297-.405.587-.816.859-1.24a26.104 26.104 0 0 0 1.748-3.216c.208-.461.398-.93.579-1.406.127-.336.256-.669.369-1.012.167-.502.305-1.014.44-1.53.087-.332.183-.659.256-.996.126-.576.214-1.164.299-1.754.042-.292.101-.577.133-.872.095-.89.152-1.791.152-2.707C50 11.193 38.807 0 25 0\"\/>\n    <\/g>\n<\/svg>\n","info":{"svgType":"shape","viewBox":"0 0 50 50","bbox":"0 0 50 50"},"boxBoundaries":{}}},"animationData":{},"rootNavigationInfo":{"format":"slash","pageId":"o0j6r","title":"início"},"currentUrl":{"full":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho","protocol":"https:","host":"igrejaevredencao74.wixsite.com","hostname":"igrejaevredencao74.wixsite.com","port":"","path":"\/akipertinho","search":"","hash":"","query":{}},"userWarmup":{},"runtime":{"data":{"behaviors_data":{},"connections_data":{},"document_data":{},"design_data":{},"mobile_hints":{},"component_properties":{},"anchors_data":{},"breakpoints_data":{},"layout_data":{},"variants_data":{},"theme_data":{},"transformations_data":{},"transitions_data":{}},"state":{}},"wixappsCoreWarmup":{"appbuilder":{},"faq":{},"news":{},"menu":{},"blog":{}},"wixappsClassicsWarmup":{"warmup":{"failedRequests":{}},"metadata":{"items":{},"descriptor":{},"isCategoriesLoaded":false,"videoThumbnails":{}}},"listBuilderWarmup":{"warmup":{"requestFailed":false},"metadata":{"items":{}}},"tpaWidgetNativeInitData":{"comp-kdgakvfd":{"events":{"onFocusTriggered":{"callbackId":"comp-kdgakvfd-onFocusTriggered","contextId":"o0j6r"},"onIconClick":{"callbackId":"comp-kdgakvfd-onIconClick","contextId":"o0j6r"},"onAppLoaded":{"callbackId":"comp-kdgakvfd-onAppLoaded","contextId":"o0j6r"}},"wixCodeProps":{"count":0,"ariaLabelLink":"Carrinho com 0 itens","cartLink":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho\/cart-page","isInteractive":false,"isLoaded":true,"triggerFocus":false,"isNavigate":false,"cssBaseUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-cart-icon\/1.678.0\/","ravenUserContextOverrides":{"id":"ed5f9768-c20d-4c70-8f9f-7cc59fbf7d11","uuid":"ed8c7760-25b0-4b04-9ec5-de4ddc0e64a8"}}},"comp-kdhgmi4f":{"events":{"getCategoryProducts":{"callbackId":"comp-kdhgmi4f-getCategoryProducts","contextId":"o0j6r"},"handleProductItemClick":{"callbackId":"comp-kdhgmi4f-handleProductItemClick","contextId":"o0j6r"},"onAppLoaded":{"callbackId":"comp-kdhgmi4f-onAppLoaded","contextId":"o0j6r"},"openQuickView":{"callbackId":"comp-kdhgmi4f-openQuickView","contextId":"o0j6r"},"handleAddToCart":{"callbackId":"comp-kdhgmi4f-handleAddToCart","contextId":"o0j6r"},"updateAddToCartStatus":{"callbackId":"comp-kdhgmi4f-updateAddToCartStatus","contextId":"o0j6r"}},"wixCodeProps":{"addedToCartStatus":{},"cssBaseUrl":"https:\/\/static.parastorage.com\/services\/wixstores-client-gallery\/1.1277.0\/","isFirstPage":true,"isInteractive":false,"isLiveSiteMode":true,"isLoaded":true,"showShowLightEmptyState":false,"hideGallery":false,"isMobile":false,"isRTL":false,"mainCollectionId":"00000000-000000-000000-000000000001","productIdToProductPageUrlMap":{"df19c1f7-07d8-a265-42f8-e8dfa824cc6e":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho\/product-page\/sou-um-produto","cd59cd36-b6d2-2cf3-9d48-81793a7bdbbd":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho\/product-page\/sou-um-produto-1","c8539b66-7a44-fe18-affc-afec4be8562a":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho\/product-page\/sou-um-produto-2","1a2d7e83-4bef-31d5-09e1-3326ee271c09":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho\/product-page\/sou-um-produto-3","d99d3cc8-bc75-ec47-6c72-f713016f98f3":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho\/product-page\/sou-um-produto-4","3fb6a3c8-988b-8755-04bd-5c59ae0b18ea":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho\/product-page\/sou-um-produto-5","ea77f230-558f-57b6-cdd1-0ba565e8f827":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho\/product-page\/sou-um-produto-6","6b6778b4-c626-c00d-972c-b138d85e3f07":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho\/product-page\/sou-um-produto-7","975bc5ac-c45f-f81c-fd5c-c909f20d89fa":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho\/product-page\/sou-um-produto-8","7bb38a7a-70b7-9cf3-fc80-584205694465":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho\/product-page\/sou-um-produto-9","52b0658f-3b3d-796e-9532-87cd79468363":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho\/product-page\/sou-um-produto-10","a668ef33-f5b8-6569-d04c-1d123be68441":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho\/product-page\/sou-um-produto-11"},"products":[{"id":"df19c1f7-07d8-a265-42f8-e8dfa824cc6e","options":[{"id":"opt-19"}],"customTextFields":[],"productType":"physical","ribbon":"","price":100,"comparePrice":85,"sku":"364215376135191","isInStock":true,"urlPart":"sou-um-produto","formattedComparePrice":"R$ 85,00","formattedPrice":"R$ 100,00","digitalProductFileItems":[],"name":"Sou um produto","media":[{"url":"b75703_e2f6529d99ec4f708a0cd4ab5e47bce0~mv2.jpg","index":0,"width":470,"mediaType":"PHOTO","altText":null,"title":"Untitled.jpg","height":470}],"isManageProductItems":false,"isTrackingInventory":false,"inventory":{"status":"in_stock","quantity":0},"subscriptionPlans":{"list":[]}},{"id":"cd59cd36-b6d2-2cf3-9d48-81793a7bdbbd","options":[],"customTextFields":[],"productType":"physical","ribbon":"","price":115,"comparePrice":0,"sku":"364215375135191","isInStock":true,"urlPart":"sou-um-produto-1","formattedComparePrice":"","formattedPrice":"R$ 115,00","digitalProductFileItems":[],"name":"Sou um produto","media":[{"url":"b75703_855098dee93b418eb263c618ab6a9eb8~mv2.jpg","index":0,"width":618,"mediaType":"PHOTO","altText":null,"title":"Untitled.jpg","height":463}],"isManageProductItems":false,"isTrackingInventory":false,"inventory":{"status":"in_stock","quantity":0},"subscriptionPlans":{"list":[]}},{"id":"c8539b66-7a44-fe18-affc-afec4be8562a","options":[{"id":"opt-19"}],"customTextFields":[],"productType":"physical","ribbon":"Mais vendido","price":10,"comparePrice":0,"sku":"364115376135191","isInStock":true,"urlPart":"sou-um-produto-2","formattedComparePrice":"","formattedPrice":"R$ 10,00","digitalProductFileItems":[],"name":"Sou um produto","media":[{"url":"b75703_c66d7ccf7a014e98b0128492cae887f1~mv2.jpg","index":0,"width":446,"mediaType":"PHOTO","altText":null,"title":"Untitled_edited_edited.jpg","height":284}],"isManageProductItems":false,"isTrackingInventory":false,"inventory":{"status":"in_stock","quantity":0},"subscriptionPlans":{"list":[]}},{"id":"1a2d7e83-4bef-31d5-09e1-3326ee271c09","options":[{"id":"opt-20"},{"id":"opt-19"}],"customTextFields":[],"productType":"physical","ribbon":"","price":25,"comparePrice":0,"sku":"217537123517253","isInStock":true,"urlPart":"sou-um-produto-3","formattedComparePrice":"","formattedPrice":"R$ 25,00","digitalProductFileItems":[],"name":"Sou um produto","media":[{"url":"b75703_3f3920ee1618489ab6b3ccd0c816423d~mv2.jpg","index":0,"width":425,"mediaType":"PHOTO","altText":null,"title":"Untitled.jpg","height":411}],"isManageProductItems":false,"isTrackingInventory":false,"inventory":{"status":"in_stock","quantity":0},"subscriptionPlans":{"list":[]}},{"id":"d99d3cc8-bc75-ec47-6c72-f713016f98f3","options":[{"id":"opt-20"}],"customTextFields":[],"productType":"physical","ribbon":"Novo","price":75,"comparePrice":0,"sku":"366615376135191","isInStock":true,"urlPart":"sou-um-produto-4","formattedComparePrice":"","formattedPrice":"R$ 75,00","digitalProductFileItems":[],"name":"Sou um produto","media":[{"url":"b75703_c8292f3e04d4499aac071c0d03163014~mv2.jpg","index":0,"width":900,"mediaType":"PHOTO","altText":null,"title":"Untitled.jpg","height":900}],"isManageProductItems":false,"isTrackingInventory":false,"inventory":{"status":"in_stock","quantity":0},"subscriptionPlans":{"list":[]}},{"id":"3fb6a3c8-988b-8755-04bd-5c59ae0b18ea","options":[],"customTextFields":[],"productType":"physical","ribbon":"Mais vendido","price":200,"comparePrice":0,"sku":"36523641234523","isInStock":true,"urlPart":"sou-um-produto-5","formattedComparePrice":"","formattedPrice":"R$ 200,00","digitalProductFileItems":[],"name":"Sou um produto","media":[{"url":"b75703_1a4fb160f30245d48b77ad9115f85410~mv2.jpg","index":0,"width":450,"mediaType":"PHOTO","altText":null,"title":"Untitled.jpg","height":450}],"isManageProductItems":false,"isTrackingInventory":false,"inventory":{"status":"in_stock","quantity":0},"subscriptionPlans":{"list":[]}},{"id":"ea77f230-558f-57b6-cdd1-0ba565e8f827","options":[],"customTextFields":[],"productType":"physical","ribbon":"","price":30,"comparePrice":0,"sku":"364215376135199","isInStock":true,"urlPart":"sou-um-produto-6","formattedComparePrice":"","formattedPrice":"R$ 30,00","digitalProductFileItems":[],"name":"Sou um produto","media":[{"url":"596320_b91daa5918324552a75d4ffcab4dded9~mv2.jpg","index":0,"width":1000,"mediaType":"PHOTO","altText":null,"title":"596320_b91daa5918324552a75d4ffcab4dded9~mv2.jpg","height":1000}],"isManageProductItems":false,"isTrackingInventory":false,"inventory":{"status":"in_stock","quantity":0},"subscriptionPlans":{"list":[]}},{"id":"6b6778b4-c626-c00d-972c-b138d85e3f07","options":[{"id":"opt-20"}],"customTextFields":[],"productType":"physical","ribbon":"","price":150,"comparePrice":0,"sku":"632835642834572","isInStock":true,"urlPart":"sou-um-produto-7","formattedComparePrice":"","formattedPrice":"R$ 150,00","digitalProductFileItems":[],"name":"Sou um produto","media":[{"url":"596320_8d48c924c0ef4a819e83ac09df63d613~mv2.jpg","index":0,"width":1000,"mediaType":"PHOTO","altText":null,"title":"596320_8d48c924c0ef4a819e83ac09df63d613~mv2.jpg","height":1000}],"isManageProductItems":false,"isTrackingInventory":false,"inventory":{"status":"in_stock","quantity":0},"subscriptionPlans":{"list":[]}},{"id":"975bc5ac-c45f-f81c-fd5c-c909f20d89fa","options":[],"customTextFields":[],"productType":"physical","ribbon":"","price":200,"comparePrice":0,"sku":"284215376135191","isInStock":true,"urlPart":"sou-um-produto-8","formattedComparePrice":"","formattedPrice":"R$ 200,00","digitalProductFileItems":[],"name":"Sou um produto","media":[{"url":"596320_5a1ecd48280b4bcda3234d8cb84daa18~mv2.jpg","index":0,"width":1000,"mediaType":"PHOTO","altText":null,"title":"596320_5a1ecd48280b4bcda3234d8cb84daa18~mv2.jpg","height":1000}],"isManageProductItems":false,"isTrackingInventory":false,"inventory":{"status":"in_stock","quantity":0},"subscriptionPlans":{"list":[]}},{"id":"7bb38a7a-70b7-9cf3-fc80-584205694465","options":[],"customTextFields":[],"productType":"physical","ribbon":"","price":110,"comparePrice":0,"sku":"126351351935","isInStock":true,"urlPart":"sou-um-produto-9","formattedComparePrice":"","formattedPrice":"R$ 110,00","digitalProductFileItems":[],"name":"Sou um produto","media":[{"url":"596320_16b54debd2104335b7d7779feb11db80~mv2.jpg","index":0,"width":1000,"mediaType":"PHOTO","altText":null,"title":"596320_16b54debd2104335b7d7779feb11db80~mv2.jpg","height":1000}],"isManageProductItems":false,"isTrackingInventory":false,"inventory":{"status":"in_stock","quantity":0},"subscriptionPlans":{"list":[]}},{"id":"52b0658f-3b3d-796e-9532-87cd79468363","options":[],"customTextFields":[],"productType":"physical","ribbon":"Novo","price":30,"comparePrice":28.5,"sku":"671253175371","isInStock":true,"urlPart":"sou-um-produto-10","formattedComparePrice":"R$ 28,50","formattedPrice":"R$ 30,00","digitalProductFileItems":[],"name":"Sou um produto","media":[{"url":"596320_a3836d3a4eb74f77b1ea9fb111043d00~mv2.jpg","index":0,"width":1000,"mediaType":"PHOTO","altText":null,"title":"596320_a3836d3a4eb74f77b1ea9fb111043d00~mv2.jpg","height":1000}],"isManageProductItems":false,"isTrackingInventory":false,"inventory":{"status":"in_stock","quantity":0},"subscriptionPlans":{"list":[]}},{"id":"a668ef33-f5b8-6569-d04c-1d123be68441","options":[],"customTextFields":[],"productType":"physical","ribbon":"","price":45,"comparePrice":0,"sku":"21554345656","isInStock":true,"urlPart":"sou-um-produto-11","formattedComparePrice":"","formattedPrice":"R$ 45,00","digitalProductFileItems":[],"name":"Sou um produto","media":[{"url":"596320_79405c17b2d14ef8ad76f69d6dc9d1ce~mv2.jpg","index":0,"width":1000,"mediaType":"PHOTO","altText":null,"title":"596320_79405c17b2d14ef8ad76f69d6dc9d1ce~mv2.jpg","height":1000}],"isManageProductItems":false,"isTrackingInventory":false,"inventory":{"status":"in_stock","quantity":0},"subscriptionPlans":{"list":[]}}],"showTitle":false,"ravenUserContextOverrides":{"id":"ed5f9768-c20d-4c70-8f9f-7cc59fbf7d11","uuid":"ed8c7760-25b0-4b04-9ec5-de4ddc0e64a8"},"textsMap":{"addToCartContactSeller":"Contactar Vendedor","addToCartOutOfStock":"Esgotado","digitalProductBadgeAriaLabelText":"Produto Digital","galleryAddToCartButtonText":"Adicionar ao Carrinho","noProductsMessageText":"Não temos nenhum produto\npara mostrar no momento.","productOutOfStockText":"Esgotado","productPriceAfterDiscountSR":"Preço promocional","productPriceBeforeDiscountSR":"Preço normal","productPriceWhenThereIsNoDiscountSR":"Preço","quantityAddSR":"Adicionar quantidade","quantityChooseAmountSR":"Escolher quantidade","quantityInputSR":"Quantidade","quantityMaximumAmountSR":"Apenas {{ inventory }} restantes no estoque","quantityMinimumAmountSR":"Insira um valor acima de {{ minimum }}","quantityRemoveSR":"Remover quantidade","quantityTotalSR":"Total de {{quantity}} itens.","quickViewButtonText":"Visualização Rápida","sliderGalleryNextProduct":"Próximo Produto","sliderGalleryNoProductsMessageText":"Não temos nenhum produto para mostrar no momento.","sliderGalleryPreviousProduct":"Produto Anterior","sliderGalleryTitle":"Todos os produtos"},"totalProducts":12,"shouldShowAddToCartSuccessAnimation":false,"experiments":{"isArrowlessMobileSliderEnabled":false}}}},"externalScripts":{},"seoDebugInfo":{},"seoSsrData":{"tags":[{"type":"title","children":"Início | Todo Negócio AKI Pertinho"},{"type":"meta","props":{"name":"description","content":"Um portal que se destina a prestação de serviços de divulgação, anúncios exclusivos para empresas que querem anunciar seus produtos e serviços."}},{"type":"link","props":{"rel":"canonical","href":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho"}},{"type":"meta","props":{"property":"og:title","content":"Início | Todo Negócio AKI Pertinho"}},{"type":"meta","props":{"property":"og:description","content":"Um portal que se destina a prestação de serviços de divulgação, anúncios exclusivos para empresas que querem anunciar seus produtos e serviços."}},{"type":"meta","props":{"property":"og:url","content":"https:\/\/igrejaevredencao74.wixsite.com\/akipertinho"}},{"type":"meta","props":{"property":"og:site_name","content":"Todo Negócio AKI Per"}},{"type":"meta","props":{"property":"og:type","content":"website"}},{"type":"meta","props":{"name":"keywords","content":"Aqui perto, pertinho, perto, produtos, regi&atilde;o, todo neg&oacute;cio"}}]},"cssData":{},"tpaCompIdToAppId":{"comp-kdgakqt5":"1552","comp-kdhglxvo":"1104","tpaWorker_3546":3546,"comp-kdhjopim":"3546"}};
    </script>
    


    
    
    
    

    
        <!-- No Footer -->
    

    
    
    
    
    
    
    
    <!--body end html embeds start-->
    
    <!--body end html embeds end-->
    
    
    

    
    
    
    <script type="text/javascript">
      var timeSpentInSSR = 821;
    </script>
    
    
    <script type="text/javascript">
      var ssrInfo = {"timeSpentInSSR":821,"platformOnPage":true,"workerStarted":true,"platformAppsOnPage":["1380b703-ce81-ff05-f115-39571d94dfcd","14517e1a-3ff0-af98-408e-2bd6953c36a2","14cc59bc-f0b7-15b8-e1c7-89ce41d0e0c9"],"userCode":false,"useBoltush":true,"sessionId":"c741fced-9865-47d9-b1e5-04b2e0906e7d","cacheExclusionReason":"","cacheableUserCode":"false","useBoltushUserCode":true};
    </script>
    

    


</body>
</html>

// JavaScript Document
